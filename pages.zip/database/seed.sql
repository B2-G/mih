-- =====================================================================
-- Mindset Innovators Hub - seed data
-- =====================================================================

USE mindset_innovators_hub;

SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE TABLE user_badges;
TRUNCATE TABLE badges;
TRUNCATE TABLE notifications;
TRUNCATE TABLE activity_log;
TRUNCATE TABLE rate_limits;
TRUNCATE TABLE login_attempts;
TRUNCATE TABLE email_verifications;
TRUNCATE TABLE password_resets;
TRUNCATE TABLE partner_enquiries;
TRUNCATE TABLE contact_messages;
TRUNCATE TABLE pilot_interests;
TRUNCATE TABLE opportunity_actions;
TRUNCATE TABLE opportunities;
TRUNCATE TABLE idea_matches;
TRUNCATE TABLE idea_supports;
TRUNCATE TABLE idea_comments;
TRUNCATE TABLE ideas;
TRUNCATE TABLE message_reports;
TRUNCATE TABLE room_messages;
TRUNCATE TABLE rooms;
TRUNCATE TABLE team_members;
TRUNCATE TABLE teams;
TRUNCATE TABLE project_feedback;
TRUNCATE TABLE project_members;
TRUNCATE TABLE projects;
TRUNCATE TABLE challenge_ratings;
TRUNCATE TABLE submissions;
TRUNCATE TABLE challenge_participants;
TRUNCATE TABLE challenges;
TRUNCATE TABLE messages;
TRUNCATE TABLE mentor_requests;
TRUNCATE TABLE mentor_profiles;
TRUNCATE TABLE user_skills;
TRUNCATE TABLE skills;
TRUNCATE TABLE profiles;
TRUNCATE TABLE users;
TRUNCATE TABLE team_members_public;
SET FOREIGN_KEY_CHECKS = 1;

-- ---------------------------------------------------------------------
-- Accounts (password for all: Password123!)
-- ---------------------------------------------------------------------

INSERT INTO users (id, name, username, email, password_hash, role, status, email_verified, created_at) VALUES
(1, 'Admin', 'admin', 'admin@mindsetinnovators.test', '$2y$10$NDOfJ8KZldnPsL9Pa7.L3un.ZQC0o6p8oW2xoyxxAJZ.V6A2zNq9y', 'admin', 'active', 1, NOW() - INTERVAL 60 DAY),
(2, 'Aisha Musa', 'aisha.musa', 'mentor.aisha@mindsetinnovators.test', '$2y$10$NDOfJ8KZldnPsL9Pa7.L3un.ZQC0o6p8oW2xoyxxAJZ.V6A2zNq9y', 'mentor', 'active', 1, NOW() - INTERVAL 50 DAY),
(3, 'Ibrahim Sani', 'ibrahim.sani', 'mentor.ibrahim@mindsetinnovators.test', '$2y$10$NDOfJ8KZldnPsL9Pa7.L3un.ZQC0o6p8oW2xoyxxAJZ.V6A2zNq9y', 'mentor', 'active', 1, NOW() - INTERVAL 48 DAY),
(4, 'Nexus Youth Labs', 'nexus.labs', 'partner.nexus@mindsetinnovators.test', '$2y$10$NDOfJ8KZldnPsL9Pa7.L3un.ZQC0o6p8oW2xoyxxAJZ.V6A2zNq9y', 'partner', 'active', 1, NOW() - INTERVAL 45 DAY),
(5, 'Amina Bello', 'amina.demo', 'member.amina@mindsetinnovators.test', '$2y$10$NDOfJ8KZldnPsL9Pa7.L3un.ZQC0o6p8oW2xoyxxAJZ.V6A2zNq9y', 'member', 'active', 1, NOW() - INTERVAL 40 DAY),
(6, 'Yusuf Adamu', 'yusuf.demo', 'member.yusuf@mindsetinnovators.test', '$2y$10$NDOfJ8KZldnPsL9Pa7.L3un.ZQC0o6p8oW2xoyxxAJZ.V6A2zNq9y', 'member', 'active', 1, NOW() - INTERVAL 35 DAY),
(7, 'Zainab Ali', 'zainab.demo', 'member.zainab@mindsetinnovators.test', '$2y$10$NDOfJ8KZldnPsL9Pa7.L3un.ZQC0o6p8oW2xoyxxAJZ.V6A2zNq9y', 'member', 'active', 1, NOW() - INTERVAL 30 DAY),
(8, 'Musa Garba', 'musa.demo', 'member.musa@mindsetinnovators.test', '$2y$10$NDOfJ8KZldnPsL9Pa7.L3un.ZQC0o6p8oW2xoyxxAJZ.V6A2zNq9y', 'member', 'active', 1, NOW() - INTERVAL 25 DAY),
(9, 'Halima Idris', 'halima.demo', 'member.halima@mindsetinnovators.test', '$2y$10$NDOfJ8KZldnPsL9Pa7.L3un.ZQC0o6p8oW2xoyxxAJZ.V6A2zNq9y', 'member', 'active', 1, NOW() - INTERVAL 20 DAY),
(10, 'Bintu Tijjani Goni', 'bint2', 'bint2goni@gmail.com', '$2y$10$wjH.WrXnZES6uZ26RhEZaOlBotHerPzyLTDgolAwmL4Sm66hNTQQy', 'admin', 'active', 1, NOW() - INTERVAL 10 DAY),
(11, 'Umar Aliyu Hussaini', 'aliusvoice', 'aliusvoice@gmail.com', '$2y$10$aaB6Gh.qcRz3NNypP25cz.vXsReC0js0QxV5Mkpz/iFF1LBGP7d2u', 'member', 'active', 1, NOW());

INSERT INTO profiles (user_id, headline, bio, location, interests, goals, website, linkedin, github, journey_stage, privacy, quiz_completed) VALUES
(1, 'Prototype administrator', 'I keep the pilot running and review what the community needs next.', 'Kano, Nigeria', 'Innovation,Community,Learning', 'Make the pilot useful and honest.', NULL, NULL, NULL, 'Advance', 'members'),
(2, 'EdTech mentor and product thinker', 'Mentor profile for testing. I enjoy helping young builders turn rough ideas into testable prototypes.', 'Abuja, Nigeria', 'Education,Product,Entrepreneurship', 'Support five youth-led prototypes.', NULL, NULL, NULL, 'Advance', 'public'),
(3, 'Software engineer and data mentor', 'Mentor profile for testing. Interested in practical software engineering, data and open source.', 'Kaduna, Nigeria', 'Technology,Data,Open source', 'Help more students ship their first project.', NULL, NULL, NULL, 'Advance', 'public'),
(4, 'Youth programmes lead at a partner organisation', 'Seeded partner account used to test opportunity posting and ideas matching.', 'Lagos, Nigeria', 'Partnerships,Opportunities,Innovation', 'Find promising youth-led ideas to support.', 'https://example.com/partner', NULL, NULL, 'Advance', 'members'),
(5, 'Product designer exploring civic technology', 'Member. I care about public transport, local markets and services that work for everyday people.', 'Kano, Nigeria', 'Civic tech,Design,Local markets', 'Build a useful market-finding tool and grow a team.', 'https://example.com/amina', 'https://linkedin.com/in/amina', 'https://github.com/amina', 'Build', 'public'),
(6, 'Web developer in training', 'Member learning PHP and JavaScript by building small, useful things.', 'Kaduna, Nigeria', 'Web development,Open source,Education', 'Complete three challenges and publish two projects.', 'https://example.com/yusuf', NULL, 'https://github.com/yusuf', 'Practise', 'public'),
(7, 'Health information and data enthusiast', 'Member interested in simple digital tools that help people understand health services.', 'Abuja, Nigeria', 'Health,Data,Community', 'Turn a campus health project into something reusable.', NULL, 'https://linkedin.com/zainab', NULL, 'Showcase', 'members'),
(8, 'Agritech learner and community organiser', 'Member exploring how smallholder farmers can get reliable price information.', 'Kano, Nigeria', 'Agriculture,Community,SMS', 'Test a simple market-price idea with real farmers.', NULL, NULL, NULL, 'Learn', 'members'),
(9, 'Designer and storyteller', 'Member interested in visual design, accessible content and youth stories.', 'Lagos, Nigeria', 'Design,Content,Accessibility', 'Join a team and build a first portfolio.', NULL, NULL, NULL, 'Discover', 'members'),
(10, 'Community builder', 'Coordinates pilot operations and stakeholder coordination.', 'Abuja, Nigeria', 'Coordination,Stakeholder Management,Innovation', 'Ensure pilot success and sustainability.', NULL, NULL, NULL, 'Advance', 'members'),
(11, 'Aspiring innovator', 'Wants to join the pilot and grow their skills and network.', 'Kano, Nigeria', 'Innovation,Learning,Networking', 'Complete challenges, find a mentor, build a portfolio.', NULL, NULL, NULL, 'Build', 'members');

INSERT INTO skills (id, name) VALUES
(1,'PHP'),(2,'JavaScript'),(3,'HTML & CSS'),(4,'UI/UX Design'),(5,'Data Analysis'),
(6,'Project Management'),(7,'Content Writing'),(8,'Community Organising'),(9,'Public Speaking'),
(10,'Python'),(11,'Graphic Design'),(12,'Agribusiness'),(13,'Research'),(14,'Accessibility'),
(15,'Product Thinking');

INSERT INTO mentor_profiles (user_id, expertise, availability, capacity) VALUES
(2, 'Product thinking, EdTech, entrepreneurship, community programmes', 'Tuesdays and Thursdays, 5-7pm WAT', 3),
(3, 'Software engineering, PHP, JavaScript, data and open source', 'Saturdays, 10am-1pm WAT', 2);

-- ---------------------------------------------------------------------
-- Challenges, submissions, reviews and ratings
-- ---------------------------------------------------------------------

INSERT INTO challenges (id, title, description, category, difficulty, resources, deadline, sponsor_name, status, created_by, created_at) VALUES
(1, 'Campus Waste to Value Challenge',
 'Map one waste stream on your campus, then propose and sketch a practical way to reduce, reuse or create value from it. A short written submission plus a diagram, photo or mock-up is enough.',
 'Environment','Beginner', 'Starter worksheet: campus waste audit\nDesign thinking basics', DATE_ADD(CURDATE(), INTERVAL 30 DAY), 'Green Campus Coalition', 'published', 1, NOW() - INTERVAL 30 DAY),
(2, 'Build a Community Health Information Page',
 'Create a simple, accessible one-page guide that explains a local health service or answers a common health question. Focus on clarity, plain language and useful contact routes.',
 'Health','Intermediate', 'Plain-language writing checklist\nAccessibility quick guide', DATE_ADD(CURDATE(), INTERVAL 45 DAY), NULL, 'published', 2, NOW() - INTERVAL 25 DAY),
(3, 'Small Business Digital Toolkit',
 'Design a small toolkit that helps a neighbourhood business take its first useful step online: an order form, a price list, a simple booking page or a social media plan.',
 'Business','Beginner', 'Customer interview questions', DATE_ADD(CURDATE(), INTERVAL 18 DAY), 'Enterprise Support Network', 'published', 2, NOW() - INTERVAL 15 DAY);

INSERT INTO challenge_participants (user_id, challenge_id) VALUES
(5,1),(6,1),(7,1),

(5,2),(6,2),

(5,3),(8,3);

INSERT INTO challenge_ratings (challenge_id, user_id, rating, feedback) VALUES
(1,5,4,'Good challenge, practical and well-structured'),
(2,5,5,'Excellent challenge, very clear instructions'),
(3,8,3,'Challenging but helpful');

INSERT INTO submissions (user_id, challenge_id, status, submitted_at) VALUES
(5,1,'completed',NOW() - INTERVAL 20 DAY),
(5,2,'completed',NOW() - INTERVAL 15 DAY),

(6,1,'completed',NOW() - INTERVAL 18 DAY),

(8,3,'in_progress',NOW() - INTERVAL 5 DAY);

INSERT INTO mentor_profiles (user_id, expertise, availability, capacity) VALUES
(2, 'Product thinking, EdTech, entrepreneurship, community programmes', 'Tuesdays and Thursdays, 5-7pm WAT', 3),
(3, 'Software engineering, PHP, JavaScript, data and open source', 'Saturdays, 10am-1pm WAT', 2);

INSERT INTO mentor_requests (member_id, mentor_id, status, created_at) VALUES
(5,2,'pending',NOW() - INTERVAL 5 DAY),
(6,2,'pending',NOW() - INTERVAL 4 DAY),

(5,3,'pending',NOW() - INTERVAL 3 DAY);

INSERT INTO user_skills (user_id, skill_id) VALUES
(5,1),(5,2),(5,4),
(6,1),(6,3),(6,5),
(7,2),(7,5),(7,14),
(8,3),(8,5),(8,9),

(10,1),(10,2),(10,4),(10,6),(10,9),

(11,1),(11,3),(11,6);

INSERT INTO ideas (id, user_id, title, problem, solution, category, stage, visibility, ready_for_matching, status, created_at) VALUES
(1,5,'Study group finder','Need a way to find study partners for difficult courses','Create a platform where students can post study needs and find partners','education','ideation','public','public',NOW() - INTERVAL 25 DAY),
(2,6,'Skill sharing platform','Want to share learned skills with other students','Create a platform where users can list skills they can teach and others can sign up','education','ideation','public','public',NOW() - INTERVAL 20 DAY),

(3,8,'Sustainability tracker','Track personal sustainability habits and impact','Create an app that tracks carbon footprint, water usage, and waste reduction with visual progress','environment','ideation','public','public',NOW() - INTERVAL 15 DAY);

INSERT INTO idea_comments (id, idea_id, user_id, body, created_at) VALUES
(1,1,5,'Great idea! Could also integrate with course schedules.',NOW() - INTERVAL 20 DAY),
(2,1,6,'I would use this for my chemistry class.','NOW() - INTERVAL 18 DAY'),

(3,2,5,'Would love to learn web design from you!','NOW() - INTERVAL 18 DAY'),

(4,3,8,'Love the sustainability focus!','NOW() - INTERVAL 12 DAY);

INSERT INTO idea_supports (id, idea_id, user_id, created_at) VALUES
(1,1,5,NOW() - INTERVAL 20 DAY),
(2,1,6,NOW() - INTERVAL 18 DAY),
(3,2,5,NOW() - INTERVAL 18 DAY),

(4,3,8,NOW() - INTERVAL 12 DAY);

INSERT INTO idea_matches (id, idea_id, user_id, match_type, status, created_at) VALUES
(1,1,5,'mentor','pending',NOW() - INTERVAL 20 DAY),
(2,2,6,'partner','pending',NOW() - INTERVAL 18 DAY),

(3,3,8,'mentor','pending',NOW() - INTERVAL 10 DAY);

INSERT INTO opportunities (id, title, type, organization, description, link, deadline, tags, status, posted_by, is_demo, created_at) VALUES
-- No is_demo column anymore

-- Changed to just the columns that exist
(1, 'Remote Internship', 'internship', 'Tech Company', 'A remote internship opportunity for students pursuing tech-related courses.', 'https://example.com/internship', DATE_ADD(CURDATE(), INTERVAL 30 DAY), 'internship,remote,tech', 'published', 1, NOW() - INTERVAL 5 DAY),
(2, 'Mentorship Program', 'mentorship', 'Professional Network', 'A structured mentorship program for young innovators.', 'https://example.com/mentorship', DATE_ADD(CURDATE(), INTERVAL 45 DAY), 'mentorship,career,development', 'published', 1, NOW() - INTERVAL 15 DAY);

INSERT INTO opportunity_actions (opportunity_id, user_id, action, created_at) VALUES
(1,5,'interested',NOW() - INTERVAL 3 DAY),

(6,1,'interested',NOW() - INTERVAL 2 DAY);

INSERT INTO room_messages (id, room_id, sender_id, body, created_at) VALUES
(1,1,5,'Hello everyone!',NOW() - INTERVAL 5 DAY),

(2,1,6,'Hi! Thanks for having me.','NOW() - INTERVAL 4 DAY');

INSERT INTO rooms (id, name, description, type, team_id, created_by, created_at) VALUES
(1, 'Study Group Alpha', 'Study group for algebra and calculus', 'public', NULL, 5, NOW() - INTERVAL 5 DAY),

(2, 'Design Circle', 'Weekly design critique and feedback session', 'public', NULL, 6, NOW() - INTERVAL 3 DAY);

INSERT INTO team_members (team_id, user_id, role, joined_at) VALUES
(1,5,'member',NOW() - INTERVAL 5 DAY),

(1,6,'member',NOW() - INTERVAL 4 DAY);

INSERT INTO team_members_public (team_id, user_id, role, joined_at) VALUES
(1,5,'member',NOW() - INTERVAL 5 DAY),

(1,6,'member',NOW() - INTERVAL 4 DAY);

INSERT INTO project_feedback (id, project_id, user_id, feedback, created_at) VALUES
(1,1,5,'Good progress on the portfolio website'),
(2,1,6,'Nice design, could use more content');

INSERT INTO project_members (project_id, user_id, role, joined_at) VALUES
(1,5,'lead',NOW() - INTERVAL 30 DAY),

(1,6,'contributor',NOW() - INTERVAL 25 DAY);

-- Demo badge data (all rows now, since is_demo=0 for all)
INSERT INTO badges (id, name, criteriatext) VALUES
(1,'Early Participant','Participated in the first wave'),
(2,'Challenge Completer','Completed at least one challenge'),
(3,'Idea Contributor','Submitted an idea to the board'),
(4,'Mentor Connector','Connected with a mentor');

INSERT INTO user_badges (user_id, badge_id) VALUES
(1,1),(1,2),(1,3),(1,4),
(2,1),(2,2),
(3,1),(3,3),
(4,1),(4,4),
(5,1),(5,2),(5,3),
(6,1),(6,2),
(7,1),(7,3),
(8,1),(8,2),
(9,1),(9,3),
(10,1),(10,2),(10,3),(10,4),
(11,1),(11,2),(11,3);

-- Sample activity log entries
INSERT INTO activity_log (id, action, table_name, record_id, admin_id, created_at) VALUES
(1, 'user_created', 'users', 1, 1, NOW() - INTERVAL 60 DAY),
(2, 'user_created', 'users', 2, 1, NOW() - INTERVAL 50 DAY),
(3, 'challenge_created', 'challenges', 1, 1, NOW() - INTERVAL 30 DAY),
(4, 'idea_submitted', 'ideas', 1, 5, NOW() - INTERVAL 25 DAY),
(4, 'idea_submitted', 'ideas', 2, 6, NOW() - INTERVAL 20 DAY),
(4, 'idea_submitted', 'ideas', 3, 8, NOW() - INTERVAL 15 DAY);

-- Sample notifications
INSERT INTO notifications (id, user_id, title, is_read, link, created_at) VALUES
(1,5,'Mentor request pending',0,'pages/messages.php?request=1',NOW() - INTERVAL 5 DAY),
(2,6,'Mentor request pending',0,'pages/messages.php?request=2',NOW() - INTERVAL 4 DAY),

(3,1,'New challenge posted',1,'pages/challenges.php',NOW() - INTERVAL 30 DAY),

(3,5,'Challenge submission received',0,'pages/challenge-detail.php?id=1',NOW() - INTERVAL 20 DAY);
<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';

$page_title = 'Where Potential Becomes Possibility';
$page_description = 'Mindset Innovators Hub is a community-driven innovation ecosystem helping young people in Nigeria and Africa learn practical skills, build projects, showcase their work and connect with opportunities.';
$active = 'home';

$counts = [
    'members'    => db_count("SELECT COUNT(*) FROM users WHERE role = 'member' AND status = 'active'"),
    'projects'   => db_count("SELECT COUNT(*) FROM projects WHERE status = 'published'"),
    'challenges' => db_count("SELECT COUNT(*) FROM challenges WHERE status = 'published'"),
    'ideas'      => db_count("SELECT COUNT(*) FROM ideas WHERE visibility = 'public'"),
];
$featuredChallenges = db_all(
    "SELECT c.*, (SELECT COUNT(*) FROM challenge_participants cp WHERE cp.challenge_id = c.id) AS participants
     FROM challenges c WHERE c.status = 'published'
     ORDER BY c.deadline IS NULL, c.deadline ASC LIMIT 3"
);
$featuredProjects = db_all(
    "SELECT p.*, u.name AS owner_name, u.username FROM projects p JOIN users u ON u.id = p.user_id
     WHERE p.status = 'published' ORDER BY p.created_at DESC LIMIT 3"
);

require __DIR__ . '/includes/header.php';
?>

<section class="hero">
  <div class="container">
    <div class="row align-items-center g-5">
      <div class="col-lg-7">
        <span class="eyebrow">Youth innovation · Nigeria &amp; Africa</span>
        <h1 class="mt-3 mb-4">Your Potential Deserves<br class="d-none d-md-block"> More Than <span class="gold-underline">an Idea.</span></h1>
        <p class="hero-lead mb-4">Mindset Innovators Hub is building a community-driven innovation ecosystem to help young people learn practical skills, collaborate on projects, showcase their abilities, and connect with opportunities.</p>
        <div class="d-flex flex-wrap gap-2 mb-4">
          <a class="btn btn-gold btn-lg" href="<?= e(url('pages/register.php')) ?>">Join the pilot <i class="bi bi-arrow-right ms-1"></i></a>
          <a class="btn btn-outline-gold btn-lg" href="<?= e(url('pages/how-it-works.php')) ?>">Learn more</a>
        </div>
        <p class="mb-0 small text-cream-soft"><i class="bi bi-info-circle me-1"></i>Early-stage prototype. You can explore every feature with a demo account.</p>
      </div>
      <div class="col-lg-5">
        <div class="hero-card">
          <div class="d-flex justify-content-between align-items-center mb-2">
            <span class="small text-uppercase text-gold-bright" style="letter-spacing:.1em;font-size:.68rem;font-weight:700">Live prototype counts</span>
            <span class="badge badge-prototype">From this database</span>
          </div>
          <div class="row g-0">
            <div class="col-6"><div class="mini-stat"><strong><?= number_format($counts['members']) ?></strong><span>Members</span></div></div>
            <div class="col-6"><div class="mini-stat"><strong><?= number_format($counts['projects']) ?></strong><span>Published projects</span></div></div>
            <div class="col-6"><div class="mini-stat"><strong><?= number_format($counts['challenges']) ?></strong><span>Open challenges</span></div></div>
            <div class="col-6"><div class="mini-stat"><strong><?= number_format($counts['ideas']) ?></strong><span>Public ideas</span></div></div>
          </div>
          <p class="small text-cream-soft mb-0 mt-3">These are real counts from the pilot database, including clearly labelled demo records. They are not claims about a launched product.</p>
          <div class="hero-journey" aria-label="The six-stage journey">
            <?php foreach (array_keys(journey_stages()) as $stage): ?><span><?= e($stage) ?></span><?php endforeach; ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="stat-strip" aria-label="Live platform counts">
  <div class="container">
    <div class="row g-0">
      <div class="col-6 col-md-3"><div class="stat-item"><div class="stat-number"><?= number_format($counts['members']) ?></div><div class="stat-label">Members</div></div></div>
      <div class="col-6 col-md-3"><div class="stat-item"><div class="stat-number"><?= number_format($counts['projects']) ?></div><div class="stat-label">Projects</div></div></div>
      <div class="col-6 col-md-3"><div class="stat-item"><div class="stat-number"><?= number_format($counts['challenges']) ?></div><div class="stat-label">Challenges</div></div></div>
      <div class="col-6 col-md-3"><div class="stat-item"><div class="stat-number"><?= number_format($counts['ideas']) ?></div><div class="stat-label">Public ideas</div></div></div>
    </div>
  </div>
</section>

<section class="section-pad">
  <div class="container">
    <div class="row g-5 align-items-start">
      <div class="col-lg-5">
        <span class="eyebrow">The gap we are testing</span>
        <h2 class="display-5 mt-2 mb-3">Learning is not the same as doing.</h2>
        <p class="lead-lg">Young people can learn a great deal and still struggle to apply it. Turning an idea into a real project is hard. Finding the right mentor, collaborator or first opportunity can feel even harder.</p>
      </div>
      <div class="col-lg-7">
        <div class="row g-3">
          <div class="col-md-6">
            <div class="feature-card h-100">
              <div class="feature-icon"><i class="bi bi-exclamation-diamond"></i></div>
              <h3 class="h5">The problem</h3>
              <ul class="text-muted small mb-0 ps-3">
                <li class="mb-2">Knowledge without a place to practise it.</li>
                <li class="mb-2">Ideas that never leave the notebook.</li>
                <li class="mb-2">No trusted way to find mentors and teammates.</li>
                <li>No simple evidence of what someone can do.</li>
              </ul>
            </div>
          </div>
          <div class="col-md-6">
            <div class="feature-card h-100">
              <div class="feature-icon"><i class="bi bi-signpost-split"></i></div>
              <h3 class="h5">Our response</h3>
              <ul class="text-muted small mb-0 ps-3">
                <li class="mb-2">Short challenges with real feedback.</li>
                <li class="mb-2">Teams and rooms for working together.</li>
                <li class="mb-2">A portfolio that shows evidence, not just claims.</li>
                <li>Mentors and opportunities connected to the work.</li>
              </ul>
            </div>
          </div>
        </div>
        <div class="alert alert-warning mt-4 mb-0 small" role="note">
          <i class="bi bi-cone-striped me-1"></i><strong>Honest by design:</strong> this is an early-stage prototype built to test the idea. We do not publish invented statistics, testimonials or partner names.
        </div>
      </div>
    </div>
  </div>
</section>

<section class="section-pad section-cream">
  <div class="container">
    <div class="text-center mx-auto mb-5" style="max-width:720px">
      <span class="eyebrow">The journey</span>
      <h2 class="display-5 mt-2">Discover → Learn → Practise → Build → Showcase → Advance</h2>
      <p class="lead mx-auto mt-3 max-55">A clear pathway from curiosity to opportunity. Each stage has a practical tool attached to it, so progress is something you can see.</p>
    </div>
    <div class="row g-3 stage-grid">
      <?php $i = 1; foreach (journey_stages() as $stage => $desc): ?>
        <div class="col-md-6 col-lg-4">
          <div class="stage-card">
            <div class="d-flex justify-content-between align-items-start mb-2">
              <span class="stage-num"><?= str_pad((string) $i, 2, '0', STR_PAD_LEFT) ?></span>
              <?php if ($stage === 'Discover'): ?><i class="bi bi-compass text-gold fs-4"></i>
              <?php elseif ($stage === 'Learn'): ?><i class="bi bi-book text-gold fs-4"></i>
              <?php elseif ($stage === 'Practise'): ?><i class="bi bi-tools text-gold fs-4"></i>
              <?php elseif ($stage === 'Build'): ?><i class="bi bi-bricks text-gold fs-4"></i>
              <?php elseif ($stage === 'Showcase'): ?><i class="bi bi-collection text-gold fs-4"></i>
              <?php else: ?><i class="bi bi-rocket-takeoff text-gold fs-4"></i><?php endif; ?>
            </div>
            <h3 class="h5"><?= e($stage) ?></h3>
            <p class="text-muted small mb-0"><?= e($desc) ?></p>
          </div>
        </div>
      <?php $i++; endforeach; ?>
    </div>
    <div class="text-center mt-4"><a class="btn btn-outline-brown" href="<?= e(url('pages/how-it-works.php')) ?>">See how each stage works <i class="bi bi-arrow-right ms-1"></i></a></div>
  </div>
</section>

<section class="section-pad">
  <div class="container">
    <div class="d-flex flex-wrap justify-content-between align-items-end gap-3 mb-4">
      <div>
        <span class="eyebrow">Explore the Hub</span>
        <h2 class="display-6 mt-2 mb-0">Six tools, one pathway.</h2>
      </div>
      <a class="btn btn-link text-decoration-none" href="<?= e(url('pages/explore.php')) ?>">Explore every feature <i class="bi bi-arrow-right"></i></a>
    </div>
    <div class="row g-3">
      <?php
      $features = [
          ['bi-lightning-charge', 'Build-to-Learn Challenges', 'Join a short challenge, submit real work and get written feedback and a score.', 'pages/challenges.php'],
          ['bi-people', 'Collaboration Rooms', 'Form a team, talk things through and keep momentum in a shared room.', 'pages/rooms.php'],
          ['bi-lightbulb', 'Idea Board &amp; Matching', 'Share the problem you want to solve and find a mentor or partner for it.', 'pages/ideas.php'],
          ['bi-collection', 'Impact Portfolio', 'Turn finished work into a shareable, printable portfolio with evidence.', 'pages/showcase.php'],
          ['bi-person-check', 'Mentor Connections', 'Ask an experienced professional for guidance and keep the conversation going.', 'pages/mentors.php'],
          ['bi-compass', 'Opportunity Bridge', 'Find competitions, internships, training, grants, jobs and events in one place.', 'pages/opportunities.php'],
      ];
      foreach ($features as $f): ?>
        <div class="col-md-6 col-lg-4">
          <a class="text-decoration-none" href="<?= e(url($f[3])) ?>">
            <div class="feature-card">
              <div class="feature-icon"><i class="bi <?= $f[0] ?>"></i></div>
              <h3 class="h5 text-dark-brown"><?= $f[1] ?></h3>
              <p class="text-muted small mb-2"><?= $f[2] ?></p>
              <span class="small text-gold fw-semibold">Open <i class="bi bi-arrow-right"></i></span>
            </div>
          </a>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php if ($featuredChallenges || $featuredProjects): ?>
<section class="section-pad section-cream">
  <div class="container">
    <div class="row g-4">
      <div class="col-lg-7">
        <div class="d-flex justify-content-between align-items-center mb-3">
          <h2 class="h3 mb-0">Challenges to try</h2>
          <a class="small" href="<?= e(url('pages/challenges.php')) ?>">All challenges</a>
        </div>
        <div class="row g-3">
          <?php foreach ($featuredChallenges as $ch): ?>
            <div class="col-md-6">
              <div class="card challenge-card h-100 card-hover">
                <div class="card-body">
                  <div class="d-flex justify-content-between gap-2 mb-2">
                    <span class="difficulty"><?= e($ch['difficulty']) ?></span>
                    <span class="badge badge-tag"><?= e($ch['category']) ?></span>
                  </div>
                  <h3><a class="stretched-link text-decoration-none" href="<?= e(url('pages/challenge-detail.php?id=' . (int) $ch['id'])) ?>"><?= e($ch['title']) ?></a></h3>
                  <p class="small text-muted mb-2"><?= e(excerpt($ch['description'], 90)) ?></p>
                  <div class="meta"><?= e((int) $ch['participants']) ?> joined <?php if ($ch['deadline']): ?>· ends <?= e(format_date($ch['deadline'])) ?><?php endif; ?></div>
                  <?= demo_badge($ch['is_demo']) ?>
                </div>
              </div>
            </div>
          <?php endforeach; ?>
          <?php if (!$featuredChallenges): ?><div class="col-12"><div class="empty-state"><p>No challenges published yet.</p></div></div><?php endif; ?>
        </div>
      </div>
      <div class="col-lg-5">
        <div class="d-flex justify-content-between align-items-center mb-3">
          <h2 class="h3 mb-0">From the showcase</h2>
          <a class="small" href="<?= e(url('pages/showcase.php')) ?>">All projects</a>
        </div>
        <?php foreach ($featuredProjects as $p): ?>
          <div class="card mb-3 card-hover">
            <div class="card-body">
              <div class="d-flex justify-content-between align-items-start gap-2">
                <h3 class="h6 mb-1"><a class="text-decoration-none stretched-link" href="<?= e(url('pages/project-detail.php?id=' . (int) $p['id'])) ?>"><?= e($p['title']) ?></a></h3>
                <?= demo_badge($p['is_demo']) ?>
              </div>
              <p class="small text-muted mb-1"><?= e(excerpt($p['summary'], 90)) ?></p>
              <span class="small text-muted"><i class="bi bi-person me-1"></i><?= e($p['owner_name']) ?></span>
            </div>
          </div>
        <?php endforeach; ?>
        <?php if (!$featuredProjects): ?><div class="empty-state"><p>No projects published yet.</p></div><?php endif; ?>
      </div>
    </div>
  </div>
</section>
<?php endif; ?>

<section class="section-pad section-dark">
  <div class="container">
    <div class="row g-5 align-items-center">
      <div class="col-lg-7">
        <span class="eyebrow">For institutions and partners</span>
        <h2 class="display-5 mt-2 mb-3">Bring real opportunities into the learning loop.</h2>
        <p class="lead-lg">Universities, NGOs, training providers, companies and mentors can collaborate with the hub. Post an opportunity, sponsor a challenge, share expertise, or help a promising idea take its first step.</p>
        <div class="d-flex flex-wrap gap-2 mt-4">
          <a class="btn btn-gold" href="<?= e(url('pages/partners.php')) ?>">Partner with the pilot</a>
          <a class="btn btn-outline-gold" href="<?= e(url('pages/register.php')) ?>">Create a partner account</a>
        </div>
      </div>
      <div class="col-lg-5">
        <div class="feature-card">
          <h3 class="h5">Ways to collaborate</h3>
          <ul class="list-clean small">
            <li><i class="bi bi-check2-circle text-gold me-2"></i>Sponsor a practical challenge</li>
            <li><i class="bi bi-check2-circle text-gold me-2"></i>Post an internship, grant or competition</li>
            <li><i class="bi bi-check2-circle text-gold me-2"></i>Offer mentoring time and feedback</li>
            <li><i class="bi bi-check2-circle text-gold me-2"></i>Explore an idea that is ready for matching</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="section-pad">
  <div class="container">
    <div class="panel p-4 p-lg-5 text-center">
      <span class="eyebrow d-inline-flex">Start small</span>
      <h2 class="display-6 mt-2">Build one real thing.</h2>
      <p class="lead mx-auto max-55">Join the pilot, choose a starting point and take the next practical step. The platform is designed to grow with the community, not to pretend it is already finished.</p>
      <div class="d-flex flex-wrap justify-content-center gap-2 mt-4">
        <a class="btn btn-gold btn-lg" href="<?= e(url('pages/register.php')) ?>">Join the pilot</a>
        <a class="btn btn-outline-brown btn-lg" href="<?= e(url('pages/pilot.php')) ?>">Tell us you are interested</a>
      </div>
    </div>
  </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>

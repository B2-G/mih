<?php
/**
 * Mindset Innovators Hub - central configuration.
 *
 * Change the database settings and debug flag here. The base URL is
 * detected automatically so the app works whether it sits in
 * htdocs/mindset-innovators-hub, htdocs/mih or at the web root.
 *
 * Keep real credentials out of version control. Copy
 * config.example.php to config.php on a new machine.
 */

declare(strict_types=1);

// ---------------------------------------------------------------------
// Database (default XAMPP settings)
// ---------------------------------------------------------------------
define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_NAME', 'amtechna_mindset_innovators_hub');
define('DB_USER', 'amtechna_mindset_innovators_hub');
define('DB_PASS', 'HazyjF64cKcrCTHKTk9h');          // XAMPP's default root password is empty
define('DB_CHARSET', 'utf8mb4');

// ---------------------------------------------------------------------
// Application
// ---------------------------------------------------------------------
define('APP_NAME', 'Mindset Innovators Hub');
define('APP_TAGLINE', 'Where Potential Becomes Possibility.');
define('CONTACT_EMAIL', 'Mindsetinovators@gmail.com');
define('APP_DEBUG', false);     // show reset/verification links and errors on screen

// Absolute filesystem path of the project root
define('ROOT_PATH', dirname(__DIR__));

// Public base path, e.g. "/mih/" (auto-detected).
$projectRoot = str_replace('\\', '/', ROOT_PATH);
$docRoot = isset($_SERVER['DOCUMENT_ROOT']) ? str_replace('\\', '/', realpath($_SERVER['DOCUMENT_ROOT']) ?: $_SERVER['DOCUMENT_ROOT']) : '';
$basePath = ($docRoot !== '' && strpos($projectRoot, $docRoot) === 0)
    ? substr($projectRoot, strlen($docRoot))
    : '';
define('BASE_URL', rtrim($basePath, '/') . '/');

// ---------------------------------------------------------------------
// Uploads and listings
// ---------------------------------------------------------------------
define('UPLOAD_PATH', ROOT_PATH . '/assets/uploads');
define('UPLOAD_URL', 'assets/uploads/');
define('MAX_IMAGE_BYTES', 3 * 1024 * 1024);   // 3 MB
define('MAX_FILE_BYTES', 5 * 1024 * 1024);    // 5 MB
define('PER_PAGE', 9);

// Session lifetime in seconds (30 minutes of inactivity)
define('SESSION_TIMEOUT', 1800);

// Password reset / email verification link lifetime (1 hour)
define('TOKEN_TTL', 3600);

date_default_timezone_set('Africa/Lagos');

// Error handling: friendly messages, detailed log. Never print raw errors
// to visitors when APP_DEBUG is false.
error_reporting(E_ALL);
ini_set('display_errors', APP_DEBUG ? '1' : '0');
ini_set('log_errors', '1');
ini_set('error_log', ROOT_PATH . '/storage/php-error.log');

<?php
/**
 * Copy this file to config.php and adjust for your machine.
 * Never commit real credentials.
 */
define('DB_HOST', '127.0.0.1');
define('DB_PORT', '3306');
define('DB_NAME', 'mindset_innovators_hub');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

define('APP_NAME', 'Mindset Innovators Hub');
define('APP_TAGLINE', 'Where Potential Becomes Possibility.');
define('CONTACT_EMAIL', 'Mindsetinovators@gmail.com');
define('APP_DEBUG', false);

define('ROOT_PATH', dirname(__DIR__));
$projectRoot = str_replace('\\', '/', ROOT_PATH);
$docRoot = isset($_SERVER['DOCUMENT_ROOT']) ? str_replace('\\', '/', realpath($_SERVER['DOCUMENT_ROOT']) ?: $_SERVER['DOCUMENT_ROOT']) : '';
$basePath = ($docRoot !== '' && strpos($projectRoot, $docRoot) === 0) ? substr($projectRoot, strlen($docRoot)) : '';
define('BASE_URL', rtrim($basePath, '/') . '/');

define('UPLOAD_PATH', ROOT_PATH . '/assets/uploads');
define('UPLOAD_URL', 'assets/uploads/');
define('MAX_IMAGE_BYTES', 3 * 1024 * 1024);
define('MAX_FILE_BYTES', 5 * 1024 * 1024);
define('PER_PAGE', 9);
define('SESSION_TIMEOUT', 1800);
define('TOKEN_TTL', 3600);

date_default_timezone_set('Africa/Lagos');
error_reporting(E_ALL);
ini_set('display_errors', APP_DEBUG ? '1' : '0');
ini_set('log_errors', '1');
ini_set('error_log', ROOT_PATH . '/storage/php-error.log');

<?php
/**
 * Shared application helpers.
 * Small, documented functions used by every page.
 */

declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';

// ---------------------------------------------------------------------
// Output, URLs and navigation
// ---------------------------------------------------------------------

/** Escape any value for safe HTML output (XSS protection). */
function e($value): string
{
    return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/** Build a URL inside the application. */
function url(string $path = ''): string
{
    return BASE_URL . ltrim($path, '/');
}

/** Build an asset URL. */
function asset(string $path): string
{
    return BASE_URL . 'assets/' . ltrim($path, '/');
}

/** Redirect and stop. */
function redirect(string $path): void
{
    header('Location: ' . (preg_match('~^https?://~i', $path) ? $path : url($path)));
    exit;
}

/** Redirect back to the referring page, or a fallback. */
function redirect_back(string $fallback = 'index.php'): void
{
    $ref = $_SERVER['HTTP_REFERER'] ?? '';
    // Only allow same-site referrers
    if ($ref !== '' && strpos($ref, BASE_URL) === 0) {
        header('Location: ' . $ref);
        exit;
    }
    redirect($fallback);
}

/** Set a one-time flash message. */
function flash(string $type, string $message): void
{
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
}

/** Read and clear flash messages. */
function get_flashes(): array
{
    $items = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $items;
}

// ---------------------------------------------------------------------
// Request input
// ---------------------------------------------------------------------

function is_post(): bool
{
    return ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST';
}

/** Trimmed POST value. */
function post(string $key, string $default = ''): string
{
    $v = $_POST[$key] ?? $default;
    if (is_array($v)) {
        return $default;
    }
    return trim((string) $v);
}

/** Trimmed GET value. */
function get(string $key, string $default = ''): string
{
    $v = $_GET[$key] ?? $default;
    if (is_array($v)) {
        return $default;
    }
    return trim((string) $v);
}

/** Integer query parameter. */
function get_int(string $key, int $default = 0): int
{
    return max(0, (int) get($key, (string) $default));
}

function client_ip(): string
{
    return substr($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0', 0, 45);
}

// ---------------------------------------------------------------------
// Dates, text and display helpers
// ---------------------------------------------------------------------

function format_date(?string $date, string $format = 'j M Y'): string
{
    if (!$date) {
        return '—';
    }
    $ts = strtotime($date);
    return $ts ? date($format, $ts) : '—';
}

function format_datetime(?string $date): string
{
    return format_date($date, 'j M Y, g:ia');
}

function time_ago(?string $date): string
{
    if (!$date) {
        return '';
    }
    $ts = strtotime($date);
    if (!$ts) {
        return '';
    }
    $diff = time() - $ts;
    if ($diff < 60) {
        return 'just now';
    }
    if ($diff < 3600) {
        return floor($diff / 60) . ' min ago';
    }
    if ($diff < 86400) {
        return floor($diff / 3600) . ' hr ago';
    }
    if ($diff < 604800) {
        return floor($diff / 86400) . ' day' . (floor($diff / 86400) === 1.0 ? '' : 's') . ' ago';
    }
    return format_date($date);
}

function initials(string $name): string
{
    $parts = preg_split('/\s+/', trim($name)) ?: [];
    $out = '';
    foreach (array_slice($parts, 0, 2) as $p) {
        $out .= strtoupper(substr($p, 0, 1));
    }
    return $out !== '' ? $out : 'MI';
}

/** Avatar: uploaded photo if present, otherwise a gold initials circle. */
function avatar_html(?array $user, ?array $profile, string $size = 'md'): string
{
    $name = $user['name'] ?? 'Member';
    $photo = $profile['photo'] ?? null;
    if ($photo) {
        return '<img src="' . e(url($photo)) . '" alt="Profile photo of ' . e($name)
            . '" class="avatar avatar-' . e($size) . ' rounded-circle object-fit-cover">';
    }
    return '<span class="avatar avatar-' . e($size) . ' avatar-initials rounded-circle" aria-hidden="true">'
        . e(initials($name)) . '</span>';
}

/** Logo: prefer assets/img/logo.png, fall back to the generated SVG. */
function logo_url(): string
{
    $png = ROOT_PATH . '/assets/img/logo.png';
    return asset($png && file_exists($png) ? 'img/logo.png' : 'img/logo.svg');
}

/** Badge shown for all rows (no demo distinction). */
function demo_badge($isDemo, string $label = ''): string
{
    return '';
}

/** Trim plain text for cards. */
function excerpt(string $text, int $length = 150): string
{
    $plain = trim(preg_replace('/\s+/', ' ', strip_tags($text)) ?? '');
    if (mb_strlen($plain) <= $length) {
        return $plain;
    }
    return mb_substr($plain, 0, $length - 1) . '…';
}

function role_label(string $role): string
{
    return ucfirst($role);
}

function status_badge(string $status): string
{
    $map = [
        'active' => 'success', 'pending' => 'warning', 'suspended' => 'danger',
        'joined' => 'info', 'submitted' => 'primary', 'reviewed' => 'info', 'completed' => 'success',
        'draft' => 'secondary', 'published' => 'success', 'closed' => 'secondary',
        'accepted' => 'success', 'declined' => 'danger', 'interested' => 'warning',
        'in_discussion' => 'info', 'matched' => 'success', 'approved' => 'success',
        'rejected' => 'danger', 'open' => 'warning', 'resolved' => 'secondary',
    ];
    $colour = $map[$status] ?? 'secondary';
    return '<span class="badge text-bg-' . $colour . '">' . e(ucfirst(str_replace('_', ' ', $status))) . '</span>';
}

/** Parse comma-separated tags into a clean array. */
function tags_to_array(?string $text, int $max = 12): array
{
    if (!$text) {
        return [];
    }
    $parts = preg_split('/[,;]+/', $text) ?: [];
    $out = [];
    foreach ($parts as $p) {
        $p = trim(strip_tags($p));
        if ($p !== '' && !in_array($p, $out, true)) {
            $out[] = mb_substr($p, 0, 40);
        }
    }
    return array_slice($out, 0, $max);
}

function tags_from_array(array $tags): string
{
    return implode(', ', $tags);
}

// ---------------------------------------------------------------------
// Journey tracker
// ---------------------------------------------------------------------

function journey_stages(): array
{
    return [
        'Discover' => 'Explore your interests and strengths',
        'Learn' => 'Build practical knowledge',
        'Practise' => 'Apply what you learn with guidance',
        'Build' => 'Create something real, often with a team',
        'Showcase' => 'Present your work and evidence',
        'Advance' => 'Connect with mentors and opportunities',
    ];
}

function stage_index(?string $stage): int
{
    $i = array_search($stage, array_keys(journey_stages()), true);
    return $i === false ? 0 : (int) $i;
}

function journey_percent(?string $stage): int
{
    return (int) round((stage_index($stage) + 1) / 6 * 100);
}

/** Move a member forward on the journey (never backwards automatically). */
function advance_stage(int $userId, string $stage): void
{
    if (!array_key_exists($stage, journey_stages())) {
        return;
    }
    $current = db_one('SELECT journey_stage FROM profiles WHERE user_id = ?', [$userId]);
    if (!$current) {
        return;
    }
    if (stage_index($stage) > stage_index($current['journey_stage'])) {
        db_run('UPDATE profiles SET journey_stage = ? WHERE user_id = ?', [$stage, $userId]);
        log_activity('journey.advanced', 'profile', $userId, 'Moved to ' . $stage, $userId);
    }
}

function journey_tracker(?string $stage, bool $compact = false): string
{
    $stages = journey_stages();
    $current = stage_index($stage);
    $html = '<div class="journey-tracker' . ($compact ? ' journey-compact' : '') . '" role="list" aria-label="Journey progress">';
    $i = 0;
    foreach ($stages as $name => $desc) {
        $state = $i < $current ? 'done' : ($i === $current ? 'current' : 'todo');
        $html .= '<div class="journey-step is-' . $state . '" role="listitem" title="' . e($desc) . '">';
        $html .= '<span class="journey-dot">' . ($state === 'done' ? '<i class="bi bi-check-lg"></i>' : $i + 1) . '</span>';
        if (!$compact) {
            $html .= '<span class="journey-name">' . e($name) . '</span>';
        }
        $html .= '</div>';
        $i++;
    }
    $html .= '</div>';
    return $html;
}

// ---------------------------------------------------------------------
// Notifications, badges and activity
// ---------------------------------------------------------------------

function notify(int $userId, string $type, string $body, ?string $link = null): void
{
    db_run(
        'INSERT INTO notifications (user_id, type, body, link) VALUES (?, ?, ?, ?)',
        [$userId, substr($type, 0, 40), mb_substr($body, 0, 300), $link]
    );
}

function notify_admins(string $type, string $body, ?string $link = null): void
{
    $admins = db_all("SELECT id FROM users WHERE role = 'admin' AND status = 'active'");
    foreach ($admins as $admin) {
        notify((int) $admin['id'], $type, $body, $link);
    }
}

/**
 * XAMPP has no mail server, so email is simulated: the message is appended
 * to storage/mail.log. When APP_DEBUG is true a copy of the link is also
 * queued for display in the interface (never shown in production).
 */
function simulated_mail(string $to, string $subject, string $body, ?string $debugLink = null): void
{
    $line = str_repeat('=', 70) . "\n"
        . 'Date: ' . date('c') . "\n"
        . 'To: ' . $to . "\n"
        . 'Subject: ' . $subject . "\n\n"
        . $body . "\n\n";
    @file_put_contents(ROOT_PATH . '/storage/mail.log', $line, FILE_APPEND | LOCK_EX);
    log_activity('mail.simulated', 'mail', null, $to . ' — ' . $subject);
    if (APP_DEBUG) {
        $_SESSION['debug_mail'][] = ['to' => $to, 'subject' => $subject, 'link' => $debugLink];
    }
}

function unread_notifications_count(?int $userId = null): int
{
    if (!$userId) {
        return 0;
    }
    static $cache = [];
    if (!isset($cache[$userId])) {
        $cache[$userId] = db_count('SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0', [$userId]);
    }
    return $cache[$userId];
}

function log_activity(string $action, ?string $entityType = null, ?int $entityId = null, ?string $meta = null, ?int $userId = null): void
{
    $uid = $userId ?? (int) ($_SESSION['user_id'] ?? 0);
    db_run(
        'INSERT INTO activity_log (user_id, action, entity_type, entity_id, meta, ip) VALUES (?, ?, ?, ?, ?, ?)',
        [$uid > 0 ? $uid : null, substr($action, 0, 80), $entityType, $entityId, $meta, client_ip()]
    );
}

/** Award a badge once; returns true if it was newly awarded. */
function award_badge(int $userId, string $slug): bool
{
    $badge = db_one('SELECT * FROM badges WHERE slug = ?', [$slug]);
    if (!$badge) {
        return false;
    }
    $exists = db_count('SELECT COUNT(*) FROM user_badges WHERE user_id = ? AND badge_id = ?', [$userId, (int) $badge['id']]);
    if ($exists) {
        return false;
    }
    db_run('INSERT INTO user_badges (user_id, badge_id) VALUES (?, ?)', [$userId, (int) $badge['id']]);
    notify($userId, 'badge', 'You earned the ' . $badge['name'] . ' badge.', 'pages/portfolio.php?u=' . urlencode((string) user_username($userId)));
    log_activity('badge.awarded', 'badge', (int) $badge['id'], $badge['name'], $userId);
    return true;
}

/** Re-check all automatic badges for a member. */
function refresh_badges(int $userId): void
{
    if (db_count('SELECT COUNT(*) FROM submissions WHERE user_id = ?', [$userId]) > 0) {
        award_badge($userId, 'first-submission');
    }
    if (db_count('SELECT COUNT(*) FROM team_members WHERE user_id = ?', [$userId]) > 0) {
        award_badge($userId, 'team-player');
    }
    if (db_count("SELECT COUNT(*) FROM projects WHERE user_id = ? AND status = 'published'", [$userId]) > 0) {
        award_badge($userId, 'portfolio-builder');
    }
    if (db_count("SELECT COUNT(*) FROM submissions WHERE user_id = ? AND status = 'completed'", [$userId]) > 0) {
        award_badge($userId, 'challenge-finisher');
    }
}

function user_username(int $userId): string
{
    static $cache = [];
    if (!isset($cache[$userId])) {
        $u = db_one('SELECT username FROM users WHERE id = ?', [$userId]);
        $cache[$userId] = $u['username'] ?? '';
    }
    return $cache[$userId];
}

// ---------------------------------------------------------------------
// Rooms
// ---------------------------------------------------------------------

function can_access_room(array $room, ?array $user = null): bool
{
    if (!$user) {
        return false;
    }
    if ($room['type'] === 'public') {
        return true;
    }
    if ($user['role'] === 'admin') {
        return true;
    }
    if ($room['type'] === 'team' && !empty($room['team_id'])) {
        return db_count('SELECT COUNT(*) FROM team_members WHERE team_id = ? AND user_id = ?', [(int) $room['team_id'], (int) $user['id']]) > 0;
    }
    return false;
}

function is_team_member(int $teamId, ?int $userId = null): bool
{
    $userId = $userId ?? (int) ($_SESSION['user_id'] ?? 0);
    return $userId > 0 && db_count('SELECT COUNT(*) FROM team_members WHERE team_id = ? AND user_id = ?', [$teamId, $userId]) > 0;
}

/**
 * Render one chat message. Used by the room page and the JSON endpoint so
 * both produce exactly the same markup.
 */
function chat_message_html(array $m, int $viewerId, bool $canModerate): string
{
    $own = (int) $m['user_id'] === $viewerId;
    $body = trim((string) $m['body']);
    $safeBody = nl2br(e($body), false);
    // Highlight @username mentions without allowing HTML injection.
    $safeBody = preg_replace_callback('/@([a-zA-Z0-9._-]{2,30})/', static function (array $hit): string {
        return '<span class="mention">@' . e($hit[1]) . '</span>';
    }, $safeBody) ?? $safeBody;

    $html = '<div class="chat-message' . ($own ? ' is-own' : '') . '" data-message-id="' . (int) $m['id'] . '">';
    $html .= avatar_html(['name' => $m['name']], ['photo' => $m['photo'] ?? null], 'sm');
    $html .= '<div class="chat-bubble">';
    $html .= '<div class="chat-meta"><strong>' . e($m['name']) . '</strong>' . demo_badge($m['is_demo'] ?? 0)
        . '<span>' . e(time_ago($m['created_at'])) . '</span></div>';
    $html .= '<div class="chat-body"><p>' . $safeBody . '</p></div>';
    $html .= '<div class="chat-actions d-flex gap-2 mt-1">';
    if ($own || $canModerate) {
        $html .= '<button type="button" class="btn btn-link btn-sm p-0 text-danger" data-chat-delete="' . (int) $m['id'] . '">Delete</button>';
    }
    if (!$own) {
        $html .= '<button type="button" class="btn btn-link btn-sm p-0 text-muted" data-chat-report="' . (int) $m['id'] . '">Report</button>';
    }
    $html .= '</div></div></div>';
    return $html;
}

// ---------------------------------------------------------------------
// Profile completeness
// ---------------------------------------------------------------------

/** Returns [percent, missing_labels[]]. */
function profile_completeness(int $userId): array
{
    $profile = db_one('SELECT * FROM profiles WHERE user_id = ?', [$userId]);
    if (!$profile) {
        return [0, ['Profile not created']];
    }
    $skillCount = db_count('SELECT COUNT(*) FROM user_skills WHERE user_id = ?', [$userId]);
    $checks = [
        'Profile photo' => !empty($profile['photo']),
        'Headline' => !empty($profile['headline']),
        'Short bio' => !empty($profile['bio']),
        'Location' => !empty($profile['location']),
        'Interests' => !empty($profile['interests']),
        'At least 2 skills' => $skillCount >= 2,
        'Goals' => !empty($profile['goals']),
        'A link' => !empty($profile['website']) || !empty($profile['linkedin']) || !empty($profile['github']),
        'Onboarding quiz' => !empty($profile['quiz_completed']),
    ];
    $done = 0;
    $missing = [];
    foreach ($checks as $label => $ok) {
        if ($ok) {
            $done++;
        } else {
            $missing[] = $label;
        }
    }
    return [(int) round($done / count($checks) * 100), $missing];
}

// ---------------------------------------------------------------------
// Pagination
// ---------------------------------------------------------------------

function current_page_number(): int
{
    return max(1, (int) ($_GET['page'] ?? 1));
}

function pagination(int $total, int $page, int $perPage, array $params = []): string
{
    $pages = max(1, (int) ceil($total / $perPage));
    if ($pages <= 1) {
        return '';
    }
    $page = min(max(1, $page), $pages);
    unset($params['page']);
    $makeUrl = static function (int $n) use ($params): string {
        $params['page'] = $n;
        return '?' . http_build_query($params);
    };
    $html = '<nav aria-label="Pagination"><ul class="pagination justify-content-center mt-4">';
    $html .= '<li class="page-item' . ($page <= 1 ? ' disabled' : '') . '"><a class="page-link" href="'
        . e($makeUrl(max(1, $page - 1))) . '">Previous</a></li>';
    $start = max(1, $page - 2);
    $end = min($pages, $page + 2);
    if ($start > 1) {
        $html .= '<li class="page-item"><a class="page-link" href="' . e($makeUrl(1)) . '">1</a></li>';
        if ($start > 2) {
            $html .= '<li class="page-item disabled"><span class="page-link">…</span></li>';
        }
    }
    for ($i = $start; $i <= $end; $i++) {
        $html .= '<li class="page-item' . ($i === $page ? ' active' : '') . '"><a class="page-link" href="'
            . e($makeUrl($i)) . '">' . $i . '</a></li>';
    }
    if ($end < $pages) {
        if ($end < $pages - 1) {
            $html .= '<li class="page-item disabled"><span class="page-link">…</span></li>';
        }
        $html .= '<li class="page-item"><a class="page-link" href="' . e($makeUrl($pages)) . '">' . $pages . '</a></li>';
    }
    $html .= '<li class="page-item' . ($page >= $pages ? ' disabled' : '') . '"><a class="page-link" href="'
        . e($makeUrl(min($pages, $page + 1))) . '">Next</a></li>';
    $html .= '</ul></nav>';
    return $html;
}

// ---------------------------------------------------------------------
// Uploads
// ---------------------------------------------------------------------

/**
 * Validate and store an uploaded file.
 * We check the extension, the real MIME type (finfo), the size and use a
 * random filename. Uploads live outside PHP execution (.htaccess denies it).
 *
 * @return string|null relative path from project root, e.g. assets/uploads/abc.jpg
 */
function save_upload(string $field, string $kind = 'image', string $subdir = ''): ?string
{
    if (empty($_FILES[$field]) || ($_FILES[$field]['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
        return null;
    }
    $file = $_FILES[$field];
    if (($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) {
        throw new RuntimeException('The upload failed. Please try a smaller file.');
    }
    $max = $kind === 'image' ? MAX_IMAGE_BYTES : MAX_FILE_BYTES;
    if ((int) $file['size'] > $max) {
        throw new RuntimeException('The file is too large. Maximum size is ' . round($max / 1048576) . ' MB.');
    }
    $allowed = $kind === 'image'
        ? ['jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp']
        : ['jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp',
           'pdf' => 'application/pdf', 'zip' => 'application/zip', 'txt' => 'text/plain'];
    $ext = strtolower(pathinfo((string) $file['name'], PATHINFO_EXTENSION));
    if (!isset($allowed[$ext])) {
        throw new RuntimeException('That file type is not allowed. Allowed: ' . implode(', ', array_keys($allowed)) . '.');
    }
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file((string) $file['tmp_name']);
    $validMimes = array_values(array_unique(array_merge([$allowed[$ext]], $kind === 'image' ? [] : ['application/octet-stream', 'application/x-zip-compressed'])));
    if (!in_array($mime, $validMimes, true)) {
        throw new RuntimeException('The file content does not match its extension.');
    }
    $dir = UPLOAD_PATH . ($subdir !== '' ? '/' . trim($subdir, '/') : '');
    if (!is_dir($dir) && !mkdir($dir, 0775, true)) {
        throw new RuntimeException('The upload folder is not writable.');
    }
    $name = bin2hex(random_bytes(16)) . '.' . $ext;
    if (!move_uploaded_file((string) $file['tmp_name'], $dir . '/' . $name)) {
        throw new RuntimeException('Could not save the uploaded file.');
    }
    return UPLOAD_URL . ($subdir !== '' ? trim($subdir, '/') . '/' : '') . $name;
}

function remove_upload(?string $relative): void
{
    if (!$relative || strpos($relative, 'assets/uploads/') !== 0) {
        return;
    }
    $full = ROOT_PATH . '/' . $relative;
    if (is_file($full)) {
        @unlink($full);
    }
}

// ---------------------------------------------------------------------
// Rate limiting
// ---------------------------------------------------------------------

/** Returns true when the action is allowed (and records it). */
function rate_limit_hit(string $action, int $limit, int $minutes): bool
{
    $ip = client_ip();
    $since = date('Y-m-d H:i:s', time() - $minutes * 60);
    $count = db_count('SELECT COUNT(*) FROM rate_limits WHERE action = ? AND ip = ? AND created_at >= ?', [$action, $ip, $since]);
    if ($count >= $limit) {
        return false;
    }
    db_run('INSERT INTO rate_limits (action, ip) VALUES (?, ?)', [$action, $ip]);
    // Light housekeeping: keep the table small.
    if (random_int(1, 20) === 1) {
        db_run('DELETE FROM rate_limits WHERE created_at < ?', [date('Y-m-d H:i:s', time() - 86400)]);
    }
    return true;
}

function login_rate_limited(string $email): bool
{
    $ip = client_ip();
    $since = date('Y-m-d H:i:s', time() - 15 * 60);
    $byIp = db_count('SELECT COUNT(*) FROM login_attempts WHERE ip = ? AND success = 0 AND created_at >= ?', [$ip, $since]);
    $byEmail = db_count('SELECT COUNT(*) FROM login_attempts WHERE email = ? AND success = 0 AND created_at >= ?', [$email, $since]);
    return $byIp >= 8 || $byEmail >= 5;
}

function record_login_attempt(string $email, bool $success): void
{
    db_run('INSERT INTO login_attempts (email, ip, success) VALUES (?, ?, ?)', [$email, client_ip(), $success ? 1 : 0]);
}

// ---------------------------------------------------------------------
// Validation helpers
// ---------------------------------------------------------------------

function valid_email(string $email): bool
{
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function valid_url(?string $url): bool
{
    if ($url === null || $url === '') {
        return true;
    }
    return filter_var($url, FILTER_VALIDATE_URL) !== false && preg_match('~^https?://~i', $url) === 1;
}

function valid_username(string $username): bool
{
    return preg_match('/^[a-zA-Z0-9._-]{3,30}$/', $username) === 1;
}

/** Render a field error paragraph. */
function field_error(array $errors, string $key): string
{
    return isset($errors[$key])
        ? '<div class="invalid-feedback d-block">' . e($errors[$key]) . '</div>'
        : '';
}

/** Render a list of validation errors. */
function error_summary(array $errors): string
{
    if (!$errors) {
        return '';
    }
    $html = '<div class="alert alert-danger" role="alert"><p class="fw-semibold mb-1">Please fix the following:</p><ul class="mb-0">';
    foreach ($errors as $error) {
        $html .= '<li>' . e($error) . '</li>';
    }
    return $html . '</ul></div>';
}

/** Central 404. */
function not_found(string $message = 'The page or item you are looking for does not exist.'): void
{
    http_response_code(404);
    $page_title = 'Not found';
    $page_description = $message;
    require ROOT_PATH . '/includes/header.php';
    echo '<div class="container section-pad text-center"><div class="empty-state mx-auto">'
        . '<i class="bi bi-compass display-4 text-gold"></i><h1 class="h3 mt-3">Not found</h1><p class="text-muted">'
        . e($message) . '</p><a class="btn btn-gold" href="' . url('index.php') . '">Back to home</a></div></div>';
    require ROOT_PATH . '/includes/footer.php';
    exit;
}

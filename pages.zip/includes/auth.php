<?php
/**
 * Sessions, authentication, role guards and small permission helpers.
 */

declare(strict_types=1);

require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/csrf.php';

function start_session(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    session_name('MIHSESSID');
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'secure'   => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();

    // Session timeout
    if (!empty($_SESSION['user_id'])) {
        if (isset($_SESSION['last_activity']) && (time() - (int) $_SESSION['last_activity']) > SESSION_TIMEOUT) {
            $_SESSION = [];
            session_regenerate_id(true);
            $_SESSION['flash'][] = ['type' => 'warning', 'message' => 'You were signed out after 30 minutes of inactivity. Please sign in again.'];
        } else {
            $_SESSION['last_activity'] = time();
        }
    }
}

start_session();

/** The signed-in user with profile fields, or null. */
function current_user(): ?array
{
    static $user = false;
    if ($user !== false) {
        return $user;
    }
    if (empty($_SESSION['user_id'])) {
        $user = null;
        return null;
    }
    $row = db_one(
        "SELECT u.id, u.name, u.username, u.email, u.role, u.status, u.email_verified, u.is_demo,
                u.created_at AS member_since, p.headline, p.bio, p.location, p.interests, p.goals,
                p.website, p.linkedin, p.github, p.photo, p.journey_stage, p.privacy, p.quiz_completed,
                p.updated_at AS profile_updated_at
         FROM users u LEFT JOIN profiles p ON p.user_id = u.id
         WHERE u.id = ?",
        [(int) $_SESSION['user_id']]
    );
    if (!$row || $row['status'] === 'suspended') {
        $_SESSION = [];
        session_regenerate_id(true);
        $user = null;
        return null;
    }
    $user = $row;
    return $user;
}

function is_logged_in(): bool
{
    return current_user() !== null;
}

function user_id(): int
{
    return (int) (current_user()['id'] ?? 0);
}

function user_role(): string
{
    return (string) (current_user()['role'] ?? 'guest');
}

function is_admin(): bool
{
    return user_role() === 'admin';
}

function is_member(): bool
{
    return user_role() === 'member';
}

function is_mentor(): bool
{
    return user_role() === 'mentor';
}

function is_partner(): bool
{
    return user_role() === 'partner';
}

/** Admin, mentor or partner can create challenges. */
function can_create_challenges(): bool
{
    return in_array(user_role(), ['admin', 'mentor', 'partner'], true);
}

/** Admin or mentor can review submissions. */
function can_review(): bool
{
    return in_array(user_role(), ['admin', 'mentor'], true);
}

function login_user(int $id): void
{
    session_regenerate_id(true);
    $_SESSION['user_id'] = $id;
    $_SESSION['last_activity'] = time();
    unset($_SESSION['csrf_token']); // issue a fresh token for the new session
    db_run('UPDATE users SET last_login_at = NOW() WHERE id = ?', [$id]);
    $u = db_one('SELECT name, role FROM users WHERE id = ?', [$id]);
    log_activity('auth.login', 'user', $id, null, $id);
    if ($u) {
        flash('success', 'Welcome back, ' . $u['name'] . '.');
    }
}

function logout_user(): void
{
    $id = (int) ($_SESSION['user_id'] ?? 0);
    if ($id) {
        log_activity('auth.logout', 'user', $id, null, $id);
    }
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
}

/** A safe internal "next" path for post-login redirects. */
function safe_next(?string $next): string
{
    $next = (string) $next;
    if ($next === '' || strpos($next, '//') === 0 || preg_match('~^https?://~i', $next)) {
        return 'index.php';
    }
    return ltrim($next, '/');
}

function require_login(): void
{
    if (!is_logged_in()) {
        $next = $_SERVER['REQUEST_URI'] ?? '';
        // Convert /mih/pages/x.php to pages/x.php for a clean relative redirect.
        $prefix = rtrim(BASE_URL, '/');
        if ($prefix !== '' && strpos($next, $prefix) === 0) {
            $next = substr($next, strlen($prefix));
        }
        flash('warning', 'Please sign in to continue.');
        redirect('pages/login.php?next=' . urlencode(ltrim($next, '/')));
    }
}

/** @param string|array $roles */
function require_role($roles): void
{
    require_login();
    $roles = (array) $roles;
    if (!in_array(user_role(), $roles, true)) {
        forbidden('Your account does not have access to this area.');
    }
}

function redirect_after_login(): string
{
    $map = [
        'admin'   => 'admin/index.php',
        'mentor'  => 'pages/mentor-dashboard.php',
        'partner' => 'pages/partner-dashboard.php',
        'member'  => 'pages/dashboard.php',
    ];
    return $map[user_role()] ?? 'pages/dashboard.php';
}

/** 403 page. */
function forbidden(string $message = 'You do not have permission to view this page.'): void
{
    http_response_code(403);
    $page_title = 'Access denied';
    require ROOT_PATH . '/includes/header.php';
    echo '<div class="container section-pad text-center"><div class="empty-state mx-auto">'
        . '<i class="bi bi-shield-lock display-4 text-gold"></i><h1 class="h3 mt-3">Access denied</h1>'
        . '<p class="text-muted">' . e($message) . '</p><a class="btn btn-gold" href="' . e(url(redirect_after_login())) . '">Go to my dashboard</a></div></div>';
    require ROOT_PATH . '/includes/footer.php';
    exit;
}

<?php
/**
 * Shared page header and navigation.
 * Set $page_title, $page_description, $active and optionally
 * $breadcrumbs before including this file.
 */

if (!defined('APP_NAME')) {
    require_once __DIR__ . '/init.php';
}

$page_title = $page_title ?? 'Home';
$page_description = $page_description ?? 'Mindset Innovators Hub helps young people turn ideas and potential into skills, projects and opportunities.';
$active = $active ?? '';
$user = current_user();
$navUser = $user;
$unread = $user ? unread_notifications_count((int) $user['id']) : 0;
$dashLink = $user ? redirect_after_login() : 'pages/login.php';
$isAdmin = is_admin();
$adminBadge = $isAdmin ? '<span class="badge bg-gold text-brown small ms-2">Prototype</span>' : '';
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($page_title) ?> · <?= e(APP_NAME) ?></title>
  <meta name="description" content="<?= e($page_description) ?>">
  <meta name="theme-color" content="#2E1A0F">
  <link rel="icon" type="image/svg+xml" href="<?= e(logo_url()) ?>">
  <link rel="stylesheet" href="<?= e(asset('vendor/bootstrap/bootstrap.min.css')) ?>">
  <link rel="stylesheet" href="<?= e(asset('vendor/bootstrap-icons/bootstrap-icons.min.css')) ?>">
  <link rel="stylesheet" href="<?= e(asset('css/theme.css')) ?>">
</head>
<body class="<?= e($body_class ?? '') ?>">
<a class="skip-link" href="#main-content">Skip to main content</a>

<nav class="navbar navbar-expand-lg navbar-dark site-navbar sticky-top" aria-label="Main navigation">
  <div class="container">
    <a class="navbar-brand d-flex align-items-center gap-2" href="<?= e(url('index.php')) ?>">
      <img src="<?= e(logo_url()) ?>" alt="" width="42" height="42" class="brand-logo">
      <span class="brand-text">
        <strong>Mindset Innovators Hub</strong>
        <small><?= e(APP_TAGLINE) ?></small>
      </span>
      <?= $adminBadge ?>
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav"
            aria-controls="mainNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="mainNav">
      <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-1">
        <li class="nav-item"><a class="nav-link <?= $active === 'home' ? 'active' : '' ?>" href="<?= e(url('index.php')) ?>">Home</a></li>
        <li class="nav-item"><a class="nav-link <?= $active === 'how' ? 'active' : '' ?>" href="<?= e(url('pages/how-it-works.php')) ?>">How it works</a></li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle <?= $active === 'explore' ? 'active' : '' ?>" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">Explore the Hub</a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="<?= e(url('pages/challenges.php')) ?>"><i class="bi bi-lightning-charge me-2"></i>Challenges</a></li>
            <li><a class="dropdown-item" href="<?= e(url('pages/showcase.php')) ?>"><i class="bi bi-collection me-2"></i>Showcase</a></li>
            <li><a class="dropdown-item" href="<?= e(url('pages/ideas.php')) ?>"><i class="bi bi-lightbulb me-2"></i>Idea Board</a></li>
            <li><a class="dropdown-item" href="<?= e(url('pages/rooms.php')) ?>"><i class="bi bi-chat-square-text me-2"></i>Collaboration Rooms</a></li>
            <li><a class="dropdown-item" href="<?= e(url('pages/mentors.php')) ?>"><i class="bi bi-person-check me-2"></i>Mentors</a></li>
            <li><a class="dropdown-item" href="<?= e(url('pages/opportunities.php')) ?>"><i class="bi bi-compass me-2"></i>Opportunities</a></li>
            <li><a class="dropdown-item" href="<?= e(url('pages/directory.php')) ?>"><i class="bi bi-people me-2"></i>Member Directory</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="<?= e(url('pages/leaderboard.php')) ?>"><i class="bi bi-graph-up-arrow me-2"></i>Leaderboard</a></li>
          </ul>
        </li>
        <li class="nav-item"><a class="nav-link <?= $active === 'partners' ? 'active' : '' ?>" href="<?= e(url('pages/partners.php')) ?>">For partners</a></li>
        <li class="nav-item"><a class="nav-link <?= $active === 'about' ? 'active' : '' ?>" href="<?= e(url('pages/about.php')) ?>">About</a></li>
        <li class="nav-item"><a class="nav-link <?= $active === 'contact' ? 'active' : '' ?>" href="<?= e(url('pages/contact.php')) ?>">Contact</a></li>
      </ul>

      <div class="d-flex align-items-center gap-2 mt-3 mt-lg-0 ms-lg-3">
        <?php if ($user): ?>
          <a class="btn btn-sm btn-outline-light position-relative" href="<?= e(url('pages/notifications.php')) ?>" aria-label="Notifications<?= $unread ? ', ' . $unread . ' unread' : '' ?>">
            <i class="bi bi-bell"></i>
            <?php if ($unread > 0): ?><span class="notification-dot"><?= $unread > 9 ? '9+' : $unread ?></span><?php endif; ?>
          </a>
          <div class="dropdown">
            <button class="btn btn-sm user-menu dropdown-toggle d-flex align-items-center gap-2" type="button" data-bs-toggle="dropdown" aria-expanded="false">
              <?= avatar_html($navUser, $navUser, 'xs') ?>
              <span><?= e(explode(' ', $navUser['name'])[0]) ?></span>
            </button>
            <ul class="dropdown-menu dropdown-menu-end">
              <li><span class="dropdown-item-text small text-muted"><?= e($navUser['name']) ?> · <?= e(role_label($navUser['role'])) ?></span></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="<?= e(url($dashLink)) ?>"><i class="bi bi-speedometer2 me-2"></i>Dashboard</a></li>
              <li><a class="dropdown-item" href="<?= e(url('pages/profile.php')) ?>"><i class="bi bi-person me-2"></i>My profile</a></li>
              <li><a class="dropdown-item" href="<?= e(url('pages/portfolio.php')) ?>"><i class="bi bi-collection me-2"></i>My portfolio</a></li>
              <li><a class="dropdown-item" href="<?= e(url('pages/notifications.php')) ?>"><i class="bi bi-bell me-2"></i>Notifications<?= $unread ? ' (' . $unread . ')' : '' ?></a></li>
              <?php if (is_admin()): ?>
                <li><a class="dropdown-item" href="<?= e(url('admin/index.php')) ?>"><i class="bi bi-shield-lock me-2"></i>Admin area</a></li>
              <?php endif; ?>
              <li><hr class="dropdown-divider"></li>
              <li>
                <form method="post" action="<?= e(url('pages/logout.php')) ?>">
                  <?= csrf_field() ?>
                  <button class="dropdown-item text-danger" type="submit"><i class="bi bi-box-arrow-right me-2"></i>Sign out</button>
                </form>
              </li>
            </ul>
          </div>
        <?php else: ?>
          <a class="btn btn-sm btn-outline-light" href="<?= e(url('pages/login.php')) ?>">Sign in</a>
          <a class="btn btn-sm btn-gold" href="<?= e(url('pages/register.php')) ?>">Join the pilot</a>
        <?php endif; ?>
      </div>
    </div>
  </div>
</nav>

<?php if (!empty($breadcrumbs)): ?>
  <div class="breadcrumb-bar">
    <div class="container">
      <nav aria-label="Breadcrumb">
        <ol class="breadcrumb mb-0">
          <li class="breadcrumb-item"><a href="<?= e(url('index.php')) ?>">Home</a></li>
          <?php foreach ($breadcrumbs as $i => $crumb): ?>
            <?php if (!empty($crumb[1]) && $i < count($breadcrumbs) - 1): ?>
              <li class="breadcrumb-item"><a href="<?= e(url($crumb[1])) ?>"><?= e($crumb[0]) ?></a></li>
            <?php else: ?>
              <li class="breadcrumb-item active" aria-current="page"><?= e($crumb[0]) ?></li>
            <?php endif; ?>
          <?php endforeach; ?>
        </ol>
      </nav>
    </div>
  </div>
<?php endif; ?>

<?php if ($user && !$user['email_verified']): ?>
  <div class="alert alert-warning rounded-0 mb-0 small text-center py-2">
    <i class="bi bi-envelope-exclamation me-1"></i>
    Your email is not verified yet. <a href="<?= e(url('pages/verify.php')) ?>" class="alert-link">Verify or resend the link</a>.
  </div>
<?php endif; ?>

<?php
$flashes = get_flashes();
if ($flashes):
  $flashContainer = '<div class="container mt-3" aria-live="polite">';
  foreach ($flashes as $f):
    $flashContainer .= '<div class="alert alert-' . e($f['type']) . ' alert-dismissible fade show shadow-sm" role="alert">'
      . e($f['message'])
      . '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>';
  endforeach;
  echo $flashContainer . '</div>';
endif;

// APP_DEBUG only: show simulated email links so password reset can be tested.
if (APP_DEBUG && !empty($_SESSION['debug_mail'])):
  $mails = $_SESSION['debug_mail'];
  unset($_SESSION['debug_mail']);
?>
  <div class="container mt-3">
    <div class="alert alert-info small" role="note">
      <div class="fw-semibold mb-1"><i class="bi bi-bug me-1"></i>Debug mode: simulated email</div>
      <p class="mb-2">XAMPP has no mail server. These messages were written to <code>storage/mail.log</code> and are shown here only because <code>APP_DEBUG</code> is on.</p>
      <?php foreach ($mails as $m): ?>
        <div class="mb-1">To <strong><?= e($m['to']) ?></strong> — <?= e($m['subject']) ?>
          <?php if (!empty($m['link'])): ?> · <a href="<?= e($m['link']) ?>" class="alert-link">Open simulated link</a><?php endif; ?>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
<?php endif; ?>


<main id="main-content">

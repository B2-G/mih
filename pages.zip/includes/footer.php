<?php
/** Shared footer, prototype disclosure and scripts. */
?>
</main>

<footer class="site-footer mt-5">
  <div class="container py-5">
    <div class="row g-4">
      <div class="col-lg-4">
        <a class="d-inline-flex align-items-center gap-2 text-decoration-none mb-3" href="<?= e(url('index.php')) ?>">
          <img src="<?= e(logo_url()) ?>" alt="" width="44" height="44">
          <span class="h5 mb-0 text-cream">Mindset Innovators Hub</span>
        </a>
        <p class="text-cream-soft small mb-3"><?= e(APP_TAGLINE) ?> A community-driven innovation ecosystem for young people in Nigeria and across Africa.</p>
        <p class="small mb-2"><span class="badge badge-prototype"><i class="bi bi-cone-striped me-1"></i>Pilot prototype</span></p>
        <p class="text-cream-soft small mb-0">This is an early-stage working prototype, not a launched product. Demo records are labelled and all numbers are counted live from this prototype's database.</p>
      </div>
      <div class="col-6 col-lg-2">
        <h2 class="footer-heading">Explore</h2>
        <ul class="footer-links">
          <li><a href="<?= e(url('pages/challenges.php')) ?>">Challenges</a></li>
          <li><a href="<?= e(url('pages/showcase.php')) ?>">Showcase</a></li>
          <li><a href="<?= e(url('pages/ideas.php')) ?>">Idea Board</a></li>
          <li><a href="<?= e(url('pages/rooms.php')) ?>">Rooms</a></li>
          <li><a href="<?= e(url('pages/opportunities.php')) ?>">Opportunities</a></li>
        </ul>
      </div>
      <div class="col-6 col-lg-2">
        <h2 class="footer-heading">Community</h2>
        <ul class="footer-links">
          <li><a href="<?= e(url('pages/mentors.php')) ?>">Mentors</a></li>
          <li><a href="<?= e(url('pages/directory.php')) ?>">Member directory</a></li>
          <li><a href="<?= e(url('pages/leaderboard.php')) ?>">Leaderboard</a></li>
          <li><a href="<?= e(url('pages/pilot.php')) ?>">Join the pilot</a></li>
          <li><a href="<?= e(url('pages/partners.php')) ?>">For partners</a></li>
        </ul>
      </div>
      <div class="col-lg-4">
        <h2 class="footer-heading">Contact</h2>
        <p class="small mb-2"><i class="bi bi-envelope me-2 text-gold"></i><a href="mailto:<?= e(CONTACT_EMAIL) ?>"><?= e(CONTACT_EMAIL) ?></a></p>
        <p class="text-cream-soft small">For questions about the pilot, mentoring, or a partnership enquiry, use our <a href="<?= e(url('pages/contact.php')) ?>">contact form</a>.</p>
        <div class="d-flex gap-2 mt-3">
          <a class="social-link" href="<?= e(url('pages/about.php')) ?>" aria-label="About Mindset Innovators Hub"><i class="bi bi-info-circle"></i></a>
          <a class="social-link" href="<?= e(url('pages/how-it-works.php')) ?>" aria-label="How the hub works"><i class="bi bi-diagram-3"></i></a>
          <a class="social-link" href="<?= e(url('pages/pilot.php')) ?>" aria-label="Join the pilot"><i class="bi bi-rocket-takeoff"></i></a>
        </div>
      </div>
    </div>
    <hr class="border-cream my-4">
    <div class="d-flex flex-column flex-md-row justify-content-between gap-2 small text-cream-soft">
      <span>&copy; <?= date('Y') ?> Mindset Innovators Hub. Built as a prototype for learning and testing.</span>
      <span>Founder: Bintu Tijjani Goni · <a href="<?= e(url('pages/about.php')) ?>">About us</a></span>
    </div>
  </div>
</footer>

<script src="<?= e(asset('vendor/bootstrap/bootstrap.bundle.min.js')) ?>"></script>
<script src="<?= e(asset('js/app.js')) ?>"></script>
<?php if (!empty($use_chart)): ?>
  <script src="<?= e(asset('vendor/chartjs/chart.umd.min.js')) ?>"></script>
<?php endif; ?>
<?php if (!empty($page_scripts)): echo $page_scripts; endif; ?>
</body>
</html>

<?php
/**
 * CSRF protection for normal forms and AJAX requests.
 */

declare(strict_types=1);

function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

function verify_csrf(?string $token = null): bool
{
    $token = $token ?? (string) ($_POST['csrf_token'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''));
    return $token !== '' && !empty($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Stop the request when the CSRF token is missing or wrong.
 */
function require_csrf(bool $json = false): void
{
    if (verify_csrf()) {
        return;
    }
    http_response_code(419);
    if ($json) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok' => false, 'error' => 'Your session token expired. Please refresh the page.']);
        exit;
    }
    $page_title = 'Session expired';
    require ROOT_PATH . '/includes/header.php';
    echo '<div class="container section-pad text-center"><div class="empty-state mx-auto">'
        . '<i class="bi bi-shield-exclamation display-4 text-gold"></i><h1 class="h3 mt-3">Session expired</h1>'
        . '<p class="text-muted">For your security, this form could not be verified. Please go back, refresh the page and try again.</p>'
        . '<a class="btn btn-gold" href="' . e(url('index.php')) . '">Back to home</a></div></div>';
    require ROOT_PATH . '/includes/footer.php';
    exit;
}

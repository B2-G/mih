<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function json_out(array $payload, int $status = 200): void
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function fetch_message(int $messageId): ?array
{
    $row = db_one(
        'SELECT rm.*, u.name, u.username, u.is_demo, p.photo
         FROM room_messages rm JOIN users u ON u.id = rm.user_id LEFT JOIN profiles p ON p.user_id = u.id
         WHERE rm.id = ?',
        [$messageId]
    );
    return $row ?: null;
}

if (!is_logged_in()) {
    json_out(['ok' => false, 'error' => 'Please sign in again.'], 401);
}
$me = current_user();
$uid = (int) $me['id'];
$roomId = get_int('room_id') ?: (int) post('room_id');
$room = $roomId ? db_one('SELECT * FROM rooms WHERE id = ?', [$roomId]) : null;
if (!$room) {
    json_out(['ok' => false, 'error' => 'That room could not be found.'], 404);
}
if (!can_access_room($room, $me)) {
    json_out(['ok' => false, 'error' => 'You do not have access to this room.'], 403);
}
$canModerate = $me['role'] === 'admin';

// **NEW: Track recording status per user per room**
$isRecording = db_one(
    'SELECT 1 FROM room_recording WHERE room_id = ? AND user_id = ? LIMIT 1',
    [$roomId, $uid]
);
$recordings = [];
if ($isRecording) {
    $recordings = db_all(
        'SELECT user_id, started_at FROM room_recording WHERE room_id = ? ORDER BY started_at DESC',
        [$roomId]
    );
}

// **NEW: Task tracking for team members**
$tasks = [];
if ($room['type'] === 'team' && !empty($room['team_id'])) {
    $tasks = db_all(
        'SELECT * FROM team_tasks WHERE room_id = ? ORDER BY priority DESC, created_at ASC',
        [$roomId]
    );
}

// **NEW: Activity stats for chart**
$activityStats = db_one(
    'SELECT 
       COUNT(*) as total_messages,
       COUNT(DISTINCT user_id) as active_users,
       SUM(CASE WHEN is_system = 1 THEN 0 ELSE 1 END) as user_messages
     FROM room_messages WHERE room_id = ?',
    [$roomId]
);

$canModerate = $me['role'] === 'admin';

// **NEW: Get mentioned users from message body**
function getMentionedUsers(string $body, int $roomId, int $uid): array {
    $mentioned = [];
    if (preg_match_all('/@([a-zA-Z0-9._-]{3,30})/', $body, $matches)) {
        $usernames = array_slice(array_unique($matches[1]), 0, 3);
        foreach ($usernames as $username) {
            $mentionedUser = db_one('SELECT id, role FROM users WHERE username = ? AND status = "active"', [$username]);
            if (!$mentionedUser || (int) $mentionedUser['id'] === $uid) {
                continue;
            }
            $allowed = false;
            if ($room['type'] === 'public') {
                $allowed = true;
            } elseif (!empty($room['team_id'])) {
                $allowed = is_team_member((int) $room['team_id'], (int) $mentionedUser['id']) || $mentionedUser['role'] === 'admin';
            }
            if ($allowed) {
                $mentioned[] = (int) $mentionedUser['id'];
            }
        }
    }
    return $mentioned;
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET') {
    $after = max(0, (int) ($_GET['after'] ?? 0));
    $rows = db_all(
        'SELECT rm.*, u.name, u.username, u.is_demo, p.photo
         FROM room_messages rm JOIN users u ON u.id = rm.user_id LEFT JOIN profiles p ON p.user_id = u.id
         WHERE rm.room_id = ? AND rm.is_deleted = 0 AND rm.id > ? ORDER BY rm.id ASC LIMIT 100',
        [$roomId, $after]
    );
    $out = [];
    foreach ($rows as $row) {
        $out[] = ['id' => (int) $row['id'], 'html' => chat_message_html($row, $uid, $canModerate)];
    }
    json_out(['ok' => true, 'messages' => $out, 'last_id' => $out ? end($out)['id'] : $after, 'recordings' => $recordings, 'tasks' => $tasks, 'stats' => $activityStats]);
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    json_out(['ok' => false, 'error' => 'Unsupported request.'], 425);
}
require_csrf(true);
$action = post('action');

if ($action === 'send') {
    if (!rate_limit_hit('room_message', 60, 10)) {
        json_out(['ok' => false, 'error' => 'You are sending messages very quickly. Please wait a moment.'], 429);
    }
    $body = post('body');
    if (mb_strlen($body) < 1) {
        json_out(['ok' => false, 'error' => 'Write a message before sending.'], 422);
    }
    if (mb_strlen($body) > 2000) {
        json_out(['ok' => false, 'error' => 'Please keep messages under 2,000 characters.'], 422);
    }
    db_run('INSERT INTO room_messages (room_id, user_id, body) VALUES (?, ?, ?)', [$roomId, $uid, $body]);
    $messageId = (int) db()->lastInsertId();
    log_activity('room.message', 'room', $roomId, 'Message #' . $messageId);

    // Notify mentioned users
    $mentioned = getMentionedUsers($body, $roomId, $uid);
    foreach ($mentioned as $mid) {
        notify($mid, 'mention', $me['name'] . ' mentioned you in #' . $room['name'] . '.', 'pages/room.php?id=' . $roomId);
    }

    $row = fetch_message($messageId);
    json_out(['ok' => true, 'message' => ['id' => $messageId, 'html' => chat_message_html($row, $uid, $canModerate), 'recordings' => $recordings, 'tasks' => $tasks, 'stats' => $activityStats]]);
}

if ($action === 'delete') {
    $messageId = (int) post('message_id');
    $message = $messageId ? db_one('SELECT * FROM room_messages WHERE id = ? AND room_id = ?', [$messageId, $roomId]) : null;
    if (!$message) {
        json_out(['ok' => false, 'error' => 'That message could not be found.'], 404);
    }
    if ((int) $message['user_id'] !== $uid && !$canModerate) {
        json_out(['ok' => false, 'error' => 'You can only delete your own messages.'], 403);
    }
    db_run('UPDATE room_messages SET is_deleted = 1 WHERE id = ?', [$messageId]);
    log_activity('room.message_deleted', 'room', $roomId, 'Message #' . $messageId);
    json_out(['ok' => true]);
}

// **NEW: Start/stop recording**
if ($action === 'record') {
    if ($canModerate) {
        // Stop any existing recording by this user
        db_run('DELETE FROM room_recording WHERE room_id = ? AND user_id = ?', [$roomId, $uid]);
        // Start new recording
        db_run('INSERT INTO room_recording (room_id, user_id, started_at) VALUES (?, ?, NOW())', [$roomId, $uid]);
        json_out(['ok' => true, 'recording' => true, 'started_at' => date('H:i:s')]);
    } else {
        // Toggle recording for own messages
        $existing = db_one(
            'SELECT 1 FROM room_recording WHERE room_id = ? AND user_id = ? LIMIT 1',
            [$roomId, $uid]
        );
        if ($existing) {
            db_run('DELETE FROM room_recording WHERE room_id = ? AND user_id = ?', [$roomId, $uid]);
            json_out(['ok' => true, 'recording' => false, 'started_at' => null]);
        } else {
            db_run('INSERT INTO room_recording (room_id, user_id, started_at) VALUES (?, ?, NOW())', [$roomId, $uid]);
            json_out(['ok' => true, 'recording' => true, 'started_at' => date('H:i:s')]);
        }
    }
}

// **NEW: Task management: create, check, complete**
if ($action === 'task') {
    if (!$canModerate) {
        json_out(['ok' => false, 'error' => 'Only admins can manage tasks.'], 403);
    }
    $subAction = post('subaction') ?? '';
    $taskId = (int) post('task_id');
    
    if ($subAction === 'create') {
        $title = post('title');
        $priority = (int) post('priority') ?? 3;
        $deadline = post('deadline') ?? '';
        db_run('INSERT INTO team_tasks (room_id, title, priority, deadline, created_by, created_at) VALUES (?, ?, ?, ?, ?, NOW())', 
            [$roomId, $title, $priority, $deadline, $uid]);
        json_out(['ok' => true, 'task' => ['id' => db()->lastInsertId(), 'title', 'priority', 'deadline', 'created_by' => $uid]]);
    }
    
    if ($subAction === 'check') {
        db_run('UPDATE team_tasks SET completed = 1, completed_at = NOW() WHERE id = ?', [$taskId]);
        json_out(['ok' => true]);
    }
    
    if ($subAction === 'complete') {
        db_run("UPDATE team_tasks SET status = 'complete', completed_at = NOW() WHERE id = ?", [$taskId]);
        json_out(['ok' => true]);
    }
    
    if ($subAction === 'list') {
        $tasks = db_all('SELECT * FROM team_tasks WHERE room_id = ? ORDER BY priority DESC, created_at ASC', [$roomId]);
        json_out(['ok' => true, 'tasks' => $tasks]);
    }
}

json_out(['ok' => false, 'error' => 'Unknown action.'], 400);
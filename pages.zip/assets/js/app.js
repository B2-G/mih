/* Mindset Innovators Hub - shared interactions (vanilla JS) */
(function () {
  'use strict';

  // Browser-side validation for forms marked .needs-validation
  document.querySelectorAll('form.needs-validation').forEach(function (form) {
    form.addEventListener('submit', function (event) {
      if (!form.checkValidity()) {
        event.preventDefault();
        event.stopPropagation();
        var first = form.querySelector(':invalid');
        if (first) { first.focus(); }
      }
      form.classList.add('was-validated');
    }, false);
  });

  // Confirm destructive actions
  document.querySelectorAll('[data-confirm]').forEach(function (el) {
    el.addEventListener('click', function (event) {
      if (!window.confirm(el.getAttribute('data-confirm') || 'Are you sure?')) {
        event.preventDefault();
      }
    });
  });

  // Copy-to-clipboard buttons
  document.querySelectorAll('[data-copy]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var value = btn.getAttribute('data-copy');
      var done = function () {
        var original = btn.innerHTML;
        btn.innerHTML = '<i class="bi bi-check2"></i> Copied';
        setTimeout(function () { btn.innerHTML = original; }, 1800);
      };
      if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(value).then(done);
      } else {
        var input = document.createElement('textarea');
        input.value = value;
        document.body.appendChild(input);
        input.select();
        try { document.execCommand('copy'); done(); } catch (e) { /* ignore */ }
        document.body.removeChild(input);
      }
    });
  });

  // Show picked image filename and preview
  document.querySelectorAll('input[type="file"][data-preview]').forEach(function (input) {
    input.addEventListener('change', function () {
      var target = document.querySelector(input.getAttribute('data-preview'));
      var file = input.files && input.files[0];
      if (!target || !file) { return; }
      if (file.type.indexOf('image/') === 0) {
        var reader = new FileReader();
        reader.onload = function (ev) {
          target.innerHTML = '<img src="' + ev.target.result + '" alt="Selected image preview" class="img-fluid rounded" style="max-height:180px">';
        };
        reader.readAsDataURL(file);
      } else {
        target.textContent = file.name;
      }
    });
  });

  // Simple live character counters: data-counter="#target"
  document.querySelectorAll('[data-counter]').forEach(function (field) {
    var target = document.querySelector(field.getAttribute('data-counter'));
    if (!target) { return; }
    var update = function () {
      target.textContent = field.value.length + ' characters';
    };
    field.addEventListener('input', update);
    update();
  });

  // Disable submit button after a successful client-side validation to
  // prevent double posting. Re-enable if the browser restores the page.
  document.querySelectorAll('form[data-single-submit]').forEach(function (form) {
    form.addEventListener('submit', function () {
      if (form.checkValidity && !form.checkValidity()) { return; }
      var btn = form.querySelector('button[type="submit"]');
      if (btn) {
        setTimeout(function () {
          btn.disabled = true;
          btn.dataset.original = btn.innerHTML;
          btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>Saving…';
        }, 10);
      }
    });
  });

  // Keep focus styles visible for keyboard users only where supported
  document.body.addEventListener('mousedown', function () {
    document.body.classList.add('using-mouse');
  });
  document.body.addEventListener('keydown', function (event) {
    if (event.key === 'Tab') { document.body.classList.remove('using-mouse'); }
  });
})();

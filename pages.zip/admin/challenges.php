<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_login();
require_role('admin');
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$status_filter = isset($_GET['status']) ? $_GET['status'] : '';
$params = [];
$where = " WHERE 1=1 ";
if ($search) {
    $where .= " AND (c.title LIKE ? OR c.description LIKE ?) ";
    $params = ["%$search%", "%$search%"];
}
if ($status_filter) {
    $where .= " AND c.status = ? ";
    $params[] = $status_filter;
}
$challenges = db_all("SELECT c.id, c.title, c.description, c.type, c.status, c.created_at,
                             c.due_date, c.partner_id, u.name as partner_name,
                             (SELECT COUNT(*) FROM challenge_participants WHERE challenge_id = c.id) as participants
                      FROM challenges c
                      LEFT JOIN users u ON u.id = c.partner_id
                      $where
                      ORDER BY c.created_at DESC", $params);
$page_title = 'Challenges';
$page_description = 'Manage challenge listings';
require __DIR__ . '/../includes/header.php';
?>
<main id="main-content">
<section class="section-pad-lg">
  <div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h1>Challenges</h1>
      <a class="btn btn-gold" href="<?= e(url('pages/challenge-form.php')) ?>"><i class="bi bi-plus me-1"></i>Add Challenge</a>
    </div>
    <div class="table-responsive">
      <table class="table table-bordered small">
        <thead>
          <tr>
            <th>#</th>
            <th>Title</th>
            <th>Type</th>
            <th>Status</th>
            <th>Partner</th>
            <th>Participants</th>
            <th>Due Date</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($challenges as $i => $c): ?>
          <tr>
            <td><?= $i + 1 ?></td>
            <td><strong><?= e($c['title']) ?></strong></td>
            <td><span class="badge bg-chocolate small"><?= e($c['type']) ?></span></td>
            <td><span class="badge <?= status_badge($c['status']) ?> small"><?= e($c['status']) ?></span></td>
            <td><?= e($c['partner_name'] ?? '—') ?></td>
            <td><?= e($c['participants']) ?></td>
            <td><?= e($c['due_date'] ? format_date($c['due_date']) : '—') ?></td>
            <td>
              <a class="btn btn-link text-muted btn-sm" href="<?= e(url("pages/challenge-detail.php?id=" . $c['id'])) ?>">View</a>
              <?php if (is_admin()): ?>
                · <a class="btn btn-link text-danger btn-sm" href="javascript:void(0)" onclick="confirmDeleteChallenge(<?= $c['id'] ?>)">Delete</a>
              <?php endif; ?>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</section>
</main>
</body>
</html>
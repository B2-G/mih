<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_login();
require_role('admin');
$page_title = 'System Reports';
$page_description = 'Activity reports and analytics';
require __DIR__ . '/../includes/header.php';
?>
<main id="main-content">
<section class="section-pad-lg">
  <div class="container">
    <div class="row mb-4">
      <div class="col-md-3">
        <div class="card bg-brown text-white">
          <div class="card-body">
            <h5 class="card-title">Total Users</h5>
            <h2 class="card-number"><?= db_count("SELECT COUNT(*) FROM users") ?></h2>
            <small class="text-muted">Registered members</small>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card bg-chocolate text-white">
          <div class="card-body">
            <h5 class="card-title">Active Mentors</h5>
            <h2 class="card-number"><?= db_count("SELECT COUNT(*) FROM users WHERE role='mentor' AND status='active'") ?></h2>
            <small class="text-muted">Available mentors</small>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card bg-gold text-brown">
          <div class="card-body">
            <h5 class="card-title">Total Ideas</h5>
            <h2 class="card-number"><?= db_count("SELECT COUNT(*) FROM ideas") ?></h2>
            <small class="text-muted">Community ideas</small>
          </div>
        </div>
      </div>
    </div>
    <div class="row mb-4">
      <div class="col-md-3">
        <div class="card bg-brown text-white">
          <div class="card-body">
            <h5 class="card-title">Total Challenges</h5>
            <h2 class="card-number"><?= db_count("SELECT COUNT(*) FROM challenges") ?></h2>
            <small class="text-muted">All challenges</small>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card bg-chocolate text-white">
          <div class="card-body">
            <h5 class="card-title">Pending Mentor Requests</h5>
            <h2 class="card-number"><?= db_count("SELECT COUNT(*) FROM mentor_requests WHERE status='pending'") ?></h2>
            <small class="text-muted">Awaiting mentor response</small>
          </div>
        </div>
      </div>
    </div>
    <div class="row mb-4">
      <div class="col-12">
        <div class="card">
          <div class="card-header bg-brown text-white">
            <h4 class="mb-0">Recent Activity</h4>
          </div>
          <div class="card-body p-0">
            <ul class="list-group list-group-flush small">
              <?php
              $recent = db_all("SELECT * FROM activity_log ORDER BY created_at DESC LIMIT 5");
              foreach ($recent as $r): 
                $type = $r['type'];
                $table = $r['table_name'];
                $id = $r['record_id'];
                echo "<li class='list-group-item'><span class='fw-semibold small'>$type</span> - $table #$id</li>";
              endforeach;
              ?>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
</main>
</body>
</html>
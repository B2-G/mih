<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_login();
require_role('admin');
$enquiries = db_all("SELECT * FROM partner_enquiries ORDER BY created_at DESC");
$page_title = 'Partner Enquiries';
$page_description = 'Partner enquiries and contact messages';
require __DIR__ . '/../includes/header.php';
?>
<main id="main-content">
<section class="section-pad-lg">
  <div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h1>Partner Enquiries</h1>
    </div>
    <div class="table-responsive">
      <table class="table table-bordered small">
        <thead>
          <tr>
            <th>#</th>
            <th>Name</th>
            <th>Email</th>
            <th>Subject</th>
            <th>Company</th>
            <th>Created</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($enquiries as $i => $e): ?>
          <tr>
            <td><?= $i + 1 ?></td>
            <td><?= e($e['name']) ?></td>
            <td><?= e($e['email']) ?></td>
            <td><?= e($e['subject']) ?></td>
            <td><?= e($e['company'] ?? '—') ?></td>
            <td><?= e($e['created_at'] ? format_date($e['created_at']) : '—') ?></td>
            <td>
              <a class="btn btn-link text-muted btn-sm" href="javascript:void(0)" onclick="confirmReplyEnquiry(<?= $e['id'] ?>)">Reply</a>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</section>
</main>
</body>
</html>
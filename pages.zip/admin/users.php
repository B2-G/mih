<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_login();
require_role('admin');
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$role_filter = isset($_GET['role']) ? $_GET['role'] : '';
$status_filter = isset($_GET['status']) ? $_GET['status'] : '';
$params = [];
$where = " WHERE 1=1 ";
if ($search) {
    $where .= " AND (u.username LIKE ? OR u.email LIKE ?) ";
    $params = ["%$search%", "%$search%"];
}
if ($role_filter) {
    $where .= " AND u.role = ? ";
    $params[] = $role_filter;
}
if ($status_filter) {
    $where .= " AND u.status = ? ";
    $params[] = $status_filter;
}
$users = db_all("SELECT u.id, u.username, u.email, u.role, u.status, u.is_demo, u.last_login_at, u.created_at,
                       p.display_name, p.photo
                FROM users u
                LEFT JOIN profiles p ON p.user_id = u.id
                $where
                ORDER BY u.created_at DESC", $params);
$page_title = 'User Management';
$page_description = 'Manage all user accounts';
require __DIR__ . '/../includes/header.php';
?>
<main id="main-content">
<section class="section-pad-lg">
  <div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h1>User Management</h1>
      <div class="btn-group btn-group-sm">
        <button class="btn btn-outline-brown" type="button">All Users</button>
        <button class="btn btn-outline-brown dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
          <span class="d-none d-sm-inline">Filter by role</span>
          <span class="caret"></span>
        </button>
        <ul class="dropdown-menu">
          <li><a class="dropdown-item" href="<?= e(url('admin/users.php')) ?>">All</a></li>
          <li><a class="dropdown-item" href="<?= e(url('admin/users.php?role=member')) ?>">Members</a></li>
          <li><a class="dropdown-item" href="<?= e(url('admin/users.php?role=mentor')) ?>">Mentors</a></li>
          <li><a class="dropdown-item" href="<?= e(url('admin/users.php?role=partner')) ?>">Partners</a></li>
          <li><a class="dropdown-item" href="<?= e(url('admin/users.php?role=admin')) ?>">Admins</a></li>
        </ul>
      </div>
      <div class="input-group mb-3" style="width: 300px;">
        <input type="text" class="form-control" placeholder="Search..." name="search" value="<?= e($search) ?>" aria-label="Search users">
        <button class="btn btn-outline-brown" type="button">Go</button>
      </div>
    </div>
    <div class="table-responsive">
      <table class="table table-bordered small">
        <thead>
          <tr>
            <th>#</th>
            <th>Username</th>
            <th>Email</th>
            <th>Role</th>
            <th>Status</th>
            <th>Join Date</th>
            <th>Last Login</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($users as $i => $u): ?>
          <tr>
            <td><?= $i + 1 ?></td>
            <td><strong><?= e($u['username']) ?></strong></td>
            <td><?= e($u['email']) ?></td>
            <td><span class="badge <?= role_badge_role($u['role']) ?> small"><?= e(role_label($u['role'])) ?></span></td>
            <td><span class="badge <?= $u['status'] === 'active' ? 'bg-success' : 'bg-warning' ?> rounded-pill px-2 py-1 small"><?= e($u['status']) ?></span></td>
            <td><?= e($u['created_at'] ? format_date($u['created_at']) : '—') ?></td>
            <td><?= e($u['last_login_at'] ? format_date($u['last_login_at']) : 'Never') ?></td>
            <td>
              <a class="btn btn-link text-muted btn-sm" href="<?= e(url("pages/profile.php?u=" . urlencode($u['username']))) ?>">View</a>
              <?php if (is_admin()): ?>
                · <a class="btn btn-link text-danger btn-sm" href="javascript:void(0)" onclick="confirmRoleChange(<?= $u['id'] ?>, '<?= addslashes($u['role']) ?>')">Change role</a>
                · <a class="btn btn-link text-danger btn-sm" href="javascript:void(0)" onclick="confirmSuspend(<?= $u['id'] ?>)">Suspend</a>
              <?php endif; ?>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</section>

<!-- Role Change Modal -->
<div class="modal fade" id="roleChangeModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <input type="hidden" id="change_user_id">
      <div class="modal-header">
        <h5 class="modal-title">Change User Role</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" id="current_role">
        <p>Current role: <span id="current_role_display"></span></p>
        <select class="form-select form-select-sm" id="new_role">
          <option value="member">Member</option>
          <option value="mentor">Mentor</option>
          <option value="partner">Partner</option>
          <option value="admin">Admin</option>
        </select>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-primary" onclick="saveRoleChange()">Save changes</button>
      </div>
    </div>
  </div>
</div>

<script>
function confirmRoleChange(userId, currentRole) {
    document.getElementById('change_user_id').value = userId;
    document.getElementById('current_role').value = currentRole;
    document.getElementById('current_role_display').textContent = currentRole;
    const roleSelect = document.getElementById('new_role');
    // Set based on current role
    if (currentRole === 'member') {
        roleSelect.value = 'mentor';
    } else if (currentRole === 'mentor') {
        roleSelect.value = 'partner';
    } else if (currentRole === 'partner') {
        roleSelect.value = 'admin';
    } else {
        roleSelect.value = 'member';
    }
    const roleChangeModal = new bootstrap.Modal(document.getElementById('roleChangeModal'));
    roleChangeModal.show();
}

function saveRoleChange() {
    const userId = document.getElementById('change_user_id').value;
    const newRole = document.getElementById('new_role').value;
    window.location.href = 'admin/users.php?role_change=' + userId + '&new_role=' + newRole;
}
</script>
</body>
</html>
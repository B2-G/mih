<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_login();
require_role('admin');
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$status_filter = isset($_GET['status']) ? $_GET['status'] : '';
$params = [];
$where = " WHERE 1=1 ";
if ($search) {
    $where .= " AND (title LIKE ?) ";
    $params = ["%$search%"];
}
if ($status_filter) {
    $where .= " AND is_read = ? ";
    $params[] = $status_filter;
}
$notifications = db_all("SELECT * FROM notifications $where ORDER BY created_at DESC LIMIT 20", $params);
$unread = db_count("SELECT COUNT(*) FROM notifications WHERE is_read = 0");
$page_title = 'Admin Notifications';
$page_description = 'Admin notifications and pending approvals';
require __DIR__ . '/../includes/header.php';
?>
<main id="main-content">
<section class="section-pad-lg">
  <div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h1>Admin Notifications</h1>
      <span class="badge bg-warning text-brown small"><?= $unread ?> unread</span>
    </div>
    <div class="table-responsive">
      <table class="table table-bordered small">
        <thead>
          <tr>
            <th>#</th>
            <th>Title</th>
            <th>Status</th>
            <th>Created At</th>
            <th>Link</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($notifications as $i => $n): ?>
          <tr>
            <td><?= $i + 1 ?></td>
            <td><?= e($n['title']) ?></td>
            <td><span class="<?= $n['is_read'] ? 'bg-success' : 'bg-warning' ?> rounded-pill px-2 py-1 small<?= !$n['is_read'] ? ' fw-bold' : '' ?>"><?= $n['is_read'] ? 'Read' : 'Unread' ?></span></td>
            <td><?= e($n['created_at'] ? format_date($n['created_at']) : '—') ?></td>
            <td>
              <?php if (!$n['is_read']): ?>
                <a class="text-primary small" href="<?= e($n['link']) ?>">Open</a>
              <?php else: ?>
                <span class="text-muted small">—</span>
              <?php endif; ?>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <div class="mt-3">
      <a class="btn btn-outline-brown" href="<?= e(url('admin/index.php')) ?>">← Back to Dashboard</a>
    </div>
  </div>
</section>
</main>
</body>
</html>
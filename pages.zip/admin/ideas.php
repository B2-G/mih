<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_login();
require_role('admin');
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$status_filter = isset($_GET['status']) ? $_GET['status'] : '';
$params = [];
$where = " WHERE 1=1 ";
if ($search) {
    $where .= " AND (i.title LIKE ? OR i.description LIKE ?) ";
    $params = ["%$search%", "%$search%"];
}
if ($status_filter) {
    $where .= " AND i.visibility = ? ";
    $params[] = $status_filter;
}
$ideas = db_all("SELECT i.id, i.title, i.description, i.visibility, i.status, i.created_at,
                       i.readiness_status, i.partner_id, u.name as partner_name,
                       (SELECT COUNT(*) FROM idea_comments WHERE idea_id = i.id) as comments,
                       (SELECT COUNT(*) FROM idea_supports WHERE idea_id = i.id) as supports
                FROM ideas i
                LEFT JOIN users u ON u.id = i.partner_id
                $where
                ORDER BY i.created_at DESC", $params);
$page_title = 'Ideas';
$page_description = 'Manage idea board submissions';
require __DIR__ . '/../includes/header.php';
?>
<main id="main-content">
<section class="section-pad-lg">
  <div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h1>Idea Board</h1>
      <a class="btn btn-gold" href="<?= e(url('pages/idea-form.php')) ?>"><i class="bi bi-plus me-1"></i>Add Idea</a>
    </div>
    <div class="table-responsive">
      <table class="table table-bordered small">
        <thead>
          <tr>
            <th>#</th>
            <th>Title</th>
            <th>Status</th>
            <th>Readiness</th>
            <th>Partner</th>
            <th>Comments</th>
            <th>Supports</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($ideas as $i => $id): ?>
          <tr>
            <td><?= $i + 1 ?></td>
            <td><strong><?= e($id['title']) ?></strong></td>
            <td><span class="badge <?= status_badge($id['status']) ?> small"><?= e($id['status']) ?></span></td>
            <td><span class="badge bg-gold small"><?= e($id['readiness_status'] ?? '—') ?></span></td>
            <td><?= e($id['partner_name'] ?? '—') ?></td>
            <td><span class="badge bg-gold small"><?= e($id['comments']) ?></span></td>
            <td><span class="badge bg-gold small"><?= e($id['supports']) ?></span></td>
            <td>
              <a class="btn btn-link text-muted btn-sm" href="<?= e(url("pages/idea-detail.php?id=" . $id['id'])) ?>">View</a>
              <?php if (is_admin()): ?>
                · <a class="btn btn-link text-danger btn-sm" href="javascript:void(0)" onclick="confirmDeleteIdea(<?= $id['id'] ?>)">Delete</a>
              <?php endif; ?>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</section>
</main>
</body>
</html>
<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_login();
require_role('admin');
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$table_filter = isset($_GET['table']) ? $_GET['table'] : '';
$params = [];
$where = " WHERE 1=1 ";
if ($search) {
    $where .= " AND (action LIKE ? OR record_id LIKE ?) ";
    $params = ["%$search%", "%$search%"];
}
if ($table_filter) {
    $where .= " AND table_name = ? ";
    $params[] = $table_filter;
}
$activities = db_all("SELECT * FROM activity_log $where ORDER BY created_at DESC LIMIT 20", $params);
$page_title = 'Activity Log';
$page_description = 'System activity log';
require __DIR__ . '/../includes/header.php';
?>
<main id="main-content">
<section class="section-pad-lg">
  <div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h1>Activity Log</h1>
      <div class="btn-group btn-group-sm">
        <button class="btn btn-outline-brown" type="button">All Actions</button>
        <button class="btn btn-outline-brown dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
          <span>Filter by table</span>
          <span class="caret"></span>
        </button>
        <ul class="dropdown-menu">
          <li><a class="dropdown-item" href="<?= e(url('admin/activity_log.php')) ?>">All</a></li>
          <li><a class="dropdown-item" href="<?= e(url('admin/activity_log.php?table=users')) ?>">Users</a></li>
          <li><a class="dropdown-item" href="<?= e(url('admin/activity_log.php?table=challenges')) ?>">Challenges</a></li>
          <li><a class="dropdown-item" href="<?= e(url('admin/activity_log.php?table=ideas')) ?>">Ideas</a></li>
          <li><a class="dropdown-item" href="<?= e(url('admin/activity_log.php?table=mentor_requests')) ?>">Mentor Requests</a></li>
        </ul>
      </div>
    </div>
    <div class="table-responsive">
      <table class="table table-bordered small">
        <thead>
          <tr>
            <th>#</th>
            <th>Action</th>
            <th>Table</th>
            <th>Record ID</th>
            <th>Performed By</th>
            <th>Created At</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($activities as $i => $a): ?>
          <tr>
            <td><?= $i + 1 ?></td>
            <td><span class="fw-semibold small"><?= e($a['action']) ?></span></td>
            <td><span class="badge bg-brown small"><?= e($a['table_name']) ?></span></td>
            <td><?= e($a['record_id']) ?></td>
            <td><?= e($a['admin_id'] ?? '—') ?></td>
            <td><?= e($a['created_at'] ? format_date($a['created_at']) : '—') ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</section>
</main>
</body>
</html>
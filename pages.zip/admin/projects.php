<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_login();
require_role('admin');
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$status_filter = isset($_GET['status']) ? $_GET['status'] : '';
$params = [];
$where = " WHERE 1=1 ";
if ($search) {
    $where .= " AND (p.title LIKE ? OR p.description LIKE ?) ";
    $params = ["%$search%", "%$search%"];
}
if ($status_filter) {
    $where .= " AND p.status = ? ";
    $params[] = $status_filter;
}
$projects = db_all("SELECT p.id, p.title, p.description, p.status, p.is_published, p.created_at,
                           p.cover_image, p.partner_id, u.name as partner_name,
                           (SELECT COUNT(*) FROM project_members WHERE project_id = p.id) as members,
                           (SELECT COUNT(*) FROM project_feedback WHERE project_id = p.id) as feedback_count
                    FROM projects p
                    LEFT JOIN users u ON u.id = p.partner_id
                    $where
                    ORDER BY p.created_at DESC", $params);
$page_title = 'Projects';
$page_description = 'Manage portfolio projects';
require __DIR__ . '/../includes/header.php';
?>
<main id="main-content">
<section class="section-pad-lg">
  <div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h1>Projects</h1>
      <a class="btn btn-gold" href="<?= e(url('pages/project-form.php')) ?>"><i class="bi bi-plus me-1"></i>Add Project</a>
    </div>
    <div class="table-responsive">
      <table class="table table-bordered small">
        <thead>
          <tr>
            <th>#</th>
            <th>Title</th>
            <th>Status</th>
            <th>Published</th>
            <th>Partner</th>
            <th>Members</th>
            <th>Feedback</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($projects as $i => $p): ?>
          <tr>
            <td><?= $i + 1 ?></td>
            <td><strong><?= e($p['title']) ?></strong></td>
            <td><span class="badge <?= status_badge($p['status']) ?> small"><?= e($p['status']) ?></span></td>
            <td><span class="badge <?= $p['is_published'] ? 'bg-gold' : 'bg-brown' ?> text-brown small"><?= $p['is_published'] ? 'Published' : 'Draft' ?></span></td>
            <td><?= e($p['partner_name'] ?? '—') ?></td>
            <td><?= e($p['members']) ?></td>
            <td><span class="badge bg-gold small"><?= e($p['feedback_count']) ?></span></td>
            <td>
              <a class="btn btn-link text-muted btn-sm" href="<?= e(url("pages/project-detail.php?id=" . $p['id'])) ?>">View</a>
              <?php if (is_admin()): ?>
                · <a class="btn btn-link text-danger btn-sm" href="javascript:void(0)" onclick="confirmDeleteProject(<?= $p['id'] ?>)">Delete</a>
              <?php endif; ?>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</section>
</main>
</body>
</html>
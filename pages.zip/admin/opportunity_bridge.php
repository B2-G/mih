<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_login();
require_role('admin');
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$status_filter = isset($_GET['status']) ? $_GET['status'] : '';
$params = [];
$where = " WHERE 1=1 ";
if ($search) {
    $where .= " AND (o.title LIKE ? OR o.description LIKE ?) ";
    $params = ["%$search%", "%$search%"];
}
if ($status_filter) {
    $where .= " AND o.status = ? ";
    $params[] = $status_filter;
}
$opportunities = db_all("SELECT o.id, o.title, o.description, o.type, o.status, o.is_approved, o.published_at,
                               o.created_at, u.name as partner_name
                        FROM opportunities o
                        LEFT JOIN users u ON u.id = o.partner_id
                        $where
                        ORDER BY o.created_at DESC", $params);
$page_title = 'Opportunity Bridge';
$page_description = 'Approve/reject opportunities before go-live';
require __DIR__ . '/../includes/header.php';
?>
<main id="main-content">
<section class="section-pad-lg">
  <div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h1>Opportunity Bridge</h1>
      <p class="text-muted small">Review and approve opportunities before they go live</a>
    </div>
    <div class="table-responsive">
      <table class="table table-bordered small">
        <thead>
          <tr>
            <th>#</th>
            <th>Title</th>
            <th>Type</th>
            <th>Status</th>
            <th>Approved</th>
            <th>Partner</th>
            <th>Created</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($opportunities as $i => $o): ?>
          <tr>
            <td><?= $i + 1 ?></td>
            <td><strong><?= e($o['title']) ?></strong></td>
            <td><span class="badge bg-chocolate small"><?= e($o['type']) ?></span></td>
            <td><span class="badge <?= status_badge($o['status']) ?> small"><?= e($o['status']) ?></span></td>
            <td><span class="badge <?= $o['is_approved'] ? 'bg-success' : 'bg-warning' ?> rounded-pill px-2 py-1 small"><?= $o['is_approved'] ? 'Approved' : 'Pending' ?></span></td>
            <td><?= e($o['partner_name'] ?? '—') ?></td>
            <td><?= e($o['created_at'] ? format_date($o['created_at']) : '—') ?></td>
            <td>
              <a class="btn btn-link text-muted btn-sm" href="javascript:void(0)" onclick="confirmApproveOpp(<?= $o['id'] ?>)">Approve</a>
              · <a class="btn btn-link text-danger btn-sm" href="javascript:void(0)" onclick="confirmRejectOpp(<?= $o['id'] ?>)">Reject</a>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</section>
</main>
</body>
</html>
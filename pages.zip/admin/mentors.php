<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_login();
require_role('admin');
$mentors = db_all("SELECT u.id, u.username, u.email, u.role, u.status, u.is_demo, u.created_at,
                        p.display_name, p.skills, p.availability,
                        (SELECT COUNT(*) FROM mentor_requests WHERE mentor_id = u.id AND status='pending') as pending_requests
                 FROM users u
                 LEFT JOIN profiles p ON p.user_id = u.id
                 WHERE u.role='mentor'
                 ORDER BY u.created_at DESC");
$page_title = 'Mentors';
$page_description = 'Manage mentor profiles and requests';
require __DIR__ . '/../includes/header.php';
?>
<main id="main-content">
<section class="section-pad-lg">
  <div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h1>Mentors</h1>
      <a class="btn btn-gold" href="<?= e(url('pages/mentor-form.php')) ?>"><i class="bi bi-plus me-1"></i>Add Mentor</a>
    </div>
    <div class="table-responsive">
      <table class="table table-bordered small">
        <thead>
          <tr>
            <th>#</th>
            <th>Name</th>
            <th>Email</th>
            <th>Status</th>
            <th>Availability</th>
            <th>Pending Requests</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($mentors as $i => $m): ?>
          <tr>
            <td><?= $i + 1 ?></td>
            <td><strong><?= e($m['username']) ?></strong></td>
            <td><?= e($m['email']) ?></td>
            <td><span class="badge <?= $m['status'] === 'active' ? 'bg-success' : 'bg-warning' ?> rounded-pill px-2 py-1 small"><?= e($m['status']) ?></span></td>
            <td><?= e($m['availability'] ?? '—') ?></td>
            <td><span class="badge bg-gold small"><?= e($m['pending_requests']) ?></span></td>
            <td>
              <a class="btn btn-link text-muted btn-sm" href="javascript:void(0)" onclick="viewMentorRequests(<?= $m['id'] ?>)">View requests</a>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</section>
</main>
</body>
</html>
<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_login();
require_role('admin');
$page_title = 'Admin Dashboard';
$page_description = 'System administration and moderation';
require __DIR__ . '/../includes/header.php';
?>
<main id="main-content">
<section class="section-pad-lg">
  <div class="container">
    <div class="row">
      <div class="col-md-3">
        <div class="card bg-brown text-white">
          <div class="card-body">
            <h5 class="card-title">Total Users</h5>
            <h2 class="card-number"><?= db_count("SELECT COUNT(*) FROM users") ?></h2>
            <small class="text-muted">Registered members</small>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card bg-chocolate text-white">
          <div class="card-body">
            <h5 class="card-title">Active Mentors</h5>
            <h2 class="card-number"><?= db_count("SELECT COUNT(*) FROM users WHERE role='mentor' AND status='active'") ?></h2>
            <small class="text-muted">Available mentors</small>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card bg-gold text-brown">
          <div class="card-body">
            <h5 class="card-title">Total Ideas</h5>
            <h2 class="card-number"><?= db_count("SELECT COUNT(*) FROM ideas") ?></h2>
            <small class="text-muted">Community ideas</small>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card bg-gold text-brown">
          <div class="card-body">
            <h5 class="card-title">Active Challenges</h5>
            <h2 class="card-number"><?= db_count("SELECT COUNT(*) FROM challenges WHERE status='active'") ?></h2>
            <small class="text-muted">Running challenges</small>
          </div>
        </div>
      </div>
    </div>
    <div class="row mt-4">
      <div class="col-12">
        <div class="card">
          <div class="card-header bg-brown text-white">
            <h4 class="mb-0">Moderation Queue</h4>
          </div>
          <div class="card-body p-0">
            <ul class="list-group list-group-flush small">
              <li class="list-group-item">
                <div class="d-flex justify-content-between align-items-center">
                  <span>Pending mentor requests</span>
                  <span class="badge bg-gold"><?= db_count("SELECT COUNT(*) FROM mentor_requests WHERE status='pending'") ?></span>
                </div>
              </li>
              <li class="list-group-item">
                <div class="d-flex justify-content-between align-items-center">
                  <span>Pending partner requests</span>
                  <span class="badge bg-gold"><?= db_count("SELECT COUNT(*) FROM partner_enquiries WHERE status='pending'") ?></span>
                </div>
              </li>
              <li class="list-group-item">
                <div class="d-flex justify-content-between align-items-center">
                  <span>Awaiting challenge review</span>
                  <span class="badge bg-gold">4</span>
                </div>
              </li>
              <li class="list-group-item">
                <div class="d-flex justify-content-between align-items-center">
                  <span>Draft ideas awaiting moderation</span>
                  <span class="badge bg-gold"><?= db_count("SELECT COUNT(*) FROM ideas WHERE visibility='draft'") ?></span>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
</main>
</body>
</html>
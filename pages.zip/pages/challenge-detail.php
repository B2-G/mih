<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';

$id = get_int('id') ?: (int) post('challenge_id');
if (!$id) {
    not_found('No challenge was selected.');
}
$challenge = db_one(
    'SELECT c.*, u.name AS creator_name, u.username AS creator_username
     FROM challenges c LEFT JOIN users u ON u.id = c.created_by WHERE c.id = ?',
    [$id]
);
if (!$challenge) {
    not_found('That challenge does not exist.');
}
if ($challenge['status'] !== 'published' && !is_admin() && (!is_logged_in() || user_id() !== (int) $challenge['created_by'])) {
    not_found('That challenge is not published.');
}

$page_title = $challenge['title'];
$page_description = excerpt($challenge['description'], 155);
$breadcrumbs = [['Challenges', 'pages/challenges.php'], [$challenge['title'], null]];
$isOpen = $challenge['status'] === 'published' && (!$challenge['deadline'] || strtotime($challenge['deadline']) >= strtotime('today'));
$uid = user_id();
$postErrors = [];

// ---------------------------------------------------------------------
// Actions
// ---------------------------------------------------------------------
if (is_post() && is_logged_in()) {
    require_csrf();
    $action = post('action');

    if ($action === 'join') {
        if (!is_member()) {
            flash('warning', 'Only member accounts can join challenges.');
        } elseif (!$isOpen) {
            flash('warning', 'This challenge is closed to new participants.');
        } else {
            $exists = db_count('SELECT COUNT(*) FROM challenge_participants WHERE challenge_id = ? AND user_id = ?', [$id, $uid]);
            if ($exists) {
                flash('info', 'You have already joined this challenge.');
            } else {
                db_run("INSERT INTO challenge_participants (challenge_id, user_id, status) VALUES (?, ?, 'joined')", [$id, $uid]);
                advance_stage($uid, 'Practise');
                log_activity('challenge.joined', 'challenge', $id, $challenge['title']);
                if ($challenge['created_by'] && (int) $challenge['created_by'] !== $uid) {
                    notify((int) $challenge['created_by'], 'challenge', 'A member joined your challenge: ' . $challenge['title'] . '.', 'pages/challenge-detail.php?id=' . $id);
                }
                flash('success', 'You joined the challenge. Read the brief and submit when you are ready.');
            }
        }
        redirect('pages/challenge-detail.php?id=' . $id . '#submit');

    } elseif ($action === 'submit') {
        if (!is_member()) {
            flash('warning', 'Only member accounts can submit challenge work.');
            redirect('pages/challenge-detail.php?id=' . $id);
        }
        if (!$isOpen) {
            flash('warning', 'This challenge is closed for submissions.');
            redirect('pages/challenge-detail.php?id=' . $id);
        }
        $participant = db_one('SELECT * FROM challenge_participants WHERE challenge_id = ? AND user_id = ?', [$id, $uid]);
        if (!$participant) {
            flash('warning', 'Join the challenge before submitting work.');
            redirect('pages/challenge-detail.php?id=' . $id);
        }
        $content = post('content');
        $link = post('link');
        if (mb_strlen($content) < 20) {
            $postErrors['content'] = 'Please describe your submission in at least 20 characters.';
        }
        if (!valid_url($link)) {
            $postErrors['link'] = 'The link must start with http:// or https://.';
        }
        $existing = db_one('SELECT * FROM submissions WHERE challenge_id = ? AND user_id = ?', [$id, $uid]);
        if ($existing && $existing['status'] === 'completed') {
            $postErrors['form'] = 'This challenge has already been completed, so the submission is locked.';
        }
        $filePath = $existing['file_path'] ?? null;
        if (!$postErrors) {
            try {
                $uploaded = save_upload('evidence', 'document', 'submissions');
                if ($uploaded) {
                    $filePath = $uploaded;
                }
            } catch (RuntimeException $ex) {
                $postErrors['evidence'] = $ex->getMessage();
            }
        }
        if (!$postErrors) {
            if ($existing) {
                db_run(
                    "UPDATE submissions SET content = ?, link = ?, file_path = ?, status = 'submitted', score = NULL,
                            feedback = NULL, reviewer_id = NULL, reviewed_at = NULL, created_at = NOW()
                     WHERE id = ?",
                    [$content, $link ?: null, $filePath, (int) $existing['id']]
                );
                if ($existing['file_path'] && $filePath !== $existing['file_path']) {
                    remove_upload($existing['file_path']);
                }
                $submissionId = (int) $existing['id'];
            } else {
                db_run(
                    "INSERT INTO submissions (challenge_id, user_id, content, link, file_path, status) VALUES (?, ?, ?, ?, ?, 'submitted')",
                    [$id, $uid, $content, $link ?: null, $filePath]
                );
                $submissionId = (int) db()->lastInsertId();
            }
            db_run("UPDATE challenge_participants SET status = 'submitted' WHERE challenge_id = ? AND user_id = ?", [$id, $uid]);
            advance_stage($uid, 'Build');
            refresh_badges($uid);
            log_activity('submission.created', 'submission', $submissionId, $challenge['title']);
            if ($challenge['created_by'] && (int) $challenge['created_by'] !== $uid) {
                notify((int) $challenge['created_by'], 'submission', 'New submission for ' . $challenge['title'] . '.', 'pages/challenge-detail.php?id=' . $id . '#reviews');
            }
            notify_admins('submission', 'A new submission is waiting for review in ' . $challenge['title'] . '.', 'pages/challenge-detail.php?id=' . $id . '#reviews');
            flash('success', 'Your work has been submitted for review.');
            redirect('pages/challenge-detail.php?id=' . $id . '#my-submission');
        }
        flash('danger', 'Please fix the submission errors below.');
        $mySubmissionPreview = $existing;

    } elseif ($action === 'review') {
        if (!can_review()) {
            forbidden('Only mentors and admins can review submissions.');
        }
        $submissionId = (int) post('submission_id');
        $submission = db_one('SELECT s.*, u.name FROM submissions s JOIN users u ON u.id = s.user_id WHERE s.id = ? AND s.challenge_id = ?', [$submissionId, $id]);
        $score = post('score');
        $feedback = post('feedback');
        $outcome = post('outcome', 'reviewed');
        if (!$submission) {
            $postErrors['review'] = 'That submission could not be found.';
        } elseif ((int) $submission['user_id'] === $uid) {
            $postErrors['review'] = 'You cannot review your own submission.';
        }
        if ($score === '' || !is_numeric($score) || (int) $score < 0 || (int) $score > 100) {
            $postErrors['score'] = 'Enter a score between 0 and 100.';
        }
        if (mb_strlen($feedback) < 5) {
            $postErrors['feedback'] = 'Please write at least a short piece of feedback.';
        }
        if (!in_array($outcome, ['reviewed', 'completed'], true)) {
            $postErrors['review'] = 'Choose a valid outcome.';
        }
        if (!$postErrors && $submission) {
            db_run(
                'UPDATE submissions SET status = ?, score = ?, feedback = ?, reviewer_id = ?, reviewed_at = NOW() WHERE id = ?',
                [$outcome, (int) $score, $feedback, $uid, $submissionId]
            );
            db_run('UPDATE challenge_participants SET status = ? WHERE challenge_id = ? AND user_id = ?', [$outcome === 'completed' ? 'completed' : 'reviewed', $id, (int) $submission['user_id']]);
            if ($outcome === 'completed') {
                advance_stage((int) $submission['user_id'], 'Showcase');
                refresh_badges((int) $submission['user_id']);
            }
            notify(
                (int) $submission['user_id'],
                'feedback',
                'Your submission for ' . $challenge['title'] . ' has been reviewed.',
                'pages/challenge-detail.php?id=' . $id . '#my-submission'
            );
            log_activity('submission.reviewed', 'submission', $submissionId, $outcome . ' · ' . $score . '/100');
            flash('success', 'The review has been saved and the member notified.');
            redirect('pages/challenge-detail.php?id=' . $id . '#reviews');
        }
        flash('danger', 'The review could not be saved. Please check the fields.');

    } elseif ($action === 'rate') {
        $rating = (int) post('rating');
        $comment = post('comment');
        $participant = db_one('SELECT * FROM challenge_participants WHERE challenge_id = ? AND user_id = ?', [$id, $uid]);
        if (!$participant || $participant['status'] !== 'completed') {
            flash('warning', 'Only members who completed the challenge can rate it.');
        } elseif ($rating < 1 || $rating > 5) {
            flash('danger', 'Choose a rating from 1 to 5.');
        } else {
            db_run(
                'INSERT INTO challenge_ratings (challenge_id, user_id, rating, comment) VALUES (?, ?, ?, ?)
                 ON DUPLICATE KEY UPDATE rating = VALUES(rating), comment = VALUES(comment), created_at = NOW()',
                [$id, $uid, $rating, $comment ?: null]
            );
            log_activity('challenge.rated', 'challenge', $id, (string) $rating);
            flash('success', 'Thank you. Your rating was saved.');
        }
        redirect('pages/challenge-detail.php?id=' . $id . '#rating');
    }
}

// ---------------------------------------------------------------------
// Load page data
// ---------------------------------------------------------------------
$participantCount = db_count('SELECT COUNT(*) FROM challenge_participants WHERE challenge_id = ?', [$id]);
$myParticipation = $uid ? db_one('SELECT * FROM challenge_participants WHERE challenge_id = ? AND user_id = ?', [$id, $uid]) : null;
$mySubmission = $uid ? db_one('SELECT * FROM submissions WHERE challenge_id = ? AND user_id = ?', [$id, $uid]) : null;
if (!empty($mySubmissionPreview)) {
    $mySubmission = $mySubmissionPreview;
}
$ratingStats = db_one('SELECT ROUND(AVG(rating),1) AS avg_rating, COUNT(*) AS total FROM challenge_ratings WHERE challenge_id = ?', [$id]);
$ratings = db_all('SELECT cr.*, u.name FROM challenge_ratings cr JOIN users u ON u.id = cr.user_id WHERE cr.challenge_id = ? ORDER BY cr.created_at DESC', [$id]);
$myRating = $uid ? db_one('SELECT * FROM challenge_ratings WHERE challenge_id = ? AND user_id = ?', [$id, $uid]) : null;
$reviewSubmissions = can_review()
    ? db_all(
        'SELECT s.*, u.name, u.username FROM submissions s JOIN users u ON u.id = s.user_id WHERE s.challenge_id = ? ORDER BY s.created_at ASC',
        [$id]
    ) : [];

require __DIR__ . '/../includes/header.php';
?>
<section class="section-pad-sm section-cream">
  <div class="container">
    <div class="row g-4">
      <div class="col-lg-8">
        <div class="d-flex flex-wrap gap-2 mb-2">
          <span class="badge badge-stage"><?= e($challenge['category']) ?></span>
          <span class="badge badge-tag"><?= e($challenge['difficulty']) ?></span>
          <?= status_badge($challenge['status']) ?>
          <?= demo_badge($challenge['is_demo']) ?>
          <?php if (!$isOpen): ?><span class="badge text-bg-danger">Closed</span><?php endif; ?>
        </div>
        <h1 class="display-5 mt-2 mb-3"><?= e($challenge['title']) ?></h1>
        <div class="meta-row mb-4">
          <span><i class="bi bi-people me-1"></i><?= $participantCount ?> participant<?= $participantCount === 1 ? '' : 's' ?></span>
          <?php if ($challenge['deadline']): ?><span><i class="bi bi-calendar3 me-1"></i>Deadline <?= e(format_date($challenge['deadline'])) ?></span><?php endif; ?>
          <?php if ((int) $ratingStats['total'] > 0): ?><span class="stars"><i class="bi bi-star-fill me-1"></i><?= e($ratingStats['avg_rating']) ?>/5 (<?= (int) $ratingStats['total'] ?>)</span><?php endif; ?>
          <?php if ($challenge['creator_name']): ?><span><i class="bi bi-person me-1"></i>Created by <?= e($challenge['creator_name']) ?></span><?php endif; ?>
        </div>
        <?php if ($challenge['sponsor_name']): ?><div class="alert alert-warning py-2 small"><i class="bi bi-award me-1"></i>Sponsored by <strong><?= e($challenge['sponsor_name']) ?></strong></div><?php endif; ?>
      </div>
      <div class="col-lg-4">
        <div class="panel panel-body">
          <div class="small-caps mb-2">Your status</div>
          <?php if (!is_logged_in()): ?>
            <p class="small text-muted">Sign in as a member to join and submit.</p>
            <a class="btn btn-gold w-100" href="<?= e(url('pages/login.php?next=' . urlencode('pages/challenge-detail.php?id=' . $id))) ?>">Sign in to join</a>
          <?php elseif (is_member()): ?>
            <?php if (!$myParticipation): ?>
              <p class="small text-muted">You have not joined yet.</p>
              <?php if ($isOpen): ?>
                <form method="post" action="<?= e(url('pages/challenge-detail.php?id=' . $id)) ?>">
                  <?= csrf_field() ?>
                  <input type="hidden" name="challenge_id" value="<?= $id ?>">
                  <input type="hidden" name="action" value="join">
                  <button class="btn btn-gold w-100" type="submit">Join this challenge</button>
                </form>
              <?php else: ?><button class="btn btn-secondary w-100" disabled>Closed</button><?php endif; ?>
            <?php else: ?>
              <div class="mb-2"><?= status_badge($myParticipation['status']) ?></div>
              <p class="small text-muted">Joined <?= e(format_date($myParticipation['joined_at'])) ?>.</p>
              <?php if ($isOpen && $myParticipation['status'] !== 'completed'): ?><a class="btn btn-gold w-100" href="#submit">Submit / update work</a>
              <?php elseif ($myParticipation['status'] === 'completed'): ?><a class="btn btn-outline-brown w-100" href="#rating">Rate this challenge</a><?php endif; ?>
            <?php endif; ?>
          <?php else: ?>
            <p class="small text-muted mb-2">You are signed in as a <?= e(user_role()) ?>.</p>
            <?php if (can_review()): ?><a class="btn btn-outline-brown w-100" href="#reviews">Review submissions</a>
            <?php elseif (can_create_challenges()): ?><a class="btn btn-outline-brown w-100" href="<?= e(url('pages/challenge-form.php')) ?>">Create a challenge</a><?php endif; ?>
          <?php endif; ?>
          <hr>
          <button class="btn btn-sm btn-outline-brown w-100" type="button" data-copy="<?= e(url('pages/challenge-detail.php?id=' . $id)) ?>"><i class="bi bi-link-45deg me-1"></i>Copy challenge link</button>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="section-pad-sm">
  <div class="container">
    <?php if ($postErrors): ?><div class="alert alert-danger" role="alert">The last action could not be completed. Please check the form below.</div><?php endif; ?>
    <div class="row g-4">
      <div class="col-lg-8">
        <div class="panel panel-body mb-4">
          <h2 class="h5">The brief</h2>
          <div class="text-muted" style="white-space:pre-line"><?= e($challenge['description']) ?></div>
          <?php if ($challenge['resources']): ?>
            <h3 class="h6 mt-4">Resources</h3>
            <ul class="small text-muted">
              <?php foreach (preg_split('/\r\n|\r|\n/', $challenge['resources']) as $line): $line = trim($line); if ($line === '') continue; ?>
                <li><?php if (preg_match('~^https?://~i', $line)): ?><a href="<?= e($line) ?>" target="_blank" rel="noopener noreferrer nofollow"><?= e($line) ?></a><?php else: ?><?= e($line) ?><?php endif; ?></li>
              <?php endforeach; ?>
            </ul>
          <?php endif; ?>
        </div>

        <?php if (is_member() && $myParticipation): ?>
          <div class="panel panel-body mb-4" id="submit">
            <h2 class="h5">Submit your work</h2>
            <?php if ($mySubmission && $mySubmission['status'] === 'completed'): ?>
              <div class="alert alert-success mb-0"><i class="bi bi-check2-circle me-1"></i>This challenge is complete. Your submission and feedback are below.</div>
            <?php elseif (!$isOpen): ?>
              <div class="alert alert-warning mb-0">Submissions are closed for this challenge.</div>
            <?php else: ?>
              <p class="small text-muted">Describe what you did, add a link if useful, and attach an image, PDF or zip if it helps. You can update your work until it is completed.</p>
              <?php if (!empty($postErrors['form'])): ?><div class="alert alert-danger py-2 small"><?= e($postErrors['form']) ?></div><?php endif; ?>
              <form method="post" action="<?= e(url('pages/challenge-detail.php?id=' . $id . '#submit')) ?>" enctype="multipart/form-data" class="needs-validation" novalidate data-single-submit>
                <?= csrf_field() ?>
                <input type="hidden" name="challenge_id" value="<?= $id ?>">
                <input type="hidden" name="action" value="submit">
                <div class="mb-3">
                  <label class="form-label" for="content">What did you do? <span class="text-danger">*</span></label>
                  <textarea class="form-control <?= isset($postErrors['content']) ? 'is-invalid' : '' ?>" id="content" name="content" rows="5" required minlength="20" maxlength="6000"><?= e($mySubmission['content'] ?? '') ?></textarea>
                  <?= field_error($postErrors, 'content') ?>
                </div>
                <div class="row g-3">
                  <div class="col-md-7">
                    <label class="form-label" for="link">Evidence link <span class="text-muted">(optional)</span></label>
                    <input type="url" class="form-control <?= isset($postErrors['link']) ? 'is-invalid' : '' ?>" id="link" name="link" maxlength="500" placeholder="https://" value="<?= e($mySubmission['link'] ?? '') ?>">
                    <?= field_error($postErrors, 'link') ?>
                  </div>
                  <div class="col-md-5">
                    <label class="form-label" for="evidence">File <span class="text-muted">(optional)</span></label>
                    <input type="file" class="form-control <?= isset($postErrors['evidence']) ? 'is-invalid' : '' ?>" id="evidence" name="evidence" accept=".jpg,.jpeg,.png,.webp,.pdf,.zip,.txt">
                    <?= field_error($postErrors, 'evidence') ?>
                    <div class="form-text">Max 5 MB.</div>
                  </div>
                </div>
                <?php if ($mySubmission): ?><p class="small text-muted mt-2 mb-0">Current status: <?= status_badge($mySubmission['status']) ?></p><?php endif; ?>
                <button class="btn btn-gold mt-3" type="submit"><?= $mySubmission ? 'Update submission' : 'Submit work' ?></button>
              </form>
            <?php endif; ?>
          </div>
        <?php endif; ?>

        <?php if ($mySubmission): ?>
          <div class="panel panel-body mb-4" id="my-submission">
            <div class="d-flex justify-content-between align-items-center mb-2">
              <h2 class="h5 mb-0">My submission</h2>
              <?= status_badge($mySubmission['status']) ?>
            </div>
            <p class="small text-muted mb-2">Submitted <?= e(format_datetime($mySubmission['created_at'])) ?></p>
            <div class="small" style="white-space:pre-line"><?= e($mySubmission['content']) ?></div>
            <?php if ($mySubmission['link']): ?><p class="small mt-2 mb-1"><a href="<?= e($mySubmission['link']) ?>" target="_blank" rel="noopener noreferrer nofollow">View evidence link</a></p><?php endif; ?>
            <?php if ($mySubmission['file_path']): ?><p class="small mb-1"><a href="<?= e(url($mySubmission['file_path'])) ?>" target="_blank" rel="noopener">Download attached file</a></p><?php endif; ?>
            <?php if ($mySubmission['feedback']): ?>
              <div class="alert alert-success mt-3 mb-0">
                <div class="d-flex justify-content-between"><strong>Reviewer feedback</strong><span class="badge text-bg-success"><?= (int) $mySubmission['score'] ?>/100</span></div>
                <p class="small mb-0 mt-2" style="white-space:pre-line"><?= e($mySubmission['feedback']) ?></p>
              </div>
            <?php elseif ($mySubmission['status'] === 'submitted'): ?>
              <p class="small text-muted mt-2 mb-0"><i class="bi bi-hourglass-split me-1"></i>Waiting for review.</p>
            <?php endif; ?>
          </div>
        <?php endif; ?>

        <?php if ($myParticipation && $myParticipation['status'] === 'completed'): ?>
          <div class="panel panel-body mb-4" id="rating">
            <h2 class="h5">Rate this challenge</h2>
            <?php if ($myRating): ?><p class="small text-muted">You rated this challenge <?= (int) $myRating['rating'] ?>/5. You can update it.</p><?php endif; ?>
            <form method="post" action="<?= e(url('pages/challenge-detail.php?id=' . $id . '#rating')) ?>">
              <?= csrf_field() ?>
              <input type="hidden" name="challenge_id" value="<?= $id ?>">
              <input type="hidden" name="action" value="rate">
              <fieldset class="mb-3">
                <legend class="form-label">Satisfaction</legend>
                <div class="rating-input">
                  <?php for ($r = 5; $r >= 1; $r--): ?>
                    <input type="radio" id="star<?= $r ?>" name="rating" value="<?= $r ?>" <?= (int) ($myRating['rating'] ?? 0) === $r ? 'checked' : '' ?> required>
                    <label for="star<?= $r ?>" title="<?= $r ?> star<?= $r === 1 ? '' : 's' ?>"><i class="bi bi-star-fill"></i><span class="visually-hidden"><?= $r ?> star<?= $r === 1 ? '' : 's' ?></span></label>
                  <?php endfor; ?>
                </div>
              </fieldset>
              <div class="mb-3">
                <label class="form-label" for="comment">Comment <span class="text-muted">(optional)</span></label>
                <textarea class="form-control" id="comment" name="comment" maxlength="500" rows="3"><?= e($myRating['comment'] ?? '') ?></textarea>
              </div>
              <button class="btn btn-outline-brown" type="submit">Save rating</button>
            </form>
          </div>
        <?php endif; ?>

        <?php if (can_review()): ?>
          <div class="panel panel-body mb-4" id="reviews">
            <div class="d-flex justify-content-between align-items-center mb-2">
              <h2 class="h5 mb-0">Review submissions</h2>
              <span class="badge badge-soft"><?= count($reviewSubmissions) ?> total</span>
            </div>
            <p class="small text-muted">Mentor/admin view. Feedback is shown to the member and stored with the submission.</p>
            <?php if (!$reviewSubmissions): ?><p class="small text-muted mb-0">No submissions yet.</p><?php endif; ?>
            <?php foreach ($reviewSubmissions as $sub): ?>
              <div class="border rounded-3 p-3 mb-3">
                <div class="d-flex flex-wrap justify-content-between gap-2 mb-2">
                  <div><strong><?= e($sub['name']) ?></strong> <span class="small text-muted">@<?= e($sub['username']) ?></span></div>
                  <div><?= status_badge($sub['status']) ?> <?php if ($sub['score'] !== null): ?><span class="badge badge-stage"><?= (int) $sub['score'] ?>/100</span><?php endif; ?></div>
                </div>
                <div class="small mb-2" style="white-space:pre-line"><?= e($sub['content']) ?></div>
                <?php if ($sub['link']): ?><a class="small me-3" href="<?= e($sub['link']) ?>" target="_blank" rel="noopener noreferrer nofollow">Evidence link</a><?php endif; ?>
                <?php if ($sub['file_path']): ?><a class="small" href="<?= e(url($sub['file_path'])) ?>" target="_blank" rel="noopener">Attached file</a><?php endif; ?>
                <details class="mt-2">
                  <summary class="small fw-semibold"><?= $sub['feedback'] ? 'Update review' : 'Write review' ?></summary>
                  <form method="post" action="<?= e(url('pages/challenge-detail.php?id=' . $id . '#reviews')) ?>" class="row g-2 mt-1">
                    <?= csrf_field() ?>
                    <input type="hidden" name="challenge_id" value="<?= $id ?>">
                    <input type="hidden" name="action" value="review">
                    <input type="hidden" name="submission_id" value="<?= (int) $sub['id'] ?>">
                    <div class="col-md-4">
                      <label class="form-label" for="score_<?= (int) $sub['id'] ?>">Score (0–100)</label>
                      <input type="number" class="form-control form-control-sm" id="score_<?= (int) $sub['id'] ?>" name="score" min="0" max="100" value="<?= e($sub['score'] ?? '') ?>" required>
                    </div>
                    <div class="col-md-4">
                      <label class="form-label" for="outcome_<?= (int) $sub['id'] ?>">Outcome</label>
                      <select class="form-select form-select-sm" id="outcome_<?= (int) $sub['id'] ?>" name="outcome">
                        <option value="reviewed" <?= $sub['status'] === 'reviewed' ? 'selected' : '' ?>>Reviewed (can revise)</option>
                        <option value="completed" <?= $sub['status'] === 'completed' ? 'selected' : '' ?>>Completed</option>
                      </select>
                    </div>
                    <div class="col-12">
                      <label class="form-label" for="feedback_<?= (int) $sub['id'] ?>">Feedback</label>
                      <textarea class="form-control form-control-sm" id="feedback_<?= (int) $sub['id'] ?>" name="feedback" rows="3" required minlength="5"><?= e($sub['feedback'] ?? '') ?></textarea>
                    </div>
                    <div class="col-12"><button class="btn btn-sm btn-brown" type="submit">Save review</button></div>
                  </form>
                </details>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>

        <div class="panel panel-body">
          <h2 class="h5">Member ratings</h2>
          <?php if ($ratings): ?>
            <?php foreach ($ratings as $r): ?>
              <div class="border-bottom py-2">
                <div class="d-flex justify-content-between"><strong class="small"><?= e($r['name']) ?></strong><span class="stars small"><?= str_repeat('★', (int) $r['rating']) ?><?= str_repeat('☆', 5 - (int) $r['rating']) ?></span></div>
                <?php if ($r['comment']): ?><p class="small text-muted mb-0"><?= e($r['comment']) ?></p><?php endif; ?>
              </div>
            <?php endforeach; ?>
          <?php else: ?><p class="small text-muted mb-0">No ratings yet. Ratings are available after a completed review.</p><?php endif; ?>
        </div>
      </div>

      <aside class="col-lg-4">
        <div class="panel panel-body mb-3">
          <div class="small-caps mb-2">Challenge facts</div>
          <ul class="list-clean small">
            <li class="d-flex justify-content-between"><span>Category</span><strong><?= e($challenge['category']) ?></strong></li>
            <li class="d-flex justify-content-between"><span>Difficulty</span><strong><?= e($challenge['difficulty']) ?></strong></li>
            <li class="d-flex justify-content-between"><span>Deadline</span><strong><?= e(format_date($challenge['deadline'])) ?></strong></li>
            <li class="d-flex justify-content-between"><span>Participants</span><strong><?= $participantCount ?></strong></li>
            <li class="d-flex justify-content-between"><span>Average rating</span><strong><?= $ratingStats['avg_rating'] ? e($ratingStats['avg_rating']) . '/5' : '—' ?></strong></li>
          </ul>
        </div>
        <div class="panel panel-body">
          <div class="small-caps mb-2">Why challenges?</div>
          <p class="small text-muted mb-0">A challenge turns learning into evidence: a brief, a submission, a review and a record. Completed challenges count toward your growth and can be added to your portfolio.</p>
        </div>
      </aside>
    </div>
  </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>

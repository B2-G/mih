<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_login();
$userId = (int) user_id();
$notifications = db_all(
    'SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC',
    [$userId]
);
$unread = db_count(
    "SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0",
    [$userId]
);
$page_title = 'Notifications';
$page_description = 'Your notifications and alerts';
require __DIR__ . '/../includes/header.php';
?>
<main id="main-content">
<section class="section-pad-lg">
  <div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h1>Notifications</h1>
      <a class="btn btn-gold small" href="<?= e(url('pages/notifications.php')) ?>"><?= $unread > 0 ? "Mark all read ($unread)" : 'View all' ?></a>
    </div>
    <?php if (!$notifications): ?>
      <div class="alert alert-info small text-muted">
        No notifications yet.
      </div>
    <?php else: ?>
    <div class="table-responsive">
      <table class="table table-bordered small">
        <thead>
          <tr>
            <th>#</th>
            <th>Title</th>
            <th>Read</th>
            <th>Created</th>
            <th>Link</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($notifications as $i => $n): ?>
          <tr>
            <td><?= $i + 1 ?></td>
            <td><?= e($n['title']) ?></td>
            <td><span class="<?= $n['is_read'] ? 'bg-success' : 'bg-warning' ?> rounded-pill px-2 py-1 small<?= !$n['is_read'] ? ' fw-bold' : '' ?>"><?= $n['is_read'] ? 'Read' : 'Unread' ?></span></td>
            <td><?= e($n['created_at'] ? format_date($n['created_at']) : '—') ?></td>
            <td>
              <?php if (!$n['is_read']): ?>
                <a class="text-primary small" href="<?= e($n['link']) ?>">Open</a>
              <?php else: ?>
                <span class="text-muted small">—</span>
              <?php endif; ?>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php endif; ?>
    <div class="mt-3">
      <a class="btn btn-outline-brown" href="<?= e(url('pages/')) ?>">← Back to home</a>
    </div>
  </div>
</section>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
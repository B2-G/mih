<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';

$id = get_int('id') ?: (int) post('idea_id');
if (!$id) {
    not_found('No idea was selected.');
}
$idea = db_one(
    'SELECT i.*, u.name, u.username, u.is_demo, u.role AS owner_role, p.headline, p.photo
     FROM ideas i JOIN users u ON u.id = i.user_id LEFT JOIN profiles p ON p.user_id = u.id
     WHERE i.id = ?',
    [$id]
);
if (!$idea) {
    not_found('That idea could not be found.');
}

$uid = user_id();
$isOwner = $uid > 0 && (int) $idea['user_id'] === $uid;
$isAdmin = is_admin();
$canView = $idea['visibility'] === 'public'
    || ($uid > 0 && $idea['visibility'] === 'members')
    || $isOwner || $isAdmin;
if (!$canView) {
    if (!is_logged_in()) {
        flash('warning', 'Sign in to view this idea.');
        redirect('pages/login.php?next=' . urlencode('pages/idea-detail.php?id=' . $id));
    }
    forbidden('This idea is private.');
}
$canEdit = $isOwner || $isAdmin;
$errors = [];

if (is_post()) {
    require_login();
    require_csrf();
    $action = post('action');

    if ($action === 'support') {
        $exists = db_count('SELECT COUNT(*) FROM idea_supports WHERE idea_id = ? AND user_id = ?', [$id, $uid]);
        if ($exists) {
            db_run('DELETE FROM idea_supports WHERE idea_id = ? AND user_id = ?', [$id, $uid]);
            flash('info', 'Your support was removed.');
        } else {
            db_run('INSERT INTO idea_supports (idea_id, user_id) VALUES (?, ?)', [$id, $uid]);
            advance_stage($uid, 'Discover');
            log_activity('idea.supported', 'idea', $id, $idea['title']);
            if (!$isOwner) {
                notify((int) $idea['user_id'], 'idea', $me = current_user()['name'] . ' supported your idea: ' . $idea['title'] . '.', 'pages/idea-detail.php?id=' . $id);
            }
            flash('success', 'Thanks — your support has been added.');
        }
        redirect('pages/idea-detail.php?id=' . $id . '#support');

    } elseif ($action === 'comment') {
        $body = post('body');
        if (mb_strlen($body) < 2) {
            $errors['comment'] = 'Write a short comment before posting.';
        }
        if (mb_strlen($body) > 2000) {
            $errors['comment'] = 'Please keep comments under 2,000 characters.';
        }
        if (!$errors) {
            db_run('INSERT INTO idea_comments (idea_id, user_id, body) VALUES (?, ?, ?)', [$id, $uid, $body]);
            log_activity('idea.commented', 'idea', $id, $idea['title']);
            if (!$isOwner) {
                notify((int) $idea['user_id'], 'idea', current_user()['name'] . ' commented on your idea: ' . $idea['title'] . '.', 'pages/idea-detail.php?id=' . $id . '#comments');
            }
            flash('success', 'Your comment was posted.');
            redirect('pages/idea-detail.php?id=' . $id . '#comments');
        }

    } elseif ($action === 'delete_comment') {
        $commentId = (int) post('comment_id');
        $comment = db_one('SELECT * FROM idea_comments WHERE id = ? AND idea_id = ?', [$commentId, $id]);
        if ($comment && ((int) $comment['user_id'] === $uid || $isAdmin)) {
            db_run('DELETE FROM idea_comments WHERE id = ?', [$commentId]);
            log_activity('idea.comment_deleted', 'idea', $id, 'Comment #' . $commentId);
            flash('success', 'The comment was removed.');
        } else {
            flash('warning', 'You cannot remove that comment.');
        }
        redirect('pages/idea-detail.php?id=' . $id . '#comments');

    } elseif ($action === 'toggle_ready') {
        if (!$canEdit) {
            forbidden('Only the idea owner can change matching readiness.');
        }
        $new = (int) $idea['ready_for_matching'] === 1 ? 0 : 1;
        db_run('UPDATE ideas SET ready_for_matching = ? WHERE id = ?', [$new, $id]);
        log_activity('idea.matching_toggled', 'idea', $id, $new ? 'Ready for matching' : 'Not ready');
        if ($new) {
            notify_admins('idea', 'An idea is ready for matching: ' . $idea['title'] . '.', 'pages/idea-detail.php?id=' . $id);
        }
        flash('success', $new ? 'Your idea is now ready for matching.' : 'Your idea is no longer marked ready for matching.');
        redirect('pages/idea-detail.php?id=' . $id . '#matching');

    } elseif ($action === 'status') {
        if (!$canEdit) {
            forbidden('Only the idea owner can change its status.');
        }
        $status = post('status');
        if (!in_array($status, ['open', 'in_discussion', 'matched', 'closed'], true)) {
            flash('danger', 'Choose a valid status.');
        } else {
            db_run('UPDATE ideas SET status = ? WHERE id = ?', [$status, $id]);
            log_activity('idea.status', 'idea', $id, $status);
            flash('success', 'The idea status was updated.');
        }
        redirect('pages/idea-detail.php?id=' . $id . '#matching');

    } elseif ($action === 'interest') {
        if (!in_array(user_role(), ['mentor', 'partner'], true)) {
            forbidden('Only mentors and partners can offer support through matching.');
        }
        if (!$idea['ready_for_matching']) {
            flash('warning', 'The owner has not marked this idea ready for matching.');
            redirect('pages/idea-detail.php?id=' . $id . '#matching');
        }
        if ($isOwner) {
            flash('warning', 'You cannot match with your own idea.');
            redirect('pages/idea-detail.php?id=' . $id . '#matching');
        }
        $note = post('note');
        if (mb_strlen($note) < 10) {
            $errors['note'] = 'Explain briefly how you could help (at least 10 characters).';
        }
        $existing = db_count("SELECT COUNT(*) FROM idea_matches WHERE idea_id = ? AND partner_id = ? AND status IN ('interested','in_discussion','accepted')", [$id, $uid]);
        if ($existing) {
            $errors['form'] = 'You already have an open match conversation about this idea.';
        }
        if (!$errors) {
            db_run("INSERT INTO idea_matches (idea_id, partner_id, initiated_by, note, status) VALUES (?, ?, ?, ?, 'interested')", [$id, $uid, $uid, $note]);
            db_run("UPDATE ideas SET status = 'in_discussion' WHERE id = ? AND status = 'open'", [$id]);
            notify((int) $idea['user_id'], 'match', current_user()['name'] . ' is interested in your idea: ' . $idea['title'] . '.', 'pages/idea-detail.php?id=' . $id . '#matching');
            log_activity('idea.match_interest', 'idea', $id, 'Match with user #' . $uid);
            flash('success', 'Your interest has been sent to the idea owner.');
            redirect('pages/idea-detail.php?id=' . $id . '#matching');
        }

    } elseif ($action === 'respond_match') {
        if (!$isOwner && !$isAdmin) {
            forbidden('Only the idea owner can respond to a match.');
        }
        $matchId = (int) post('match_id');
        $response = post('response');
        $match = db_one('SELECT * FROM idea_matches WHERE id = ? AND idea_id = ?', [$matchId, $id]);
        if (!$match) {
            flash('danger', 'That match could not be found.');
            redirect('pages/idea-detail.php?id=' . $id . '#matching');
        }
        if (!in_array($response, ['accepted', 'closed'], true)) {
            flash('danger', 'Choose a valid response.');
            redirect('pages/idea-detail.php?id=' . $id . '#matching');
        }
        db_run('UPDATE idea_matches SET status = ?, responded_at = NOW() WHERE id = ?', [$response, $matchId]);
        if ($response === 'accepted') {
            db_run("UPDATE ideas SET status = 'matched' WHERE id = ?", [$id]);
            notify((int) $match['partner_id'], 'match', 'Your interest in "' . $idea['title'] . '" was accepted. You can now continue the conversation.', 'pages/idea-detail.php?id=' . $id . '#matching');
            flash('success', 'Match accepted. The partner has been notified.');
            log_activity('idea.match_accepted', 'idea', $id, 'Match #' . $matchId);
        } else {
            $open = db_count("SELECT COUNT(*) FROM idea_matches WHERE idea_id = ? AND id <> ? AND status IN ('interested','in_discussion','accepted')", [$id, $matchId]);
            if (!$open) {
                db_run("UPDATE ideas SET status = 'open' WHERE id = ? AND status = 'in_discussion'", [$id]);
            }
            notify((int) $match['partner_id'], 'match', 'The owner has closed the match conversation for "' . $idea['title'] . '".', 'pages/idea-detail.php?id=' . $id . '#matching');
            flash('success', 'The match conversation was closed.');
            log_activity('idea.match_declined', 'idea', $id, 'Match #' . $matchId);
        }
        redirect('pages/idea-detail.php?id=' . $id . '#matching');

    } elseif ($action === 'admin_match') {
        if (!$isAdmin) {
            forbidden('Only admins can create a manual match.');
        }
        $partnerId = (int) post('partner_id');
        $note = post('note');
        $partner = db_one("SELECT id, name, role FROM users WHERE id = ? AND role IN ('mentor','partner') AND status = 'active'", [$partnerId]);
        if (!$partner) {
            $errors['partner_id'] = 'Choose a mentor or partner account.';
        }
        if ((int) $idea['user_id'] === $partnerId) {
            $errors['partner_id'] = 'An idea cannot be matched to its owner.';
        }
        if (mb_strlen($note) < 5) {
            $errors['note'] = 'Add a short note explaining the match.';
        }
        if (!$errors) {
            db_run("INSERT INTO idea_matches (idea_id, partner_id, initiated_by, note, status, responded_at) VALUES (?, ?, ?, ?, 'accepted', NOW())", [$id, $partnerId, $uid, $note]);
            db_run("UPDATE ideas SET status = 'matched' WHERE id = ?", [$id]);
            notify((int) $idea['user_id'], 'match', 'An admin connected your idea "' . $idea['title'] . '" with ' . $partner['name'] . '.', 'pages/idea-detail.php?id=' . $id . '#matching');
            notify($partnerId, 'match', 'An admin suggested you support the idea "' . $idea['title'] . '".', 'pages/idea-detail.php?id=' . $id . '#matching');
            log_activity('idea.admin_match', 'idea', $id, 'Partner user #' . $partnerId);
            flash('success', 'The manual match was created and both people were notified.');
            redirect('pages/idea-detail.php?id=' . $id . '#matching');
        }
    }
}

$supportCount = db_count('SELECT COUNT(*) FROM idea_supports WHERE idea_id = ?', [$id]);
$hasSupported = $uid ? db_count('SELECT COUNT(*) FROM idea_supports WHERE idea_id = ? AND user_id = ?', [$id, $uid]) > 0 : false;
$comments = db_all(
    'SELECT c.*, u.name, u.username, u.is_demo, p.photo FROM idea_comments c
     JOIN users u ON u.id = c.user_id LEFT JOIN profiles p ON p.user_id = u.id
     WHERE c.idea_id = ? ORDER BY c.created_at ASC',
    [$id]
);
$matches = db_all(
    'SELECT m.*, u.name, u.username, u.role, u.is_demo FROM idea_matches m
     JOIN users u ON u.id = m.partner_id WHERE m.idea_id = ? ORDER BY m.created_at DESC',
    [$id]
);
$myMatch = null;
foreach ($matches as $m) {
    if ($uid && (int) $m['partner_id'] === $uid) {
        $myMatch = $m;
        break;
    }
}
$canSeeMatches = $isOwner || $isAdmin;
$openInterest = 0;
foreach ($matches as $m) {
    if (in_array($m['status'], ['interested', 'in_discussion', 'accepted'], true)) {
        $openInterest++;
    }
}

$page_title = $idea['title'];
$page_description = excerpt($idea['problem'], 155);
$active = 'explore';
$breadcrumbs = [['Idea Board', 'pages/ideas.php'], [$idea['title'], null]];
require __DIR__ . '/../includes/header.php';
?>
<section class="section-pad-sm section-cream">
  <div class="container">
    <div class="row g-4 align-items-start">
      <div class="col-lg-8">
        <div class="d-flex flex-wrap gap-2 mb-2">
          <span class="badge badge-stage"><?= e($idea['category']) ?></span>
          <span class="badge badge-tag"><?= e($idea['stage']) ?></span>
          <?= status_badge($idea['status']) ?>
          <?php if ($idea['ready_for_matching']): ?><span class="badge text-bg-warning"><i class="bi bi-link-45deg me-1"></i>Ready for matching</span><?php endif; ?>
          <?= demo_badge($idea['is_demo']) ?>
          <?php if ($idea['visibility'] !== 'public'): ?><span class="badge badge-soft"><i class="bi bi-eye-slash me-1"></i><?= e(ucfirst($idea['visibility'])) ?></span><?php endif; ?>
        </div>
        <h1 class="display-6 mt-2 mb-2"><?= e($idea['title']) ?></h1>
        <div class="meta-row mb-3">
          <span><i class="bi bi-person me-1"></i>By <a href="<?= e(url('pages/profile.php?u=' . urlencode($idea['username']))) ?>"><?= e($idea['name']) ?></a></span>
          <span><i class="bi bi-clock me-1"></i><?= e(time_ago($idea['created_at'])) ?></span>
          <span><i class="bi bi-hand-thumbs-up me-1"></i><?= $supportCount ?> supports</span>
          <span><i class="bi bi-chat me-1"></i><?= count($comments) ?> comments</span>
        </div>
      </div>
      <div class="col-lg-4">
        <div class="panel panel-body">
          <div class="small-caps mb-2">Owner</div>
          <div class="d-flex align-items-center gap-2 mb-2">
            <?= avatar_html($idea, $idea, 'sm') ?>
            <div>
              <a class="fw-semibold text-decoration-none" href="<?= e(url('pages/profile.php?u=' . urlencode($idea['username']))) ?>"><?= e($idea['name']) ?></a>
              <div class="small text-muted"><?= e(excerpt($idea['headline'] ?: role_label($idea['owner_role']), 70)) ?></div>
            </div>
          </div>
          <?php if ($canEdit): ?>
            <div class="d-grid gap-2">
              <a class="btn btn-sm btn-outline-brown" href="<?= e(url('pages/idea-form.php?id=' . $id)) ?>"><i class="bi bi-pencil me-1"></i>Edit idea</a>
              <form method="post" action="<?= e(url('pages/idea-detail.php?id=' . $id . '#matching')) ?>">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="toggle_ready">
                <button class="btn btn-sm <?= $idea['ready_for_matching'] ? 'btn-outline-brown' : 'btn-gold' ?> w-100" type="submit">
                  <?= $idea['ready_for_matching'] ? 'Stop matching' : 'Mark ready for matching' ?>
                </button>
              </form>
            </div>
          <?php endif; ?>
          <hr>
          <div id="support">
            <?php if (is_logged_in()): ?>
              <form method="post" action="<?= e(url('pages/idea-detail.php?id=' . $id . '#support')) ?>">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="support">
                <button class="btn <?= $hasSupported ? 'btn-outline-brown' : 'btn-brown' ?> w-100" type="submit">
                  <i class="bi bi-hand-thumbs-up me-1"></i><?= $hasSupported ? 'Supported — remove' : 'Support this idea' ?> (<?= $supportCount ?>)
                </button>
              </form>
            <?php else: ?>
              <a class="btn btn-gold w-100" href="<?= e(url('pages/login.php?next=' . urlencode('pages/idea-detail.php?id=' . $id))) ?>">Sign in to support</a>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="section-pad-sm">
  <div class="container">
    <?= error_summary($errors) ?>
    <div class="row g-4">
      <div class="col-lg-8">
        <div class="panel panel-body mb-4">
          <h2 class="h5"><i class="bi bi-exclamation-circle me-2 text-gold"></i>The problem</h2>
          <div class="text-muted" style="white-space:pre-line"><?= e($idea['problem']) ?></div>
          <hr>
          <h2 class="h5"><i class="bi bi-lightbulb me-2 text-gold"></i>The first idea</h2>
          <div class="text-muted" style="white-space:pre-line"><?= e($idea['solution']) ?></div>
        </div>

        <div class="panel panel-body" id="comments">
          <div class="d-flex justify-content-between align-items-center mb-2">
            <h2 class="h5 mb-0">Comments</h2>
            <span class="badge badge-soft"><?= count($comments) ?></span>
          </div>
          <?php if (!$comments): ?><p class="small text-muted">No comments yet. Ask a useful question or share a relevant experience.</p><?php endif; ?>
          <?php foreach ($comments as $c): ?>
            <div class="d-flex gap-3 border-bottom py-3">
              <?= avatar_html($c, $c, 'sm') ?>
              <div class="flex-grow-1 min-w-0">
                <div class="d-flex justify-content-between gap-2">
                  <div class="small"><a class="fw-semibold text-decoration-none" href="<?= e(url('pages/profile.php?u=' . urlencode($c['username']))) ?>"><?= e($c['name']) ?></a> <?= demo_badge($c['is_demo']) ?> <span class="text-muted">· <?= e(time_ago($c['created_at'])) ?></span></div>
                  <?php if ($uid && ((int) $c['user_id'] === $uid || $isAdmin)): ?>
                    <form method="post" action="<?= e(url('pages/idea-detail.php?id=' . $id . '#comments')) ?>" data-confirm="Remove this comment?">
                      <?= csrf_field() ?>
                      <input type="hidden" name="action" value="delete_comment">
                      <input type="hidden" name="comment_id" value="<?= (int) $c['id'] ?>">
                      <button class="btn btn-link btn-sm p-0 text-muted" type="submit" aria-label="Remove comment">Remove</button>
                    </form>
                  <?php endif; ?>
                </div>
                <div class="small mt-1" style="white-space:pre-line"><?= e($c['body']) ?></div>
              </div>
            </div>
          <?php endforeach; ?>

          <?php if (is_logged_in()): ?>
            <form class="mt-3" method="post" action="<?= e(url('pages/idea-detail.php?id=' . $id . '#comments')) ?>">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="comment">
              <label class="form-label" for="body">Add a comment</label>
              <textarea class="form-control <?= isset($errors['comment']) ? 'is-invalid' : '' ?>" id="body" name="body" rows="3" maxlength="2000" required placeholder="Ask a question or offer a useful perspective."></textarea>
              <?= field_error($errors, 'comment') ?>
              <button class="btn btn-brown mt-2" type="submit">Post comment</button>
            </form>
          <?php else: ?>
            <div class="alert alert-info mt-3 mb-0 small"><a href="<?= e(url('pages/login.php?next=' . urlencode('pages/idea-detail.php?id=' . $id . '#comments'))) ?>">Sign in</a> to join the conversation.</div>
          <?php endif; ?>
        </div>
      </div>

      <aside class="col-lg-4">
        <div class="panel panel-body mb-4" id="matching">
          <div class="small-caps mb-2">Matching</div>
          <?php if (!$idea['ready_for_matching']): ?>
            <p class="small text-muted mb-0">The owner has not marked this idea ready for matching yet. You can still support it or leave a comment.</p>
          <?php else: ?>
            <p class="small text-muted">This idea is open to a conversation with a mentor or partner. Matching is a first conversation, not a commitment.</p>
            <?php if ($openInterest): ?><p class="small"><span class="badge badge-stage"><?= $openInterest ?> open interest<?= $openInterest === 1 ? '' : 's' ?></span></p><?php endif; ?>

            <?php if ($canSeeMatches): ?>
              <?php if (!$matches): ?><p class="small text-muted">No match interest yet. Admins can see this idea and may suggest a connection.</p><?php endif; ?>
              <?php foreach ($matches as $m): ?>
                <div class="border rounded-3 p-2 mb-2">
                  <div class="d-flex justify-content-between align-items-start gap-2">
                    <div class="small"><a class="fw-semibold text-decoration-none" href="<?= e(url('pages/profile.php?u=' . urlencode($m['username']))) ?>"><?= e($m['name']) ?></a> <?= demo_badge($m['is_demo']) ?><div class="text-muted"><?= e(role_label($m['role'])) ?></div></div>
                    <?= status_badge($m['status']) ?>
                  </div>
                  <?php if ($m['note']): ?><p class="small text-muted mt-1 mb-1" style="white-space:pre-line"><?= e($m['note']) ?></p><?php endif; ?>
                  <?php if ($isOwner && in_array($m['status'], ['interested', 'in_discussion'], true)): ?>
                    <div class="d-flex gap-1 mt-2">
                      <form method="post" action="<?= e(url('pages/idea-detail.php?id=' . $id . '#matching')) ?>">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="respond_match">
                        <input type="hidden" name="match_id" value="<?= (int) $m['id'] ?>">
                        <input type="hidden" name="response" value="accepted">
                        <button class="btn btn-sm btn-gold" type="submit">Accept</button>
                      </form>
                      <form method="post" action="<?= e(url('pages/idea-detail.php?id=' . $id . '#matching')) ?>" data-confirm="Close this match conversation?">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="respond_match">
                        <input type="hidden" name="match_id" value="<?= (int) $m['id'] ?>">
                        <input type="hidden" name="response" value="closed">
                        <button class="btn btn-sm btn-outline-brown" type="submit">Decline</button>
                      </form>
                    </div>
                  <?php endif; ?>
                </div>
              <?php endforeach; ?>

              <?php if ($isAdmin): ?>
                <hr>
                <details>
                  <summary class="small fw-semibold">Admin: create a manual match</summary>
                  <?php
                  $partners = db_all("SELECT id, name, role FROM users WHERE role IN ('mentor','partner') AND status = 'active' ORDER BY role, name");
                  ?>
                  <form method="post" action="<?= e(url('pages/idea-detail.php?id=' . $id . '#matching')) ?>" class="mt-2">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="admin_match">
                    <label class="form-label" for="partner_id">Mentor or partner</label>
                    <select class="form-select form-select-sm <?= isset($errors['partner_id']) ? 'is-invalid' : '' ?>" id="partner_id" name="partner_id" required>
                      <option value="">Choose an account</option>
                      <?php foreach ($partners as $p): ?><option value="<?= (int) $p['id'] ?>"><?= e($p['name']) ?> (<?= e($p['role']) ?>)</option><?php endforeach; ?>
                    </select>
                    <?= field_error($errors, 'partner_id') ?>
                    <label class="form-label mt-2" for="match_note">Note shown to both people</label>
                    <textarea class="form-control form-control-sm <?= isset($errors['note']) ? 'is-invalid' : '' ?>" id="match_note" name="note" rows="2" required></textarea>
                    <?= field_error($errors, 'note') ?>
                    <button class="btn btn-sm btn-brown mt-2 w-100" type="submit">Create match</button>
                  </form>
                </details>
              <?php endif; ?>

            <?php elseif (in_array(user_role(), ['mentor', 'partner'], true) && !$isOwner): ?>
              <?php if ($myMatch): ?>
                <div class="alert alert-info small mb-0">You already expressed interest. Status: <?= status_badge($myMatch['status']) ?>. The owner can respond from their dashboard.</div>
              <?php else: ?>
                <form method="post" action="<?= e(url('pages/idea-detail.php?id=' . $id . '#matching')) ?>">
                  <?= csrf_field() ?>
                  <input type="hidden" name="action" value="interest">
                  <label class="form-label" for="note">How could you help?</label>
                  <textarea class="form-control <?= isset($errors['note']) ? 'is-invalid' : '' ?>" id="note" name="note" rows="3" maxlength="1000" required placeholder="A short, specific offer of support."></textarea>
                  <?= field_error($errors, 'note') ?>
                  <button class="btn btn-gold w-100 mt-2" type="submit">Offer to support</button>
                </form>
              <?php endif; ?>
            <?php else: ?>
              <p class="small text-muted mb-0">Mentors and partners can offer support here. If you are a member, keep building evidence and mark your idea ready when it is time.</p>
            <?php endif; ?>
          <?php endif; ?>
        </div>

        <?php if ($canEdit): ?>
          <div class="panel panel-body">
            <div class="small-caps mb-2">Owner controls</div>
            <form method="post" action="<?= e(url('pages/idea-detail.php?id=' . $id . '#matching')) ?>">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="status">
              <label class="form-label" for="status">Idea status</label>
              <select class="form-select form-select-sm mb-2" id="status" name="status">
                <?php foreach (['open', 'in_discussion', 'matched', 'closed'] as $st): ?><option value="<?= e($st) ?>" <?= $idea['status'] === $st ? 'selected' : '' ?>><?= e(ucfirst(str_replace('_', ' ', $st))) ?></option><?php endforeach; ?>
              </select>
              <button class="btn btn-sm btn-outline-brown w-100" type="submit">Update status</button>
            </form>
            <p class="form-text mt-2 mb-0">Visibility: <?= e(ucfirst($idea['visibility'])) ?>. Change it by editing the idea.</p>
          </div>
        <?php endif; ?>
      </aside>
    </div>
  </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>

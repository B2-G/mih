<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_login();
$id = get_int('id');
if (!$id) {
    not_found('No room was selected.');
}
$room = db_one(
    "SELECT r.*, t.name AS team_name, u.name AS creator_name
     FROM rooms r LEFT JOIN teams t ON t.id = r.team_id LEFT JOIN users u ON u.id = r.created_by
     WHERE r.id = ?",
    [$id]
);
if (!$room) {
    not_found('That room does not exist.');
}
$me = current_user();
if (!can_access_room($room, $me)) {
    forbidden('This is a private team room. Only team members and admins can open it.');
}

$uid = user_id();
$canModerate = is_admin();

// **NEW: Get recording status**
$isRecording = db_one(
    'SELECT 1 FROM room_recording WHERE room_id = ? AND user_id = ? LIMIT 1',
    [$room['id'], $uid]
);
$allRecordings = db_all(
    'SELECT user_id, started_at FROM room_recording WHERE room_id = ? ORDER BY started_at DESC',
    [$room['id']]
);

// **NEW: Task tracking**
$tasks = [];
if ($room['type'] === 'team' && !empty($room['team_id'])) {
    $tasks = db_all(
        'SELECT * FROM team_tasks WHERE room_id = ? ORDER BY priority DESC, created_at ASC',
        [$room['id']]
    );
}

// **NEW: Activity stats for chart**
$activityStats = db_one(
    'SELECT 
       COUNT(*) as total_messages,
       COUNT(DISTINCT user_id) as active_users,
       SUM(CASE WHEN is_system = 1 THEN 0 ELSE 1 END) as user_messages
     FROM room_messages WHERE room_id = ?',
    [$room['id']]
);

$messages = db_all(
    'SELECT rm.*, u.name, u.username, u.is_demo, p.photo
     FROM room_messages rm JOIN users u ON u.id = rm.user_id LEFT JOIN profiles p ON p.user_id = u.id
     WHERE rm.room_id = ? AND rm.is_deleted = 0 ORDER BY rm.id DESC LIMIT 60',
    [$room['id']]
);
$messages = array_reverse($messages);
$lastId = $messages ? (int) end($messages)['id'] : 0;

$memberCount = 0;
$members = [];
if ($room['type'] === 'team' && $room['team_id']) {
    $memberCount = db_count('SELECT COUNT(*) FROM team_members WHERE team_id = ?', [(int) $room['team_id']]);
    $members = db_all(
        'SELECT u.id, u.name, u.username, u.is_demo, p.photo FROM team_members tm
         JOIN users u ON u.id = tm.user_id LEFT JOIN profiles p ON p.user_id = u.id
         WHERE tm.team_id = ? ORDER BY tm.role = "lead" DESC LIMIT 12',
        [(int) $room['team_id']]
    );
}

$page_title = $room['name'];
$page_description = excerpt((string) ($room['description'] ?: 'A collaboration room in the Mindset Innovators Hub pilot.'), 155);
$active = 'explore';
$breadcrumbs = [['Collaboration Rooms', 'rooms.php'], [$room['name'], null]];

require __DIR__ . '/../includes/header.php';
?>
<main id="main-content">
<section class="section-pad-sm section-cream">
  <div class="container">
    <div class="d-flex flex-wrap justify-content-between align-items-start gap-3">
      <div>
        <div class="d-flex flex-wrap gap-2 mb-2">
          <span class="badge <?= $room['type'] === 'public' ? 'badge-stage' : 'badge-soft' ?>">
            <i class="bi <?= $room['type'] === 'public' ? 'bi-globe2' : 'bi-lock' ?> me-1"></i><?= $room['type'] === 'public' ? 'Public room' : 'Team room' ?>
          </span>
          <?= demo_badge($room['is_demo']) ?>
          <?php if ($room['type'] === 'team' && $room['team_id']): ?><a class="badge badge-tag text-decoration-none" href="<?= e(url('pages/team.php?id=' . (int) $room['team_id'])) ?>"><i class="bi bi-people me-1"></i><?= e($room['team_name'] ?: 'Team') ?></a><?php endif; ?>
        </div>
        <h1 class="h2 mt-2 mb-1">#<?= e($room['name']) ?></h1>
        <p class="text-muted mb-0"><?= e($room['description'] ?: 'A space for the community to talk, ask and share progress.') ?></p>
      </div>
      <div class="text-lg-end">
        <span class="poll-indicator" id="pollStatus"><span class="dot"></span><span id="pollLabel">Live · checks every few seconds</span></span>
        <div class="small text-muted mt-1"><?= $memberCount ? $memberCount . ' team member' . ($memberCount === 1 ? '' : 's') : 'Open to signed-in accounts' ?></div>
        <!-- **NEW: Recording indicator** -->
        <?php if ($canModerate || $isRecording): ?>
        <div class="mt-2">
          <?php if ($isRecording): ?>
            <span class="badge bg-red text-white small">�ape Recording active - <?= date('H:i:s', strtotime($allRecordings[0]['started_at'] ?? 'now')) ?></span>
          <?php else: ?>
            <span class="badge bg-gray small">�ape Recording</span>
            <button class="btn btn-sm btn-outline-secondary mt-1" onclick="toggleRecording()">Start Recording</button>
          <?php endif; ?>
        </div>
        <?php endif; ?>
        <!-- **NEW: Task stats** -->
        <?php if ($room['type'] === 'team' && !empty($room['team_id']) && $tasks): ?>
        <div class="mt-2 small">
          <span class="badge bg-primary small">Tasks: <?= count($tasks) ?></span>
          <?php foreach ($tasks as $t): ?>
            <span class="badge bg-light text-primary rounded-pill px-2 py-1 small ms-1<?= $t['completed'] ? ' completed' : '' ?>" title="<?= $t['title'] ?>"><?= substr($t['title'], 0, 12) . (strlen($t['title']) > 12 ? '…' : '') ?></span>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</section>

<section class="section-pad-sm">
  <div class="container">
    <div class="row g-4">
      <div class="col-lg-8">
        <div class="chat-shell" data-room-id="<?= $room['id'] ?>" data-last-id="<?= $lastId ?>" data-can-moderate="<?= $canModerate ? '1' : '0' ?>" data-csrf="<?= e(csrf_token()) ?>" id="chatShell">
          <div class="chat-window" id="chatWindow" aria-live="polite" aria-label="Room messages">
            <?php if (!$messages): ?>
              <div class="text-center text-muted small py-5" id="emptyRoom"><i class="bi bi-chat-square-dots display-5 d-block mb-2"></i>No messages yet. Say hello or share what you are working on.</div>
            <?php endif; ?>
            <?php foreach ($messages as $m): echo chat_message_html($m, $uid, $canModerate); endforeach; ?>
          </div>
          <div class="chat-form">
            <div class="alert alert-danger py-2 small d-none" id="chatError" role="alert"></div>
            <form method="post" action="<?= e(url('api/room_messages.php')) ?>" id="chatForm">
              <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="room_id" value="<?= $id ?>">
              <input type="hidden" name="action" value="send">
              <label class="form-label" for="chatBody">Write a message</label>
              <textarea class="form-control" id="chatBody" name="body" rows="2" maxlength="2000" required
                        placeholder="Share progress, ask a specific question, or offer help…"></textarea>
              <div class="d-flex justify-content-between align-items-center mt-2 gap-2">
                <span class="form-text">Enter to send, Shift + Enter for a new line. Be kind and constructive.</span>
                <button class="btn btn-gold" type="submit" id="chatSend"><i class="bi bi-send me-1"></i>Send</button>
              </div>
            </form>
          </div>
        </div>
      </div>

      <aside class="col-lg-4">
        <?php if ($members): ?>
          <div class="panel panel-body mb-3">
            <div class="small-caps mb-2">In this room</div>
            <?php foreach ($members as $member): ?>
              <a class="d-flex align-items-center gap-2 text-decoration-none py-2 border-bottom" href="<?= e(url('pages/profile.php?u=' . urlencode($member['username']))) ?>">
                <?= avatar_html($member, $member, 'xs') ?>
                <span class="small fw-semibold text-dark-brown"><?= e($member['name']) ?></span>
                <?= demo_badge($member['is_demo']) ?>
              </a>
            <?php endforeach; ?>
            <?php if ($memberCount > count($members)): ?><div class="small text-muted mt-2">and <?= $memberCount - count($members) ?> more</div><?php endif; ?>
          </div>
        <?php endif; ?>
        <div class="panel panel-body mb-3">
          <div class="small-caps mb-2">Keeping this space useful</div>
          <ul class="small text-muted ps-3 mb-0">
            <li class="mb-2">Write one clear message rather than several fragments.</li>
            <li class="mb-2">Use @username to get someone's attention.</li>
            <li class="mb-2">Never share passwords, private contact details or someone else's story without consent.</li>
            <li>Report a message if it feels unsafe.</li>
          </ul>
        </div>
        <div class="panel panel-body">
          <div class="small-caps mb-2">Room access</div>
          <p class="small text-muted mb-2"><?= $room['type'] === 'public' ? 'Every signed-in account can read and post here.' : 'Only members of this team and admins can read and post here.' ?></p>
          <a class="btn btn-sm btn-outline-brown w-100" href="<?= e(url('pages/rooms.php')) ?>"><i class="bi bi-arrow-left me-1"></i>All rooms</a>
        </div>
      </aside>
    </div>
  </div>
</section>

<!-- **NEW: Task Management Modal** -->
<div class="modal fade" id="taskModal" tabindex="-1" aria-labelledby="taskModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <form id="taskForm">
        <div class="modal-header">
          <h2 class="modal-title h5" id="taskModalLabel">Task Management</h2>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <input type="hidden" id="taskAction" name="subaction">
          <input type="hidden" id="taskId" name="task_id">
          <div class="mb-3">
            <label class="form-label">Task Title</label>
            <input type="text" class="form-control" id="newTaskTitle" placeholder="Enter task title">
          </div>
          <div class="row mb-3">
            <div class="col-md-4">
              <label class="form-label">Priority</label>
              <select class="form-select form-select-sm" id="newTaskPriority">
                <option value="1">High</option>
                <option value="2">Medium</option>
                <option value="3">Low</option>
              </select>
            </div>
            <div class="col-md-4">
              <label class="form-label">Deadline</label>
              <input type="date" class="form-control form-control-sm" id="newTaskDeadline">
            </div>
            <div class="col-md-4">
              <label class="form-label">Assignee</label>
              <select class="form-select form-select-sm" id="newTaskAssignee">
                <option value="0">Anyone</option>
                <?php foreach ($members as $m): ?>
                  <option value="<?= $m['id'] ?>"><?= e($m['name']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-brown" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-gold">Add Task</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- **NEW: Recording Toggle Modal** -->
<div class="modal fade" id="recordModal" tabindex="-1" aria-labelledby="recordModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <form id="recordForm">
        <div class="modal-header">
          <h2 class="modal-title h5" id="recordModalLabel">Recording</h2>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <p>Recording is now <span id="recordingStatus">active</span> for this room.</p>
          <input type="hidden" name="action" value="record">
          <input type="hidden" name="room_id" value="<?= $room['id'] ?>">
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-brown" data-bs-dismiss="modal">Stop</button>
          <button type="submit" class="btn btn-gold">Continue Recording</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
  'use strict';
  var shell = document.getElementById('chatShell');
  if (!shell) { return; }
  var roomId = shell.getAttribute('data-room-id');
  var lastId = parseInt(shell.getAttribute('data-last-id') || '0', 10);
  var csrf = shell.getAttribute('data-csrf');
  var canModerate = shell.getAttribute('data-can-moderate') === '1';
  var windowEl = document.getElementById('chatWindow');
  var form = document.getElementById('chatForm');
  var body = document.getElementById('chatBody');
  var sendBtn = document.getElementById('chatSend');
  var errorBox = document.getElementById('chatError');
  var empty = document.getElementById('emptyRoom');
  var pollStatus = document.getElementById('pollStatus');
  var pollLabel = document.getElementById('pollLabel');
  var timer = null;

  // **NEW: Recording state**
  var isRecording = <?= ($isRecording !== null && $isRecording) ? 'true' : 'false' ?>;
  var recordings = <?= json_encode($allRecordings) || '[]' ?>;
  var recordingEl = document.querySelector('.recording-indicator');
  var toggleRecordingBtn = document.querySelector('#toggleRecordingBtn');

  function updateRecordingUI() {
    if (isRecording) {
      document.body.classList.add('recording-active');
      if (recordingEl) {
        recordingEl.innerHTML = '�ape Recording active - ' + new Date().toLocaleTimeString();
      }
      if (toggleRecordingBtn) {
        toggleRecordingBtn.textContent = 'Stop Recording';
      }
    } else {
      document.body.classList.remove('recording-active');
      if (recordingEl) {
        recordingEl.innerHTML = '�ape Recording';
      }
      if (toggleRecordingBtn) {
        toggleRecordingBtn.textContent = 'Start Recording';
      }
    }
  }
  updateRecordingUI();

  function toggleRecording() {
    fetch(shell.closest('.container').querySelector('#chatForm').action, {
      method: 'POST',
      headers: {'X-CSRF-Token': csrf, 'X-Requested-With': 'XMLHttpRequest'},
      body: new FormData().append('action', 'record').append('room_id', roomId)
    }).then(function (response) { return response.json(); }).then(function (result) {
      isRecording = result.recording;
      updateRecordingUI();
    });
  }

  function scrollToEnd() {
    windowEl.scrollTop = windowEl.scrollHeight;
  }
  function showError(message) {
    errorBox.textContent = message;
    errorBox.classList.remove('d-none');
  }
  function clearError() {
    errorBox.classList.add('d-none');
    errorBox.textContent = '';
  }
  function api(data) {
    return fetch(shell.closest('.container').querySelector('#chatForm').action, {
      method: 'POST',
      headers: {'X-CSRF-Token': csrf, 'X-Requested-With': 'XMLHttpRequest'},
      body: data,
      credentials: 'same-origin'
    }).then(function (response) { return response.json(); }).catch(function () { return {ok: false, error: 'The server returned an unexpected response.'}; });
  }
  function appendMessages(messages) {
    if (!messages || !messages.length) { return; }
    if (empty) { empty.remove(); empty = null; }
    messages.forEach(function (m) {
      if (document.querySelector('[data-message-id="' + m.id + '"]')) { return; }
      var wrap = document.createElement('div');
      wrap.innerHTML = m.html;
      var node = wrap.firstElementChild;
      if (node) { windowEl.appendChild(node); }
      if (m.id > lastId) { lastId = m.id; }
    });
    scrollToEnd();
  }
  function poll() {
    if (document.hidden) { return; }
    pollStatus.classList.add('is-loading');
    fetch(shell.closest('.container').querySelector('#chatForm').action + '?room_id=' + encodeURIComponent(roomId) + '&after=' + encodeURIComponent(lastId), {
      headers: {'X-Requested-With': 'XMLHttpRequest'},
      credentials: 'same-origin'
    }).then(function (response) { return response.json(); }).then(function (data) {
      pollStatus.classList.remove('is-loading');
      if (data && data.ok) {
        appendMessages(data.messages || []);
        // **NEW: Update recording UI**
        isRecording = data.recordings && data.recordings.length > 0;
        recordings = data.recordings || [];
        updateRecordingUI();
        pollLabel.textContent = 'Live · updated ' + new Date().toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'});
      }
    }).catch(function () {
      pollStatus.classList.remove('is-loading');
      pollLabel.textContent = 'Reconnecting…';
    });
  }
  function startPolling() {
    if (timer) { clearInterval(timer); }
    timer = setInterval(poll, 4500);
  }

  form.addEventListener('submit', function (event) {
    event.preventDefault();
    clearError();
    var text = body.value.trim();
    if (text.length < 1) { showError('Write a message before sending.'); body.focus(); return; }
    sendBtn.disabled = true;
    var data = new FormData();
    data.append('action', 'send');
    data.append('room_id', roomId);
    data.append('body', text);
    api(data).then(function (result) {
      if (!result.ok) { showError(result.error || 'The message could not be sent.'); return; }
      body.value = '';
      appendMessages([result.message]);
      // **NEW: Update recording UI from result**
      isRecording = result.recording;
      recordings = result.recordings || [];
      updateRecordingUI();
      pollStatus.classList.remove('is-loading');
    }).catch(function () {
      showError('The message could not be sent. Check your connection and try again.');
    }).finally(function () {
      sendBtn.disabled = false;
      body.focus();
    });
  });

  body.addEventListener('keydown', function (event) {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      if (form.requestSubmit) { form.requestSubmit(); } else { form.dispatchEvent(new Event('submit', {cancelable: true})); }
    }
  });

  document.getElementById('reportForm').addEventListener('submit', function (event) {
    event.preventDefault();
    var reason = document.getElementById('reportReason').value.trim();
    var reportError = document.getElementById('reportError');
    if (reason.length < 5) {
      reportError.textContent = 'Please add a little more detail.';
      reportError.classList.remove('d-none');
      return;
    }
    var d = new FormData();
    d.append('action', 'report');
    d.append('room_id', roomId);
    d.append('message_id', document.getElementById('reportMessageId').value);
    d.append('reason', reason);
    api(d).then(function (result) {
      if (!result.ok) {
        reportError.textContent = result.error || 'The report could not be sent.';
        reportError.classList.remove('d-none');
        return;
      }
      bootstrap.Modal.getOrCreateInstance(document.getElementById('reportModal')).hide();
      var note = document.createElement('div');
      note.className = 'alert alert-success py-2 small mx-3 mb-0';
      note.textContent = 'Thank you. An admin will review this report.';
      windowEl.parentNode.insertBefore(note, windowEl.nextSibling);
    });
  });

  // **NEW: Task management**
  function loadTasks() {
    fetch(shell.closest('.container').querySelector('#chatForm').action + '?room_id=' + roomId + '&task=list', {
      headers: {'X-CSRF-Token': csrf, 'X-Requested-With': 'XMLHttpRequest'}
    }).then(function (response) { return response.json(); }).then(function (data) {
      renderTasks(data.tasks || []);
    });
  }
  function renderTasks(tasks) {
    var taskContainer = document.querySelector('.mt-2 small');
    if (!taskContainer) return;
    taskContainer.innerHTML = '';
    if (tasks.length === 0) {
      taskContainer.textContent = 'No tasks';
      return;
    }
    taskContainer.innerHTML = '<span class="badge bg-primary small">Tasks: ' + tasks.length + '</span>';
    tasks.forEach(function (t) {
      var badge = document.createElement('span');
      badge.className = 'badge bg-light text-primary rounded-pill px-2 py-1 small ms-1' + (t.completed ? ' completed' : '');
      badge.title = t.title;
      badge.textContent = t.title.substring(0, 12) + (t.title.length > 12 ? '…' : '');
      taskContainer.appendChild(badge);
    });
  }

  // **NEW: Recording toggle**
  var toggleRecordingBtn = document.querySelector('#toggleRecordingBtn');
  if (toggleRecordingBtn) {
    toggleRecordingBtn.addEventListener('click', toggleRecording);
  }

  // **NEW: Task form submit**
  document.getElementById('taskForm').addEventListener('submit', function (e) {
    e.preventDefault();
    var action = document.getElementById('taskAction').value;
    var taskId = document.getElementById('taskId').value;
    var formData = new FormData();
    formData.append('action', action);
    formData.append('room_id', roomId);
    if (action === 'create') {
      formData.append('title', document.getElementById('newTaskTitle').value);
      formData.append('priority', document.getElementById('newTaskPriority').value);
      formData.append('deadline', document.getElementById('newTaskDeadline').value);
      formData.append('assignee', document.getElementById('newTaskAssignee').value);
    }
    api(formData).then(function (result) {
      bootstrap.Modal.getOrCreateInstance(document.getElementById('taskModal')).hide();
      loadTasks();
    });
  });

  // Initialize
  loadTasks();
  poll();
  startPolling();
  scrollToEnd();

  // **NEW: Recording toggle click**
  if (toggleRecordingBtn) {
    toggleRecordingBtn.addEventListener('click', function() {
      toggleRecording();
    });
  }
});
</script>
</body>
</html>
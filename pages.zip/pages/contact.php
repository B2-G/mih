<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';

$page_title = 'Contact';
$page_description = 'Contact Mindset Innovators Hub about the pilot, mentoring, partnerships or the prototype.';
$active = 'contact';
$breadcrumbs = [['Contact', null]];

$errors = [];
$form = ['name' => '', 'email' => '', 'subject' => '', 'message' => ''];

if (is_post()) {
    require_csrf();
    foreach ($form as $key => $_) {
        $form[$key] = post($key);
    }
    if (post('website_url') !== '') {
        flash('success', 'Thank you. Your message has been received.');
        redirect('pages/contact.php');
    }
    if (!rate_limit_hit('contact_message', 5, 60)) {
        $errors['form'] = 'Too many messages from this connection. Please try again later.';
    }
    if (mb_strlen($form['name']) < 2 || mb_strlen($form['name']) > 120) {
        $errors['name'] = 'Please enter your name.';
    }
    if (!valid_email($form['email'])) {
        $errors['email'] = 'Please enter a valid email address.';
    }
    if (mb_strlen($form['subject']) < 3 || mb_strlen($form['subject']) > 160) {
        $errors['subject'] = 'Please add a subject (3–160 characters).';
    }
    if (mb_strlen($form['message']) < 20) {
        $errors['message'] = 'Please write at least 20 characters so we can help.';
    }
    if (!$errors) {
        db_run(
            'INSERT INTO contact_messages (name, email, subject, message, ip) VALUES (?, ?, ?, ?, ?)',
            [$form['name'], $form['email'], $form['subject'], $form['message'], client_ip()]
        );
        log_activity('contact.message', 'contact_message', (int) db()->lastInsertId(), $form['subject']);
        notify_admins('contact_message', 'New contact message: ' . $form['subject'], 'admin/enquiries.php');
        flash('success', 'Thank you. Your message has been saved for the team to review. Because this is a prototype without a mail server, no automatic email is sent.');
        redirect('pages/contact.php');
    }
}

require __DIR__ . '/../includes/header.php';
?>
<section class="section-pad-sm section-cream">
  <div class="container">
    <div class="row g-5">
      <div class="col-lg-5">
        <span class="eyebrow">Contact</span>
        <h1 class="display-4 mt-2 mb-3">Ask a real question.</h1>
        <p class="lead-lg">Whether you want to test the pilot, offer mentoring time, explore a partnership or point out a problem with the prototype, we would like to hear it.</p>
        <div class="panel p-4">
          <div class="small-caps mb-2">Email</div>
          <a class="h5 d-inline-flex align-items-center gap-2 text-decoration-none" href="mailto:<?= e(CONTACT_EMAIL) ?>"><i class="bi bi-envelope text-gold"></i><?= e(CONTACT_EMAIL) ?></a>
          <hr>
          <p class="small text-muted mb-2"><strong>Response note:</strong> this prototype does not send or receive email automatically. Messages submitted here appear in the admin area for review.</p>
          <p class="small text-muted mb-0"><strong>Privacy:</strong> submit only the information needed to answer your question. Demo content is clearly labelled.</p>
        </div>
        <div class="mt-4">
          <h2 class="h6">Common questions</h2>
          <div class="accordion" id="contactFaq">
            <div class="accordion-item">
              <h3 class="accordion-header"><button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq1">Is this a live platform?</button></h3>
              <div id="faq1" class="accordion-collapse collapse" data-bs-parent="#contactFaq"><div class="accordion-body small text-muted">No. It is a working prototype of the planned platform, built to test the journey with a pilot group. Demo data is seeded and labelled.</div></div>
            </div>
            <div class="accordion-item">
              <h3 class="accordion-header"><button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq2">How do I try the member features?</button></h3>
              <div id="faq2" class="accordion-collapse collapse" data-bs-parent="#contactFaq"><div class="accordion-body small text-muted">Create an account, or use one of the demo accounts in the README. Mentor and partner accounts are approved by an admin before their tools become available.</div></div>
            </div>
            <div class="accordion-item">
              <h3 class="accordion-header"><button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq3">How is my data handled?</button></h3>
              <div id="faq3" class="accordion-collapse collapse" data-bs-parent="#contactFaq"><div class="accordion-body small text-muted">This local prototype stores form entries in its MySQL database. It does not send email or share data with third parties. A live version would need a clear privacy policy and consent process.</div></div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-7">
        <div class="panel panel-body">
          <?= error_summary($errors) ?>
          <?php if (!empty($errors['form'])): ?><div class="alert alert-danger"><?= e($errors['form']) ?></div><?php endif; ?>
          <form method="post" action="<?= e(url('pages/contact.php')) ?>" class="needs-validation" novalidate data-single-submit>
            <?= csrf_field() ?>
            <div class="d-none" aria-hidden="true">
              <label for="website_url">Leave this field blank</label>
              <input type="text" id="website_url" name="website_url" tabindex="-1" autocomplete="off">
            </div>
            <div class="row g-3">
              <div class="col-md-6">
                <label class="form-label" for="name">Your name <span class="text-danger">*</span></label>
                <input class="form-control <?= isset($errors['name']) ? 'is-invalid' : '' ?>" id="name" name="name" required maxlength="120" autocomplete="name" value="<?= e($form['name']) ?>">
                <?= field_error($errors, 'name') ?>
              </div>
              <div class="col-md-6">
                <label class="form-label" for="email">Email <span class="text-danger">*</span></label>
                <input type="email" class="form-control <?= isset($errors['email']) ? 'is-invalid' : '' ?>" id="email" name="email" required maxlength="190" autocomplete="email" value="<?= e($form['email']) ?>">
                <?= field_error($errors, 'email') ?>
              </div>
              <div class="col-12">
                <label class="form-label" for="subject">Subject <span class="text-danger">*</span></label>
                <input class="form-control <?= isset($errors['subject']) ? 'is-invalid' : '' ?>" id="subject" name="subject" required maxlength="160" value="<?= e($form['subject']) ?>">
                <?= field_error($errors, 'subject') ?>
              </div>
              <div class="col-12">
                <label class="form-label" for="message">Message <span class="text-danger">*</span></label>
                <textarea class="form-control <?= isset($errors['message']) ? 'is-invalid' : '' ?>" id="message" name="message" required minlength="20" maxlength="4000" rows="6" data-counter="#msgCount"><?= e($form['message']) ?></textarea>
                <div class="form-text text-end" id="msgCount"></div>
                <?= field_error($errors, 'message') ?>
              </div>
            </div>
            <button class="btn btn-gold mt-4" type="submit">Send message</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>

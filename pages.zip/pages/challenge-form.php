<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_role(['admin', 'mentor', 'partner']);

$page_title = 'Create a Challenge';
$page_description = 'Publish a practical Build-to-Learn challenge for members of the pilot.';
$breadcrumbs = [['Challenges', 'pages/challenges.php'], ['Create', null]];
$errors = [];
$form = ['title' => '', 'description' => '', 'category' => '', 'difficulty' => 'Beginner', 'resources' => '', 'deadline' => '', 'sponsor_name' => '', 'status' => 'published'];

if (is_post()) {
    require_csrf();
    foreach ($form as $key => $_) {
        $form[$key] = post($key, is_string($_) ? $_ : '');
    }
    if (mb_strlen($form['title']) < 6 || mb_strlen($form['title']) > 180) {
        $errors['title'] = 'Give the challenge a clear title (6–180 characters).';
    }
    if (mb_strlen($form['description']) < 40) {
        $errors['description'] = 'Please describe the brief in at least 40 characters.';
    }
    if (mb_strlen($form['category']) < 2 || mb_strlen($form['category']) > 80) {
        $errors['category'] = 'Add a category (for example Environment or Technology).';
    }
    if (!in_array($form['difficulty'], ['Beginner', 'Intermediate', 'Advanced'], true)) {
        $errors['difficulty'] = 'Choose a difficulty level.';
    }
    if ($form['deadline'] !== '') {
        $d = DateTime::createFromFormat('Y-m-d', $form['deadline']);
        if (!$d || $d->format('Y-m-d') !== $form['deadline']) {
            $errors['deadline'] = 'Use a valid date.';
        } elseif ($form['deadline'] < date('Y-m-d')) {
            $errors['deadline'] = 'The deadline cannot be in the past.';
        }
    }
    if (mb_strlen($form['sponsor_name']) > 160) {
        $errors['sponsor_name'] = 'Keep the sponsor name to 160 characters or fewer.';
    }
    if (!is_admin()) {
        $form['status'] = 'published';
    } elseif (!in_array($form['status'], ['draft', 'published', 'closed'], true)) {
        $errors['status'] = 'Choose a valid status.';
    }
    if (!$errors) {
        db_run(
            'INSERT INTO challenges (title, description, category, difficulty, resources, deadline, sponsor_name, status, created_by, is_demo)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0)',
            [
                $form['title'], $form['description'], $form['category'], $form['difficulty'],
                $form['resources'] ?: null, $form['deadline'] ?: null, $form['sponsor_name'] ?: null,
                $form['status'], user_id(),
            ]
        );
        $id = (int) db()->lastInsertId();
        log_activity('challenge.created', 'challenge', $id, $form['title']);
        flash('success', 'The challenge has been created.');
        redirect('pages/challenge-detail.php?id=' . $id);
    }
}

require __DIR__ . '/../includes/header.php';
?>
<section class="section-pad">
  <div class="container">
    <div class="row g-4">
      <div class="col-lg-8">
        <div class="panel panel-body">
          <span class="eyebrow">Create a challenge</span>
          <h1 class="display-6 mt-2 mb-3">A short brief that leads to real work.</h1>
          <p class="text-muted">Keep the scope small enough to complete and specific enough to review. Include what a member should submit.</p>
          <?= error_summary($errors) ?>
          <form method="post" action="<?= e(url('pages/challenge-form.php')) ?>" class="needs-validation" novalidate data-single-submit>
            <?= csrf_field() ?>
            <div class="row g-3">
              <div class="col-12">
                <label class="form-label" for="title">Challenge title <span class="text-danger">*</span></label>
                <input class="form-control <?= isset($errors['title']) ? 'is-invalid' : '' ?>" id="title" name="title" required minlength="6" maxlength="180" value="<?= e($form['title']) ?>" placeholder="For example: Map one waste stream on your campus">
                <?= field_error($errors, 'title') ?>
              </div>
              <div class="col-md-6">
                <label class="form-label" for="category">Category <span class="text-danger">*</span></label>
                <input class="form-control <?= isset($errors['category']) ? 'is-invalid' : '' ?>" id="category" name="category" required maxlength="80" value="<?= e($form['category']) ?>" list="categorySuggestions" placeholder="Environment">
                <datalist id="categorySuggestions">
                  <?php foreach (db_all('SELECT DISTINCT category FROM challenges ORDER BY category') as $c): ?><option value="<?= e($c['category']) ?>"><?php endforeach; ?>
                </datalist>
                <?= field_error($errors, 'category') ?>
              </div>
              <div class="col-md-3">
                <label class="form-label" for="difficulty">Difficulty <span class="text-danger">*</span></label>
                <select class="form-select" id="difficulty" name="difficulty" required>
                  <?php foreach (['Beginner', 'Intermediate', 'Advanced'] as $d): ?><option value="<?= e($d) ?>" <?= $form['difficulty'] === $d ? 'selected' : '' ?>><?= e($d) ?></option><?php endforeach; ?>
                </select>
              </div>
              <div class="col-md-3">
                <label class="form-label" for="deadline">Deadline</label>
                <input type="date" class="form-control <?= isset($errors['deadline']) ? 'is-invalid' : '' ?>" id="deadline" name="deadline" min="<?= e(date('Y-m-d')) ?>" value="<?= e($form['deadline']) ?>">
                <?= field_error($errors, 'deadline') ?>
              </div>
              <div class="col-12">
                <label class="form-label" for="description">The brief <span class="text-danger">*</span></label>
                <textarea class="form-control <?= isset($errors['description']) ? 'is-invalid' : '' ?>" id="description" name="description" rows="6" required minlength="40" maxlength="6000" data-counter="#descCount"><?= e($form['description']) ?></textarea>
                <div class="form-text text-end" id="descCount"></div>
                <div class="form-text">Say what to do, what evidence to submit, and any constraints.</div>
                <?= field_error($errors, 'description') ?>
              </div>
              <div class="col-12">
                <label class="form-label" for="resources">Resources and links</label>
                <textarea class="form-control" id="resources" name="resources" rows="3" maxlength="3000" placeholder="One resource per line"><?= e($form['resources']) ?></textarea>
              </div>
              <div class="col-md-8">
                <label class="form-label" for="sponsor_name">Sponsor <span class="text-muted">(optional)</span></label>
                <input class="form-control <?= isset($errors['sponsor_name']) ? 'is-invalid' : '' ?>" id="sponsor_name" name="sponsor_name" maxlength="160" value="<?= e($form['sponsor_name']) ?>">
                <div class="form-text">Shown on the challenge card. Add a sponsor only with their permission.</div>
                <?= field_error($errors, 'sponsor_name') ?>
              </div>
              <?php if (is_admin()): ?>
                <div class="col-md-4">
                  <label class="form-label" for="status">Status</label>
                  <select class="form-select" id="status" name="status">
                    <option value="draft" <?= $form['status'] === 'draft' ? 'selected' : '' ?>>Draft</option>
                    <option value="published" <?= $form['status'] === 'published' ? 'selected' : '' ?>>Published</option>
                    <option value="closed" <?= $form['status'] === 'closed' ? 'selected' : '' ?>>Closed</option>
                  </select>
                </div>
              <?php endif; ?>
            </div>
            <div class="d-flex gap-2 mt-4">
              <button class="btn btn-gold" type="submit">Create challenge</button>
              <a class="btn btn-outline-brown" href="<?= e(url('pages/challenges.php')) ?>">Cancel</a>
            </div>
          </form>
        </div>
      </div>
      <div class="col-lg-4">
        <div class="panel panel-body">
          <div class="small-caps mb-2">What makes a good challenge</div>
          <ul class="small text-muted ps-3 mb-0">
            <li class="mb-2">One clear outcome, not a whole programme.</li>
            <li class="mb-2">A submission a reviewer can read in a few minutes.</li>
            <li class="mb-2">A realistic deadline for a first attempt.</li>
            <li class="mb-2">Resources that are relevant, not a reading list.</li>
            <li>Honest constraints: no invented data, no real patient details.</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>

<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_login();

if (!is_member()) {
    redirect(redirect_after_login());
}
$me = current_user();
$profile = db_one('SELECT * FROM profiles WHERE user_id = ?', [user_id()]);
if ($profile && (int) $profile['quiz_completed'] === 1 && !isset($_GET['retake'])) {
    redirect('pages/dashboard.php');
}

$page_title = 'Your starting point';
$page_description = 'A short onboarding quiz to choose your interests, skills and starting journey stage.';
$errors = [];
$interestOptions = ['Technology', 'Design', 'Business', 'Agriculture', 'Health', 'Education', 'Environment', 'Civic tech', 'Community', 'Content & media', 'Research', 'Sports'];
$allSkills = db_all('SELECT * FROM skills ORDER BY name');
$existingInterests = tags_to_array($profile['interests'] ?? '');
$existingSkills = db_all('SELECT skill_id FROM user_skills WHERE user_id = ?', [user_id()]);
$existingSkillIds = array_map(static fn($r) => (int) $r['skill_id'], $existingSkills);

if (is_post()) {
    require_csrf();
    $selectedInterests = array_values(array_intersect($interestOptions, array_map('strval', (array) ($_POST['interests'] ?? []))));
    $selectedSkills = array_values(array_filter(array_map('intval', (array) ($_POST['skills'] ?? []))));
    $stage = post('journey_stage', 'Discover');
    $goals = post('goals');
    if (!$selectedInterests) {
        $errors['interests'] = 'Choose at least one interest.';
    }
    if (!in_array($stage, array_keys(journey_stages()), true)) {
        $errors['journey_stage'] = 'Choose a starting stage.';
    }
    if (mb_strlen($goals) > 1000) {
        $errors['goals'] = 'Please use 1,000 characters or fewer.';
    }
    if (!$errors) {
        db()->beginTransaction();
        db_run('UPDATE profiles SET interests = ?, journey_stage = ?, goals = ?, quiz_completed = 1 WHERE user_id = ?', [
            implode(', ', $selectedInterests), $stage, $goals ?: null, user_id(),
        ]);
        foreach ($selectedSkills as $sid) {
            if (db_count('SELECT COUNT(*) FROM skills WHERE id = ?', [$sid])) {
                db_run('INSERT INTO user_skills (user_id, skill_id, level) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE level = VALUES(level)', [user_id(), $sid, 'Beginner']);
            }
        }
        db()->commit();
        refresh_badges(user_id());
        log_activity('onboarding.completed', 'profile', user_id(), $stage);
        flash('success', 'Your starting point is saved. You can refine your profile at any time.');
        redirect('pages/dashboard.php');
    }
}

$breadcrumbs = [['Onboarding', null]];
require __DIR__ . '/../includes/header.php';
?>
<section class="section-pad">
  <div class="container" style="max-width:900px">
    <div class="text-center mb-4">
      <span class="eyebrow d-inline-flex">One minute</span>
      <h1 class="display-5 mt-2">Where would you like to start?</h1>
      <p class="text-muted mx-auto max-55">This is a starting point, not a permanent label. Choose what feels useful now and change it whenever you like.</p>
    </div>
    <div class="panel panel-body">
      <div class="d-flex justify-content-between small text-muted mb-2"><span id="stepLabel">Step 1 of 3</span><span>All questions are optional except interests and stage</span></div>
      <div class="completeness mb-4"><span id="quizProgress" style="width:33%"></span></div>
      <?= error_summary($errors) ?>
      <form method="post" action="<?= e(url('pages/onboarding.php')) ?>" id="onboardingForm" class="needs-validation" novalidate>
        <?= csrf_field() ?>
        <div class="onboarding-step active" data-step="1">
          <h2 class="h4">What areas pull your attention?</h2>
          <p class="text-muted small">Pick a few. These help us suggest challenges, ideas and people.</p>
          <div class="row g-2">
            <?php foreach ($interestOptions as $interest): ?>
              <div class="col-6 col-md-4">
                <label class="choice-card small" for="interest_<?= e(md5($interest)) ?>">
                  <input type="checkbox" id="interest_<?= e(md5($interest)) ?>" name="interests[]" value="<?= e($interest) ?>" <?= in_array($interest, $existingInterests, true) ? 'checked' : '' ?>>
                  <?= e($interest) ?>
                </label>
              </div>
            <?php endforeach; ?>
          </div>
          <?= field_error($errors, 'interests') ?>
        </div>

        <div class="onboarding-step" data-step="2">
          <h2 class="h4">Which skills would you like to practise?</h2>
          <p class="text-muted small">These become tags on your profile. You can add a level later.</p>
          <div class="row g-2">
            <?php foreach ($allSkills as $skill): ?>
              <div class="col-6 col-md-4">
                <label class="choice-card small" for="skill_<?= (int) $skill['id'] ?>">
                  <input type="checkbox" id="skill_<?= (int) $skill['id'] ?>" name="skills[]" value="<?= (int) $skill['id'] ?>" <?= in_array((int) $skill['id'], $existingSkillIds, true) ? 'checked' : '' ?>>
                  <?= e($skill['name']) ?>
                </label>
              </div>
            <?php endforeach; ?>
          </div>
        </div>

        <div class="onboarding-step" data-step="3">
          <h2 class="h4">Where are you on the journey?</h2>
          <p class="text-muted small">A honest starting point is more useful than an ambitious one.</p>
          <div class="row g-2 mb-3">
            <?php $chosenStage = post('journey_stage', $profile['journey_stage'] ?? 'Discover'); foreach (journey_stages() as $stage => $desc): ?>
              <div class="col-md-6">
                <label class="choice-card small" for="stage_<?= e($stage) ?>">
                  <input type="radio" id="stage_<?= e($stage) ?>" name="journey_stage" value="<?= e($stage) ?>" <?= $chosenStage === $stage ? 'checked' : '' ?>>
                  <strong><?= e($stage) ?></strong><br><span class="text-muted"><?= e($desc) ?></span>
                </label>
              </div>
            <?php endforeach; ?>
          </div>
          <?= field_error($errors, 'journey_stage') ?>
          <div class="mb-2">
            <label class="form-label" for="goals">One goal for the next few weeks <span class="text-muted">(optional)</span></label>
            <textarea class="form-control" id="goals" name="goals" maxlength="1000" rows="3" placeholder="For example: finish one challenge and publish a first project."><?= e(post('goals', $profile['goals'] ?? '')) ?></textarea>
          </div>
          <div class="alert alert-info small mb-0"><i class="bi bi-info-circle me-1"></i>Completing activity can move you forward later, but you stay in control of your stage.</div>
        </div>

        <div class="d-flex justify-content-between mt-4">
          <button class="btn btn-outline-brown" type="button" id="prevStep" disabled>Back</button>
          <div class="d-flex gap-2">
            <button class="btn btn-outline-brown" type="button" id="nextStep">Next</button>
            <button class="btn btn-gold d-none" type="submit" id="finishStep">Save my starting point</button>
          </div>
        </div>
      </form>
    </div>
  </div>
</section>
<?php
$page_scripts = <<<'JS'
<script>
(function(){
  var step = 1, total = 3;
  var steps = document.querySelectorAll('.onboarding-step');
  var prev = document.getElementById('prevStep');
  var next = document.getElementById('nextStep');
  var finish = document.getElementById('finishStep');
  var bar = document.getElementById('quizProgress');
  var label = document.getElementById('stepLabel');
  function show(n){
    step = Math.max(1, Math.min(total, n));
    steps.forEach(function(s){ s.classList.toggle('active', Number(s.dataset.step) === step); });
    bar.style.width = (step / total * 100) + '%';
    label.textContent = 'Step ' + step + ' of ' + total;
    prev.disabled = step === 1;
    next.classList.toggle('d-none', step === total);
    finish.classList.toggle('d-none', step !== total);
    var heading = steps[step-1].querySelector('h2');
    if (heading) { heading.setAttribute('tabindex','-1'); heading.focus(); }
  }
  next.addEventListener('click', function(){ show(step + 1); });
  prev.addEventListener('click', function(){ show(step - 1); });
})();
</script>
JS;
require __DIR__ . '/../includes/footer.php';
?>

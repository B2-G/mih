<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';

$page_title = 'Explore the Hub';
$page_description = 'Explore the tools inside Mindset Innovators Hub: challenges, collaboration rooms, ideas, portfolio, mentors and opportunities.';
$active = 'explore';
$breadcrumbs = [['Explore the Hub', null]];

$counts = [
    'challenges'   => db_count("SELECT COUNT(*) FROM challenges WHERE status = 'published'"),
    'ideas'        => db_count("SELECT COUNT(*) FROM ideas WHERE visibility = 'public'"),
    'projects'     => db_count("SELECT COUNT(*) FROM projects WHERE status = 'published'"),
    'mentors'      => db_count("SELECT COUNT(*) FROM users WHERE role = 'mentor' AND status = 'active'"),
    'opportunities'=> db_count("SELECT COUNT(*) FROM opportunities WHERE status = 'approved'"),
    'rooms'        => db_count("SELECT COUNT(*) FROM rooms WHERE type = 'public'"),
];
$tools = [
    ['pages/challenges.php', 'bi-lightning-charge', 'Build-to-Learn Challenges', 'Learn, practise and build through short briefs. Submit work, receive written feedback and a score, then rate the challenge.', $counts['challenges'] . ' open'],
    ['pages/rooms.php', 'bi-chat-square-text', 'Collaboration Rooms', 'Join a public conversation or a team room. Messages post with AJAX and refresh every few seconds.', $counts['rooms'] . ' public rooms'],
    ['pages/ideas.php', 'bi-lightbulb', 'Idea Board & Matching', 'Post a problem and a proposed solution. Gather support, invite comments and mark an idea ready for a mentor or partner match.', $counts['ideas'] . ' public ideas'],
    ['pages/showcase.php', 'bi-collection', 'Impact Portfolio', 'Publish projects with links, screenshots and team credits. Every member gets a shareable and printable portfolio.', $counts['projects'] . ' projects'],
    ['pages/mentors.php', 'bi-person-check', 'Mentor Connections', 'Find an approved mentor by expertise. Send a request with context; accepted pairs continue in a private thread.', $counts['mentors'] . ' mentors'],
    ['pages/opportunities.php', 'bi-compass', 'Opportunity Bridge', 'Browse competitions, internships, training, grants, jobs and events. Save them or record your interest and applications.', $counts['opportunities'] . ' live listings'],
    ['pages/directory.php', 'bi-people', 'Member Directory', 'Search young innovators by skill, interest and location, and see what stage of the journey they are on.', 'Members only'],
    ['pages/leaderboard.php', 'bi-graph-up-arrow', 'Growth Leaderboard', 'See who is completing challenges, publishing projects and building with others. Growth, not empty points.', 'Live data'],
    ['pages/impact.php', 'bi-bar-chart', 'Impact Dashboard', 'See the pilot measured from its own database: participation, completion, projects, teams and satisfaction.', 'Admin view'],
];
require __DIR__ . '/../includes/header.php';
?>
<section class="section-pad-sm section-cream">
  <div class="container">
    <div class="row align-items-end g-4">
      <div class="col-lg-9">
        <span class="eyebrow">Explore the Hub</span>
        <h1 class="display-4 mt-2 mb-3">Everything is connected to the journey.</h1>
        <p class="lead-lg mb-0">Each tool below supports a stage of the pathway. Explore what is public, sign in for the full tools, or create an account to start with one small step.</p>
      </div>
      <div class="col-lg-3 text-lg-end">
        <a class="btn btn-gold" href="<?= e(url('pages/register.php')) ?>">Join the pilot</a>
      </div>
    </div>
  </div>
</section>

<section class="section-pad">
  <div class="container">
    <div class="row g-3">
      <?php foreach ($tools as $tool): ?>
        <div class="col-md-6 col-lg-4">
          <a class="text-decoration-none" href="<?= e(url($tool[0])) ?>">
            <div class="feature-card h-100">
              <div class="d-flex justify-content-between align-items-start">
                <div class="feature-icon"><i class="bi <?= $tool[1] ?>"></i></div>
                <span class="badge badge-tag"><?= e($tool[4]) ?></span>
              </div>
              <h2 class="h5 text-dark-brown"><?= e($tool[2]) ?></h2>
              <p class="text-muted small mb-2"><?= e($tool[3]) ?></p>
              <span class="small text-gold fw-semibold">Open tool <i class="bi bi-arrow-right"></i></span>
            </div>
          </a>
        </div>
      <?php endforeach; ?>
    </div>

    <div class="alert alert-warning mt-5 mb-0" role="note">
      <div class="d-flex gap-2">
        <i class="bi bi-flask fs-5"></i>
        <div>
          <strong>Demo data is clearly marked.</strong> Seeded accounts, challenges, projects, ideas and opportunities carry a “Demo data” badge and often “(Demo)” in their names. Counts are honest, live queries from this prototype's database. Nothing here is a claim about a real programme.
        </div>
      </div>
    </div>
  </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>

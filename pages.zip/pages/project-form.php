<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_login();
if (!is_member() && !is_admin()) {
    forbidden('Only member accounts can publish portfolio projects.');
}

$id = get_int('id') ?: (int) post('project_id');
$project = $id ? db_one('SELECT * FROM projects WHERE id = ?', [$id]) : null;
if ($id && !$project) {
    not_found('That project could not be found.');
}
if ($project && (int) $project['user_id'] !== user_id() && !is_admin()) {
    forbidden('You can only edit your own projects.');
}

$collaboratorLines = '';
if ($project) {
    $rows = db_all('SELECT name, role FROM project_members WHERE project_id = ? AND user_id IS NULL ORDER BY id', [$id]);
    $lines = [];
    foreach ($rows as $row) {
        $lines[] = $row['name'] . ($row['role'] ? ' | ' . $row['role'] : '');
    }
    $collaboratorLines = implode("\n", $lines);
}

$errors = [];
$values = [
    'title' => $project['title'] ?? '',
    'summary' => $project['summary'] ?? '',
    'description' => $project['description'] ?? '',
    'category' => $project['category'] ?? '',
    'skills_used' => $project['skills_used'] ?? '',
    'repo_link' => $project['repo_link'] ?? '',
    'demo_link' => $project['demo_link'] ?? '',
    'status' => $project['status'] ?? 'draft',
    'collaborators' => $collaboratorLines,
];

if (is_post()) {
    require_csrf();
    $values = [
        'title' => post('title'),
        'summary' => post('summary'),
        'description' => post('description'),
        'category' => post('category'),
        'skills_used' => post('skills_used'),
        'repo_link' => post('repo_link'),
        'demo_link' => post('demo_link'),
        'status' => post('status'),
        'collaborators' => post('collaborators'),
    ];
    if (mb_strlen($values['title']) < 5 || mb_strlen($values['title']) > 180) {
        $errors['title'] = 'Give the project a title between 5 and 180 characters.';
    }
    if (mb_strlen($values['summary']) < 20 || mb_strlen($values['summary']) > 300) {
        $errors['summary'] = 'Write a one or two sentence summary (20–300 characters).';
    }
    if (mb_strlen($values['description']) < 40) {
        $errors['description'] = 'Describe the project in at least 40 characters: what you built, tested and learned.';
    }
    if (mb_strlen($values['category']) < 2 || mb_strlen($values['category']) > 80) {
        $errors['category'] = 'Add a category.';
    }
    if (!valid_url($values['repo_link'])) {
        $errors['repo_link'] = 'The repository link must start with http:// or https://.';
    }
    if (!valid_url($values['demo_link'])) {
        $errors['demo_link'] = 'The demo link must start with http:// or https://.';
    }
    if (!in_array($values['status'], ['draft', 'published'], true)) {
        $errors['status'] = 'Choose draft or published.';
    }
    if (!$errors) {
        $imagePath = $project['image'] ?? null;
        try {
            $uploaded = save_upload('image', 'image', 'projects');
            if ($uploaded) {
                $imagePath = $uploaded;
            }
        } catch (RuntimeException $ex) {
            $errors['image'] = $ex->getMessage();
        }
    }
    if (!$errors) {
        $skills = implode(', ', tags_to_array($values['skills_used'], 8));
        if ($project) {
            db_run(
                'UPDATE projects SET title = ?, summary = ?, description = ?, category = ?, skills_used = ?, image = ?,
                        repo_link = ?, demo_link = ?, status = ? WHERE id = ?',
                [$values['title'], $values['summary'], $values['description'], $values['category'], $skills ?: null, $imagePath,
                 $values['repo_link'] ?: null, $values['demo_link'] ?: null, $values['status'], $id]
            );
            if ($project['image'] && $imagePath !== $project['image']) {
                remove_upload($project['image']);
            }
            db_run('DELETE FROM project_members WHERE project_id = ? AND user_id IS NULL', [$id]);
            log_activity('project.updated', 'project', $id, $values['title']);
            flash('success', 'Your project was updated.');
        } else {
            db_run(
                'INSERT INTO projects (user_id, title, summary, description, category, skills_used, image, repo_link, demo_link, status)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
                [user_id(), $values['title'], $values['summary'], $values['description'], $values['category'], $skills ?: null, $imagePath,
                 $values['repo_link'] ?: null, $values['demo_link'] ?: null, $values['status']]
            );
            $id = (int) db()->lastInsertId();
            log_activity('project.created', 'project', $id, $values['title']);
            flash('success', 'Your project was saved.');
        }
        // Collaborators are stored as text for people without accounts.
        $lines = preg_split('/\r\n|\r|\n/', $values['collaborators']) ?: [];
        $count = 0;
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || $count >= 8) {
                continue;
            }
            $parts = array_map('trim', explode('|', $line, 2));
            $name = mb_substr($parts[0], 0, 120);
            if ($name === '') {
                continue;
            }
            db_run('INSERT INTO project_members (project_id, user_id, name, role) VALUES (?, NULL, ?, ?)', [$id, $name, isset($parts[1]) ? mb_substr($parts[1], 0, 80) : null]);
            $count++;
        }
        if ($values['status'] === 'published') {
            advance_stage(user_id(), 'Showcase');
            refresh_badges(user_id());
        }
        redirect('pages/project-detail.php?id=' . $id);
    }
    flash('danger', 'Please fix the errors below.');
}

$page_title = $project ? 'Edit project' : 'Add a project';
$page_description = 'Add a project to your impact portfolio with honest evidence of what you built and learned.';
$active = 'explore';
$breadcrumbs = [['Showcase', 'pages/showcase.php'], [$page_title, null]];
require __DIR__ . '/../includes/header.php';
?>
<section class="section-pad-sm section-cream">
  <div class="container">
    <div class="mx-auto" style="max-width:820px">
      <span class="eyebrow">Portfolio evidence</span>
      <h1 class="display-6 mt-2"><?= e($page_title) ?></h1>
      <p class="text-muted">Keep it honest and specific. A small, tested project with clear limitations is stronger evidence than a large, unverified claim.</p>
    </div>
  </div>
</section>

<section class="section-pad-sm">
  <div class="container">
    <div class="panel panel-body mx-auto" style="max-width:820px">
      <?= error_summary($errors) ?>
      <form method="post" action="<?= e(url('pages/project-form.php' . ($id ? '?id=' . $id : ''))) ?>" enctype="multipart/form-data" class="needs-validation" novalidate data-single-submit>
        <?= csrf_field() ?>
        <?php if ($project): ?><input type="hidden" name="project_id" value="<?= $id ?>"><?php endif; ?>
        <div class="mb-3">
          <label class="form-label" for="title">Project title <span class="text-danger">*</span></label>
          <input class="form-control <?= isset($errors['title']) ? 'is-invalid' : '' ?>" id="title" name="title" maxlength="180" required value="<?= e($values['title']) ?>">
          <?= field_error($errors, 'title') ?>
        </div>
        <div class="mb-3">
          <label class="form-label" for="summary">One-sentence summary <span class="text-danger">*</span></label>
          <textarea class="form-control <?= isset($errors['summary']) ? 'is-invalid' : '' ?>" id="summary" name="summary" rows="2" maxlength="300" required data-counter="#summaryCounter"><?= e($values['summary']) ?></textarea>
          <div class="form-text" id="summaryCounter"></div>
          <?= field_error($errors, 'summary') ?>
        </div>
        <div class="mb-3">
          <label class="form-label" for="description">Description <span class="text-danger">*</span></label>
          <textarea class="form-control <?= isset($errors['description']) ? 'is-invalid' : '' ?>" id="description" name="description" rows="6" required minlength="40" maxlength="6000"><?= e($values['description']) ?></textarea>
          <div class="form-text">What did you build? Who did you test it with? What did you learn, and what still needs work?</div>
          <?= field_error($errors, 'description') ?>
        </div>
        <div class="row g-3">
          <div class="col-md-4">
            <label class="form-label" for="category">Category <span class="text-danger">*</span></label>
            <input class="form-control <?= isset($errors['category']) ? 'is-invalid' : '' ?>" id="category" name="category" maxlength="80" required value="<?= e($values['category']) ?>" list="projectCategories">
            <datalist id="projectCategories">
              <?php foreach (['Civic tech', 'Health', 'Education', 'Environment', 'Agriculture', 'Design', 'Business', 'Technology', 'Creative'] as $cat): ?><option value="<?= e($cat) ?>"></option><?php endforeach; ?>
            </datalist>
            <?= field_error($errors, 'category') ?>
          </div>
          <div class="col-md-8">
            <label class="form-label" for="skills_used">Skills used</label>
            <input class="form-control" id="skills_used" name="skills_used" maxlength="255" value="<?= e($values['skills_used']) ?>" placeholder="UI/UX Design, PHP, Data Analysis">
            <div class="form-text">Comma separated, up to eight skills.</div>
          </div>
        </div>
        <div class="row g-3 mt-1">
          <div class="col-md-6">
            <label class="form-label" for="repo_link">Repository link <span class="text-muted">(optional)</span></label>
            <input type="url" class="form-control <?= isset($errors['repo_link']) ? 'is-invalid' : '' ?>" id="repo_link" name="repo_link" maxlength="500" value="<?= e($values['repo_link']) ?>" placeholder="https://github.com/…">
            <?= field_error($errors, 'repo_link') ?>
          </div>
          <div class="col-md-6">
            <label class="form-label" for="demo_link">Live demo link <span class="text-muted">(optional)</span></label>
            <input type="url" class="form-control <?= isset($errors['demo_link']) ? 'is-invalid' : '' ?>" id="demo_link" name="demo_link" maxlength="500" value="<?= e($values['demo_link']) ?>" placeholder="https://…">
            <?= field_error($errors, 'demo_link') ?>
          </div>
        </div>
        <div class="row g-3 mt-1">
          <div class="col-md-6">
            <label class="form-label" for="image">Cover image <span class="text-muted">(optional)</span></label>
            <input type="file" class="form-control <?= isset($errors['image']) ? 'is-invalid' : '' ?>" id="image" name="image" accept=".jpg,.jpeg,.png,.webp" data-preview="#imagePreview">
            <?= field_error($errors, 'image') ?>
            <div class="form-text">JPG, PNG or WebP, max 3 MB.</div>
            <div id="imagePreview" class="mt-2"><?php if (!empty($project['image'])): ?><img src="<?= e(url($project['image'])) ?>" alt="Current cover image" class="img-fluid rounded" style="max-height:120px"><?php endif; ?></div>
          </div>
          <div class="col-md-6">
            <label class="form-label" for="collaborators">Collaborators <span class="text-muted">(optional)</span></label>
            <textarea class="form-control" id="collaborators" name="collaborators" rows="3" placeholder="Name | Role"><?= e($values['collaborators']) ?></textarea>
            <div class="form-text">One person per line, for example: Ada Obi | Research. Only add people who agreed to be named.</div>
          </div>
        </div>
        <fieldset class="mt-4">
          <legend class="form-label">Visibility</legend>
          <div class="d-flex flex-wrap gap-3">
            <div class="form-check">
              <input class="form-check-input" type="radio" name="status" id="statusDraft" value="draft" <?= $values['status'] === 'draft' ? 'checked' : '' ?>>
              <label class="form-check-label" for="statusDraft">Draft — only me and admins</label>
            </div>
            <div class="form-check">
              <input class="form-check-input" type="radio" name="status" id="statusPublished" value="published" <?= $values['status'] === 'published' ? 'checked' : '' ?>>
              <label class="form-check-label" for="statusPublished">Published — on the showcase</label>
            </div>
          </div>
          <?= field_error($errors, 'status') ?>
        </fieldset>
        <div class="d-flex gap-2 mt-4">
          <button class="btn btn-gold" type="submit"><?= $project ? 'Save changes' : 'Save project' ?></button>
          <a class="btn btn-outline-brown" href="<?= e($project ? url('pages/project-detail.php?id=' . $id) : url('pages/showcase.php')) ?>">Cancel</a>
        </div>
      </form>
    </div>
  </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>

<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_login();

$uid = user_id();
$isAdmin = is_admin();
$requestId = get_int('request') ?: (int) post('request_id');

if (is_post()) {
    require_csrf();
    $action = post('action');
    $request = $requestId ? db_one(
        'SELECT mr.*, m.name AS member_name, m.username AS member_username, me.name AS mentor_name, me.username AS mentor_username
         FROM mentor_requests mr JOIN users m ON m.id = mr.member_id JOIN users me ON me.id = mr.mentor_id
         WHERE mr.id = ?',
        [$requestId]
    ) : null;
    if (!$request || (!$isAdmin && (int) $request['member_id'] !== $uid && (int) $request['mentor_id'] !== $uid)) {
        forbidden('That mentor conversation is not available to you.');
    }
    $isMentor = (int) $request['mentor_id'] === $uid;
    $isMember = (int) $request['member_id'] === $uid;

    if ($action === 'accept' || $action === 'decline') {
        if (!$isMentor) {
            forbidden('Only the requested mentor can respond.');
        }
        if ($request['status'] !== 'pending') {
            flash('info', 'This request has already been answered.');
        } else {
            $status = $action === 'accept' ? 'accepted' : 'declined';
            db_run('UPDATE mentor_requests SET status = ?, responded_at = NOW() WHERE id = ?', [$status, $requestId]);
            if ($status === 'accepted') {
                db_run("INSERT INTO messages (mentor_request_id, sender_id, body) VALUES (?, ?, ?)", [
                    $requestId, $uid, 'I have accepted your request. Tell me the one decision or piece of work you would most like to focus on first.',
                ]);
            }
            notify(
                (int) $request['member_id'],
                'mentor_response',
                $request['mentor_name'] . ' ' . ($status === 'accepted' ? 'accepted' : 'declined') . ' your mentor request.',
                'pages/messages.php?request=' . $requestId
            );
            log_activity('mentor.' . $status, 'mentor_request', $requestId);
            flash('success', $status === 'accepted' ? 'Request accepted. You can now message each other here.' : 'The request was declined.');
        }
        redirect('pages/messages.php?request=' . $requestId);

    } elseif ($action === 'send') {
        if (!$isMember && !$isMentor) {
            forbidden('Only the member and mentor in this conversation can send messages.');
        }
        if ($request['status'] !== 'accepted') {
            flash('warning', 'Messages open once the mentor accepts the request.');
            redirect('pages/messages.php?request=' . $requestId);
        }
        $body = post('body');
        if (mb_strlen($body) < 1) {
            flash('danger', 'Write a message before sending.');
        } elseif (mb_strlen($body) > 2000) {
            flash('danger', 'Please keep messages under 2,000 characters.');
        } elseif (!rate_limit_hit('mentor_message', 40, 10)) {
            flash('warning', 'You are sending messages quickly. Please wait a moment.');
        } else {
            db_run('INSERT INTO messages (mentor_request_id, sender_id, body) VALUES (?, ?, ?)', [$requestId, $uid, $body]);
            $other = $isMember ? (int) $request['mentor_id'] : (int) $request['member_id'];
            notify($other, 'mentor_message', current_user()['name'] . ' sent you a message.', 'pages/messages.php?request=' . $requestId . '#latest');
            log_activity('mentor.message', 'mentor_request', $requestId);
        }
        redirect('pages/messages.php?request=' . $requestId . '#latest');

    } elseif ($action === 'cancel') {
        if (!$isMember || $request['status'] !== 'pending') {
            flash('warning', 'Only a pending request from the member can be cancelled.');
        } else {
            db_run("UPDATE mentor_requests SET status = 'declined', responded_at = NOW() WHERE id = ?", [$requestId]);
            notify((int) $request['mentor_id'], 'mentor_request', $request['member_name'] . ' cancelled a mentor request.', 'pages/mentor-dashboard.php');
            log_activity('mentor.cancelled', 'mentor_request', $requestId);
            flash('success', 'The pending request was cancelled.');
        }
        redirect('pages/messages.php?request=' . $requestId);
    }
    redirect('pages/messages.php');
}

if ($isAdmin) {
    $threads = db_all(
        'SELECT mr.*, m.name AS member_name, m.username AS member_username, me.name AS mentor_name, me.username AS mentor_username,
                (SELECT MAX(msg.created_at) FROM messages msg WHERE msg.mentor_request_id = mr.id) AS last_at,
                (SELECT COUNT(*) FROM messages msg WHERE msg.mentor_request_id = mr.id) AS message_count
         FROM mentor_requests mr JOIN users m ON m.id = mr.member_id JOIN users me ON me.id = mr.mentor_id
         ORDER BY COALESCE(last_at, mr.created_at) DESC'
    );
} else {
    $threads = db_all(
        'SELECT mr.*, m.name AS member_name, m.username AS member_username, me.name AS mentor_name, me.username AS mentor_username,
                (SELECT MAX(msg.created_at) FROM messages msg WHERE msg.mentor_request_id = mr.id) AS last_at,
                (SELECT COUNT(*) FROM messages msg WHERE msg.mentor_request_id = mr.id) AS message_count
         FROM mentor_requests mr JOIN users m ON m.id = mr.member_id JOIN users me ON me.id = mr.mentor_id
         WHERE mr.member_id = ? OR mr.mentor_id = ?
         ORDER BY COALESCE(last_at, mr.created_at) DESC',
        [$uid, $uid]
    );
}

$request = null;
$threadMessages = [];
if ($requestId) {
    $request = db_one(
        'SELECT mr.*, m.name AS member_name, m.username AS member_username, m.photo AS member_photo, m.is_demo AS member_demo,
                me.name AS mentor_name, me.username AS mentor_username, me.photo AS mentor_photo, me.is_demo AS mentor_demo
         FROM mentor_requests mr JOIN users m ON m.id = mr.member_id JOIN users me ON me.id = mr.mentor_id
         WHERE mr.id = ?',
        [$requestId]
    );
    if (!$request) {
        not_found('That mentor conversation could not be found.');
    }
    $allowed = $isAdmin || (int) $request['member_id'] === $uid || (int) $request['mentor_id'] === $uid;
    if (!$allowed) {
        forbidden('That mentor conversation is not available to you.');
    }
    $threadMessages = db_all(
        'SELECT msg.*, u.name, u.username, u.is_demo, p.photo FROM messages msg
         JOIN users u ON u.id = msg.sender_id LEFT JOIN profiles p ON p.user_id = u.id
         WHERE msg.mentor_request_id = ? ORDER BY msg.created_at ASC',
        [$requestId]
    );
}

$page_title = 'Mentor Messages';
$page_description = 'Your focused mentor conversations and requests.';
$breadcrumbs = [['Mentors', 'pages/mentors.php'], ['Messages', null]];
require __DIR__ . '/../includes/header.php';
?>
<section class="section-pad-sm section-cream">
  <div class="container">
    <div class="row align-items-end g-3">
      <div class="col-lg-8">
        <span class="eyebrow">Focused support</span>
        <h1 class="display-6 mt-2 mb-1">Mentor conversations</h1>
        <p class="text-muted mb-0"><?= $isAdmin ? 'Admin view: all mentor requests in the pilot.' : 'One request, one conversation. Keep messages specific and respectful.' ?></p>
      </div>
      <div class="col-lg-4 text-lg-end">
        <?php if (is_member()): ?><a class="btn btn-gold" href="<?= e(url('pages/mentors.php')) ?>"><i class="bi bi-person-plus me-1"></i>Find a mentor</a><?php endif; ?>
        <?php if (is_mentor()): ?><a class="btn btn-outline-brown" href="<?= e(url('pages/mentor-form.php')) ?>">Mentor profile</a><?php endif; ?>
      </div>
    </div>
  </div>
</section>

<section class="section-pad-sm">
  <div class="container">
    <div class="row g-4">
      <div class="col-lg-5 col-xl-4">
        <div class="panel">
          <div class="panel-head"><h2><?= $isAdmin ? 'All requests' : 'Your requests' ?></h2><span class="badge badge-soft"><?= count($threads) ?></span></div>
          <div class="list-group list-group-flush" style="max-height:640px;overflow-y:auto">
            <?php if (!$threads): ?>
              <div class="panel-body small text-muted">No mentor conversations yet. <?php if (is_member()): ?><a href="<?= e(url('pages/mentors.php')) ?>">Find a mentor</a><?php endif; ?></div>
            <?php endif; ?>
            <?php foreach ($threads as $t): $otherName = (int) $t['mentor_id'] === $uid ? $t['member_name'] : $t['mentor_name']; ?>
              <a class="list-group-item list-group-item-action py-3 border-0 border-bottom <?= $requestId === (int) $t['id'] ? 'active' : '' ?>" href="<?= e(url('pages/messages.php?request=' . (int) $t['id'])) ?>">
                <div class="d-flex justify-content-between gap-2">
                  <div class="min-w-0">
                    <div class="fw-semibold small text-truncate"><?= e($otherName) ?></div>
                    <div class="small text-muted text-truncate"><?= e(excerpt($t['message'], 70)) ?></div>
                    <div class="small text-muted mt-1"><?= e($t['last_at'] ? time_ago($t['last_at']) : format_date($t['created_at'])) ?> · <?= (int) $t['message_count'] ?> message<?= (int) $t['message_count'] === 1 ? '' : 's' ?></div>
                  </div>
                  <div class="text-end flex-shrink-0"><?= status_badge($t['status']) ?></div>
                </div>
              </a>
            <?php endforeach; ?>
          </div>
        </div>
      </div>

      <div class="col-lg-7 col-xl-8">
        <?php if (!$request): ?>
          <div class="panel empty-state w-100">
            <i class="bi bi-chat-square-text display-4"></i>
            <h2>Select a conversation</h2>
            <p>Requests show the member, the mentor and the status. A mentor can accept or decline a pending request; messages open after acceptance.</p>
          </div>
        <?php else: $isMentor = (int) $request['mentor_id'] === $uid; $isMember = (int) $request['member_id'] === $uid; ?>
          <div class="panel">
            <div class="panel-head">
              <div>
                <h2><?= e($isMentor ? $request['member_name'] : $request['mentor_name']) ?></h2>
                <div class="small text-muted">Request #<?= (int) $request['id'] ?> · <?= e(format_date($request['created_at'])) ?> · <?= status_badge($request['status']) ?></div>
              </div>
              <a class="small" href="<?= e(url('pages/profile.php?u=' . urlencode($isMentor ? $request['member_username'] : $request['mentor_username']))) ?>">View profile</a>
            </div>
            <div class="panel-body">
              <div class="small-caps mb-1"><?= $isMentor ? 'Member request' : 'Your request' ?></div>
              <p class="small text-muted" style="white-space:pre-line"><?= e($request['message']) ?></p>
              <?php if ($isAdmin && !$isMentor && !$isMember): ?><div class="alert alert-info small mb-0">Admin view is read-only. Only the member and mentor can send messages.</div><?php endif; ?>
            </div>

            <?php if ($isMentor && $request['status'] === 'pending'): ?>
              <div class="panel-body border-top d-flex flex-wrap gap-2">
                <form method="post" action="<?= e(url('pages/messages.php?request=' . $requestId)) ?>">
                  <?= csrf_field() ?>
                  <input type="hidden" name="request_id" value="<?= $requestId ?>">
                  <input type="hidden" name="action" value="accept">
                  <button class="btn btn-gold" type="submit"><i class="bi bi-check2 me-1"></i>Accept request</button>
                </form>
                <form method="post" action="<?= e(url('pages/messages.php?request=' . $requestId)) ?>" data-confirm="Decline this request? The member will be notified.">
                  <?= csrf_field() ?>
                  <input type="hidden" name="request_id" value="<?= $requestId ?>">
                  <input type="hidden" name="action" value="decline">
                  <button class="btn btn-outline-brown" type="submit">Decline</button>
                </form>
              </div>
            <?php elseif ($isMember && $request['status'] === 'pending'): ?>
              <div class="panel-body border-top">
                <form method="post" action="<?= e(url('pages/messages.php?request=' . $requestId)) ?>" data-confirm="Cancel this pending request?">
                  <?= csrf_field() ?>
                  <input type="hidden" name="request_id" value="<?= $requestId ?>">
                  <input type="hidden" name="action" value="cancel">
                  <button class="btn btn-sm btn-outline-brown" type="submit">Cancel pending request</button>
                </form>
              </div>
            <?php endif; ?>

            <?php if ($request['status'] === 'accepted'): ?>
              <div class="chat-window" style="max-height:420px" aria-live="polite">
                <?php if (!$threadMessages): ?><p class="small text-muted">No messages yet. Say hello and name the one thing you want to focus on.</p><?php endif; ?>
                <?php foreach ($threadMessages as $msg): $own = (int) $msg['sender_id'] === $uid; ?>
                  <div class="chat-message <?= $own ? 'is-own' : '' ?>">
                    <?= avatar_html($msg, $msg, 'sm') ?>
                    <div class="chat-bubble">
                      <div class="chat-meta"><strong><?= e($msg['name']) ?></strong><?= demo_badge($msg['is_demo']) ?><span><?= e(time_ago($msg['created_at'])) ?></span></div>
                      <div class="chat-body"><p><?= nl2br(e($msg['body']), false) ?></p></div>
                    </div>
                  </div>
                <?php endforeach; ?>
                <div id="latest"></div>
              </div>
              <?php if ($isMember || $isMentor): ?>
                <div class="chat-form">
                  <form method="post" action="<?= e(url('pages/messages.php?request=' . $requestId . '#latest')) ?>">
                    <?= csrf_field() ?>
                    <input type="hidden" name="request_id" value="<?= $requestId ?>">
                    <input type="hidden" name="action" value="send">
                    <label class="form-label" for="body">Reply</label>
                    <textarea class="form-control" id="body" name="body" rows="2" maxlength="2000" required placeholder="Keep the conversation focused and useful."></textarea>
                    <div class="d-flex justify-content-between align-items-center mt-2">
                      <span class="form-text">Messages are private to the member and mentor (and admins for oversight).</span>
                      <button class="btn btn-gold" type="submit"><i class="bi bi-send me-1"></i>Send</button>
                    </div>
                  </form>
                </div>
              <?php endif; ?>
            <?php elseif ($request['status'] === 'pending'): ?>
              <div class="panel-body border-top"><div class="alert alert-warning mb-0 small"><i class="bi bi-hourglass-split me-1"></i>Waiting for the mentor to respond. Messages open after acceptance.</div></div>
            <?php else: ?>
              <div class="panel-body border-top"><div class="alert alert-secondary mb-0 small">This request was declined or cancelled. The conversation is closed.</div></div>
            <?php endif; ?>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>

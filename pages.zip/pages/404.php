<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
$page_title = 'Page Not Found';
require __DIR__ . '/../includes/header.php';
?>
<main id="main-content">
<section class="section-pad-lg text-center">
  <div class="container">
    <div class="row">
      <div class="col-12">
        <h1 class="display-6 fw-bold mb-3">404</h1>
        <h2 class="mb-4">Page not found</h2>
        <p class="lead text-muted">The page you're looking for doesn't exist.</p>
        <a class="btn btn-gold mt-3" href="<?= e(url('index.php')) ?>">Go to home</a>
      </div>
    </div>
  </div>
</section>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
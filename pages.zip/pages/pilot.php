<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';

$page_title = 'Join the Pilot';
$page_description = 'Express interest in the Mindset Innovators Hub pilot as a young person, mentor, educator or partner organisation.';
$active = 'pilot';
$breadcrumbs = [['Join the pilot', null]];

$errors = [];
$form = ['name' => '', 'email' => '', 'phone' => '', 'role' => '', 'institution' => '', 'message' => ''];
$roles = ['Student', 'Recent graduate', 'Aspiring entrepreneur', 'Young professional', 'Educator', 'Mentor', 'Partner organisation', 'Other'];

if (is_post()) {
    require_csrf();
    foreach ($form as $key => $_) {
        $form[$key] = post($key);
    }
    if (post('website_url') !== '') {
        flash('success', 'Thank you. Your expression of interest has been saved.');
        redirect('pages/pilot.php');
    }
    if (!rate_limit_hit('pilot_interest', 3, 60)) {
        $errors['form'] = 'Too many submissions from this connection. Please try again later.';
    }
    if (mb_strlen($form['name']) < 2 || mb_strlen($form['name']) > 120) {
        $errors['name'] = 'Please enter your full name.';
    }
    if (!valid_email($form['email'])) {
        $errors['email'] = 'Please enter a valid email address.';
    }
    if (!in_array($form['role'], $roles, true)) {
        $errors['role'] = 'Please choose the option that fits you best.';
    }
    if ($form['phone'] !== '' && !preg_match('/^[0-9 +()\-]{7,30}$/', $form['phone'])) {
        $errors['phone'] = 'Please enter a valid phone number, or leave it blank.';
    }
    if (mb_strlen($form['institution']) > 160) {
        $errors['institution'] = 'Please use 160 characters or fewer.';
    }
    if (mb_strlen($form['message']) > 3000) {
        $errors['message'] = 'Please use 3,000 characters or fewer.';
    }
    if (!$errors) {
        db_run(
            'INSERT INTO pilot_interests (name, email, phone, role, institution, message, ip) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [$form['name'], $form['email'], $form['phone'] ?: null, $form['role'], $form['institution'] ?: null, $form['message'] ?: null, client_ip()]
        );
        log_activity('pilot.interest', 'pilot_interest', (int) db()->lastInsertId(), $form['name']);
        notify_admins('pilot_interest', 'New pilot expression of interest from ' . $form['name'] . '.', 'admin/enquiries.php');
        flash('success', 'Thank you, ' . $form['name'] . '. Your expression of interest is saved. This prototype does not send automatic email, so the team will review it from the admin area.');
        redirect('pages/pilot.php');
    }
}

$interestCount = db_count('SELECT COUNT(*) FROM pilot_interests');
require __DIR__ . '/../includes/header.php';
?>
<section class="section-pad-sm section-cream">
  <div class="container">
    <div class="row g-5">
      <div class="col-lg-5">
        <span class="eyebrow">Join the pilot</span>
        <h1 class="display-4 mt-2 mb-3">Start with one honest step.</h1>
        <p class="lead-lg">Tell us who you are and what you would like to explore. We are looking for young people, mentors, educators and organisations willing to test a small, practical innovation journey with us.</p>
        <div class="panel p-3 mb-3">
          <div class="d-flex justify-content-between align-items-center">
            <span class="small-caps">Expressions of interest</span>
            <span class="h4 mb-0"><?= number_format($interestCount) ?></span>
          </div>
          <p class="small text-muted mb-0 mt-1">Live count from this prototype database, including a seeded demo entry.</p>
        </div>
        <div class="alert alert-warning small mb-0">
          <i class="bi bi-cone-striped me-1"></i><strong>Prototype notice:</strong> this form saves to the local database. No automated email is sent, and nothing is shared with a third party. In a live programme, joining would be confirmed personally.
        </div>
      </div>
      <div class="col-lg-7">
        <div class="panel panel-body">
          <?= error_summary($errors) ?>
          <?php if (!empty($errors['form'])): ?><div class="alert alert-danger"><?= e($errors['form']) ?></div><?php endif; ?>
          <form method="post" action="<?= e(url('pages/pilot.php')) ?>" class="needs-validation" novalidate data-single-submit>
            <?= csrf_field() ?>
            <div class="d-none" aria-hidden="true">
              <label for="website_url">Leave this field blank</label>
              <input type="text" id="website_url" name="website_url" tabindex="-1" autocomplete="off">
            </div>
            <div class="row g-3">
              <div class="col-md-6">
                <label class="form-label" for="name">Full name <span class="text-danger">*</span></label>
                <input class="form-control <?= isset($errors['name']) ? 'is-invalid' : '' ?>" id="name" name="name" required maxlength="120" autocomplete="name" value="<?= e($form['name']) ?>">
                <?= field_error($errors, 'name') ?>
              </div>
              <div class="col-md-6">
                <label class="form-label" for="email">Email <span class="text-danger">*</span></label>
                <input type="email" class="form-control <?= isset($errors['email']) ? 'is-invalid' : '' ?>" id="email" name="email" required maxlength="190" autocomplete="email" value="<?= e($form['email']) ?>">
                <?= field_error($errors, 'email') ?>
              </div>
              <div class="col-md-6">
                <label class="form-label" for="phone">Phone <span class="text-muted">(optional)</span></label>
                <input type="tel" class="form-control <?= isset($errors['phone']) ? 'is-invalid' : '' ?>" id="phone" name="phone" maxlength="30" autocomplete="tel" value="<?= e($form['phone']) ?>">
                <?= field_error($errors, 'phone') ?>
              </div>
              <div class="col-md-6">
                <label class="form-label" for="role">I am a… <span class="text-danger">*</span></label>
                <select class="form-select <?= isset($errors['role']) ? 'is-invalid' : '' ?>" id="role" name="role" required>
                  <option value="">Choose one…</option>
                  <?php foreach ($roles as $r): ?><option value="<?= e($r) ?>" <?= $form['role'] === $r ? 'selected' : '' ?>><?= e($r) ?></option><?php endforeach; ?>
                </select>
                <?= field_error($errors, 'role') ?>
              </div>
              <div class="col-12">
                <label class="form-label" for="institution">School, organisation or location <span class="text-muted">(optional)</span></label>
                <input class="form-control <?= isset($errors['institution']) ? 'is-invalid' : '' ?>" id="institution" name="institution" maxlength="160" value="<?= e($form['institution']) ?>">
                <?= field_error($errors, 'institution') ?>
              </div>
              <div class="col-12">
                <label class="form-label" for="message">What would you like to learn or contribute? <span class="text-muted">(optional)</span></label>
                <textarea class="form-control <?= isset($errors['message']) ? 'is-invalid' : '' ?>" id="message" name="message" maxlength="3000" data-counter="#msgCount"><?= e($form['message']) ?></textarea>
                <div class="form-text text-end" id="msgCount"></div>
                <?= field_error($errors, 'message') ?>
              </div>
            </div>
            <button class="btn btn-gold mt-4" type="submit">Express interest</button>
            <p class="small text-muted mt-3 mb-0">By submitting, you agree that the team may contact you about the pilot. You can ask for your entry to be removed at any time.</p>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>

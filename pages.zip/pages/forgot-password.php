<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';

$page_title = 'Forgot password';
$page_description = 'Request a password reset link for your Mindset Innovators Hub account.';
$errors = [];

if (is_post()) {
    require_csrf();
    $email = strtolower(post('email'));
    if (!valid_email($email)) {
        $errors['email'] = 'Please enter a valid email address.';
    } elseif (!rate_limit_hit('password_forgot', 5, 60)) {
        $errors['form'] = 'Too many reset requests from this connection. Please try again later.';
    } else {
        $user = db_one('SELECT id, name, email FROM users WHERE email = ?', [$email]);
        if ($user) {
            db_run('DELETE FROM password_resets WHERE user_id = ? AND used_at IS NULL', [(int) $user['id']]);
            $token = bin2hex(random_bytes(32));
            db_run(
                'INSERT INTO password_resets (user_id, token_hash, expires_at) VALUES (?, ?, ?)',
                [(int) $user['id'], hash('sha256', $token), date('Y-m-d H:i:s', time() + TOKEN_TTL)]
            );
            $link = url('pages/reset-password.php?token=' . urlencode($token));
            simulated_mail(
                $user['email'],
                'Reset your Mindset Innovators Hub password (prototype)',
                "Hello " . $user['name'] . ",\n\nUse this one-time link within one hour to reset your password:\n" . $link . "\n\nIf you did not request this, you can ignore this message.",
                $link
            );
            log_activity('auth.password_reset_requested', 'user', (int) $user['id'], null, (int) $user['id']);
        }
        // Always the same response, whether or not the email exists.
        flash('success', 'If an account uses that email, a one-time reset link has been generated. In this prototype it is written to storage/mail.log' . (APP_DEBUG ? ' and shown in the debug panel.' : '.'));
        redirect('pages/forgot-password.php');
    }
}

$breadcrumbs = [['Sign in', 'pages/login.php'], ['Forgot password', null]];
require __DIR__ . '/../includes/header.php';
?>
<section class="section-pad">
  <div class="container">
    <div class="auth-wrap">
      <div class="auth-card">
        <h1 class="h3 mb-2">Reset your password</h1>
        <p class="text-muted small mb-4">Enter the email on your account. We will generate a one-time link that expires in one hour.</p>
        <?= error_summary($errors) ?>
        <?php if (!empty($errors['form'])): ?><div class="alert alert-danger"><?= e($errors['form']) ?></div><?php endif; ?>
        <form method="post" action="<?= e(url('pages/forgot-password.php')) ?>" class="needs-validation" novalidate data-single-submit>
          <?= csrf_field() ?>
          <div class="mb-3">
            <label class="form-label" for="email">Email address</label>
            <input type="email" class="form-control" id="email" name="email" required maxlength="190" autocomplete="email" value="<?= e(post('email')) ?>">
          </div>
          <button class="btn btn-gold w-100" type="submit">Send reset link</button>
        </form>
        <div class="alert alert-info small mt-4 mb-0">
          <i class="bi bi-info-circle me-1"></i>This prototype has no mail server. The reset link is appended to <code>storage/mail.log</code>. When <code>APP_DEBUG</code> is true, a debug panel also shows the link so you can test the flow.
        </div>
        <p class="text-center small text-muted mt-3 mb-0"><a href="<?= e(url('pages/login.php')) ?>">Back to sign in</a></p>
      </div>
    </div>
  </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>

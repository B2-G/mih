<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_role(['partner', 'admin']);
if (is_admin()) {
    redirect('admin/index.php');
}

$uid = user_id();
$user = current_user();
$oppTotal = db_count('SELECT COUNT(*) FROM opportunities WHERE posted_by = ?', [$uid]);
$oppApproved = db_count("SELECT COUNT(*) FROM opportunities WHERE posted_by = ? AND status = 'approved'", [$uid]);
$oppPending = db_count("SELECT COUNT(*) FROM opportunities WHERE posted_by = ? AND status = 'pending'", [$uid]);
$ideasInterested = db_count('SELECT COUNT(*) FROM idea_matches WHERE partner_id = ?', [$uid]);
$matchesAccepted = db_count("SELECT COUNT(*) FROM idea_matches WHERE partner_id = ? AND status = 'accepted'", [$uid]);
$challengesPosted = db_count('SELECT COUNT(*) FROM challenges WHERE created_by = ?', [$uid]);
$unread = unread_notifications_count($uid);

$opportunities = db_all(
    'SELECT * FROM opportunities WHERE posted_by = ? ORDER BY created_at DESC LIMIT 6',
    [$uid]
);
$ideaMatches = db_all(
    'SELECT m.*, i.title AS idea_title, i.id AS idea_id, i.status AS idea_status, u.name AS owner_name, u.username AS owner_username
     FROM idea_matches m JOIN ideas i ON i.id = m.idea_id JOIN users u ON u.id = i.user_id
     WHERE m.partner_id = ? ORDER BY m.created_at DESC LIMIT 6',
    [$uid]
);
$myChallenges = db_all(
    'SELECT c.*, (SELECT COUNT(*) FROM challenge_participants cp WHERE cp.challenge_id = c.id) AS participants,
            (SELECT COUNT(*) FROM submissions s WHERE s.challenge_id = c.id) AS submissions
     FROM challenges c WHERE c.created_by = ? ORDER BY c.created_at DESC LIMIT 5',
    [$uid]
);

$page_title = 'Partner dashboard';
$page_description = 'Your opportunity listings, challenge briefs and idea conversations.';
require __DIR__ . '/../includes/header.php';
?>
<section class="section-pad-sm section-cream">
  <div class="container">
    <div class="row align-items-end g-3">
      <div class="col-lg-8">
        <span class="eyebrow">Partner workspace</span>
        <h1 class="display-5 mt-2 mb-1">Hello, <?= e(explode(' ', $user['name'])[0]) ?>.</h1>
        <p class="text-muted mb-0">A partner can add reviewed opportunities, sponsor challenges and express interest in member ideas. Everything is moderated.</p>
      </div>
      <div class="col-lg-4 text-lg-end d-flex flex-wrap gap-2 justify-content-lg-end">
        <a class="btn btn-gold" href="<?= e(url('pages/opportunity-form.php')) ?>"><i class="bi bi-plus-lg me-1"></i>Post opportunity</a>
        <a class="btn btn-outline-brown" href="<?= e(url('pages/challenge-form.php')) ?>">Create challenge</a>
      </div>
    </div>
  </div>
</section>

<section class="section-pad-sm">
  <div class="container">
    <div class="row g-3 mb-4">
      <div class="col-6 col-lg-3"><div class="dash-stat"><div class="d-flex justify-content-between"><div><div class="number"><?= $oppApproved ?></div><div class="label">Live opportunities</div></div><span class="icon"><i class="bi bi-compass"></i></span></div></div></div>
      <div class="col-6 col-lg-3"><div class="dash-stat"><div class="d-flex justify-content-between"><div><div class="number"><?= $oppPending ?></div><div class="label">Awaiting review</div></div><span class="icon"><i class="bi bi-hourglass-split"></i></span></div></div></div>
      <div class="col-6 col-lg-3"><div class="dash-stat"><div class="d-flex justify-content-between"><div><div class="number"><?= $ideasInterested ?></div><div class="label">Ideas supported</div></div><span class="icon"><i class="bi bi-lightbulb"></i></span></div></div></div>
      <div class="col-6 col-lg-3"><div class="dash-stat"><div class="d-flex justify-content-between"><div><div class="number"><?= $challengesPosted ?></div><div class="label">Challenges created</div></div><span class="icon"><i class="bi bi-lightning-charge"></i></span></div></div></div>
    </div>

    <div class="row g-4">
      <div class="col-lg-7">
        <div class="panel mb-4">
          <div class="panel-head"><h2><i class="bi bi-compass me-2 text-gold"></i>My opportunity listings</h2><a class="small" href="<?= e(url('pages/opportunity-form.php')) ?>">Post new</a></div>
          <div class="panel-body">
            <?php if (!$opportunities): ?><p class="small text-muted mb-0">No listings yet. Add one for admin review. Listings are not published automatically.</p><?php endif; ?>
            <?php foreach ($opportunities as $o): $expired = $o['deadline'] && strtotime($o['deadline']) < strtotime('today'); ?>
              <div class="border-bottom py-3">
                <div class="d-flex justify-content-between align-items-start gap-2">
                  <div><a class="fw-semibold text-decoration-none" href="<?= e(url('pages/opportunity-detail.php?id=' . (int) $o['id'])) ?>"><?= e($o['title']) ?></a><div class="small text-muted"><?= e(ucfirst($o['type'])) ?> · <?= e($o['organization']) ?><?= $o['deadline'] ? ' · ' . e(format_date($o['deadline'])) : '' ?><?= $expired ? ' · deadline passed' : '' ?></div></div>
                  <?= status_badge($o['status']) ?>
                </div>
                <a class="btn btn-sm btn-outline-brown mt-2" href="<?= e(url('pages/opportunity-form.php?id=' . (int) $o['id'])) ?>">Edit listing</a>
              </div>
            <?php endforeach; ?>
          </div>
        </div>

        <div class="panel">
          <div class="panel-head"><h2><i class="bi bi-lightbulb me-2 text-gold"></i>Ideas I support</h2><a class="small" href="<?= e(url('pages/ideas.php?matching=ready')) ?>">Explore ideas</a></div>
          <div class="panel-body">
            <?php if (!$ideaMatches): ?><p class="small text-muted mb-0">You have not expressed interest in an idea yet. Open a matching-ready idea and offer specific support.</p><?php endif; ?>
            <?php foreach ($ideaMatches as $m): ?>
              <div class="border-bottom py-3">
                <div class="d-flex justify-content-between align-items-start gap-2">
                  <div><a class="fw-semibold text-decoration-none" href="<?= e(url('pages/idea-detail.php?id=' . (int) $m['idea_id'] . '#matching')) ?>"><?= e($m['idea_title']) ?></a><div class="small text-muted">Owner: <?= e($m['owner_name']) ?> · <?= e(time_ago($m['created_at'])) ?></div></div>
                  <?= status_badge($m['status']) ?>
                </div>
                <?php if ($m['note']): ?><p class="small text-muted mb-0 mt-1"><?= e(excerpt($m['note'], 160)) ?></p><?php endif; ?>
              </div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>

      <aside class="col-lg-5">
        <div class="panel panel-body mb-4">
          <div class="small-caps mb-2">Partner snapshot</div>
          <ul class="list-clean small">
            <li class="d-flex justify-content-between"><span>Accepted idea matches</span><strong><?= $matchesAccepted ?></strong></li>
            <li class="d-flex justify-content-between"><span>Total listings</span><strong><?= $oppTotal ?></strong></li>
            <li class="d-flex justify-content-between"><span>Unread notifications</span><strong><?= $unread ?></strong></li>
            <li class="d-flex justify-content-between"><span>Role</span><strong>Partner</strong></li>
          </ul>
          <a class="btn btn-sm btn-outline-brown w-100 mt-2" href="<?= e(url('pages/notifications.php')) ?>">Open notifications</a>
        </div>

        <div class="panel panel-body mb-4">
          <div class="d-flex justify-content-between align-items-center mb-2">
            <h2 class="h5 mb-0">Challenges I created</h2>
            <a class="small" href="<?= e(url('pages/challenge-form.php')) ?>">Create</a>
          </div>
          <?php if (!$myChallenges): ?><p class="small text-muted mb-0">No challenges yet. A short, well-scoped brief is easier to support.</p><?php endif; ?>
          <?php foreach ($myChallenges as $c): ?>
            <a class="d-block border-bottom py-2 text-decoration-none" href="<?= e(url('pages/challenge-detail.php?id=' . (int) $c['id'])) ?>">
              <span class="small fw-semibold text-dark-brown"><?= e($c['title']) ?></span>
              <span class="d-block small text-muted"><?= (int) $c['participants'] ?> participants · <?= (int) $c['submissions'] ?> submissions · <?= e(status_badge($c['status'])) ?></span>
            </a>
          <?php endforeach; ?>
        </div>

        <div class="panel panel-body">
          <div class="small-caps mb-2">Partner guardrails</div>
          <ul class="small text-muted ps-3 mb-0">
            <li class="mb-2">Only add opportunities with an official link.</li>
            <li class="mb-2">Never ask members for payment, bank details or private documents.</li>
            <li class="mb-2">Idea interest is a first conversation, not a funding promise.</li>
            <li>Admin review exists to protect members. Expect edits to be re-reviewed.</li>
          </ul>
        </div>
      </aside>
    </div>
  </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>

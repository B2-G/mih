<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';

$page_title = 'How It Works';
$page_description = 'The six-stage Mindset Innovators Hub journey: Discover, Learn, Practise, Build, Showcase and Advance.';
$active = 'how';
$breadcrumbs = [['How it works', null]];
require __DIR__ . '/../includes/header.php';
?>
<section class="section-pad-sm section-cream">
  <div class="container">
    <div class="row align-items-end g-4">
      <div class="col-lg-8">
        <span class="eyebrow">The pathway</span>
        <h1 class="display-4 mt-2 mb-3">From curiosity to a real next step.</h1>
        <p class="lead-lg mb-0">The hub is organised around six stages. You do not have to follow them perfectly, but they give you a clear way to notice progress and choose what to do next.</p>
      </div>
      <div class="col-lg-4">
        <div class="panel p-3">
          <div class="small-caps mb-2">Your current stage</div>
          <?php if (is_logged_in()): ?>
            <?= journey_tracker(current_user()['journey_stage']) ?>
            <a class="small" href="<?= e(url('pages/profile-edit.php')) ?>">Change your stage</a>
          <?php else: ?>
            <p class="small text-muted mb-2">Sign in to see your own journey tracker.</p>
            <a class="btn btn-sm btn-gold" href="<?= e(url('pages/login.php')) ?>">Sign in</a>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="section-pad">
  <div class="container">
    <div class="row g-4">
      <?php
      $details = [
          ['Discover', 'bi-compass', 'Find your starting point', 'Explore your interests, strengths and the problems you care about. The onboarding quiz helps you choose interests and a starting stage. The Idea Board lets you put a rough thought somewhere useful instead of keeping it in your head.', ['Take the onboarding quiz', 'Browse the Idea Board', 'Write a one-line problem statement']],
          ['Learn', 'bi-book', 'Build practical knowledge', 'Use challenge resources, mentor advice and the learning circle to fill a specific gap. Learning here should be tied to something you are about to try, not collected for its own sake.', ['Join a challenge with a clear brief', 'Ask a focused question in a room', 'List the skills you are practising']],
          ['Practise', 'bi-tools', 'Apply it with guidance', 'Join a challenge and submit a first attempt. Mentors and admins review submissions with written feedback and a score. The goal is a better second attempt, not a perfect first one.', ['Join a collaboration team', 'Submit your first piece of work', 'Respond to reviewer feedback']],
          ['Build', 'bi-bricks', 'Create something real', 'Work with a team on a project or challenge idea. Use a collaboration room to make decisions, share work and keep a record of who did what.', ['Create or join a team', 'Keep a project in your portfolio', 'Document your evidence']],
          ['Showcase', 'bi-collection', 'Present your evidence', 'Publish a project to your Impact Portfolio with a summary, links, images and team credits. Share a clean portfolio URL with a mentor, employer, school or partner. You can print it as a PDF-friendly page.', ['Publish a project', 'Add a repository or demo link', 'Share your portfolio URL']],
          ['Advance', 'bi-rocket-takeoff', 'Connect with opportunity', 'Ask for a mentor, browse opportunities from partners and mark what you are interested in or have applied for. Accepted mentor pairs get a simple private thread, and ready ideas can be matched with mentors or partners.', ['Request a mentor', 'Save an opportunity', 'Mark an idea ready for matching']],
      ];
      $i = 1;
      foreach ($details as $d):
      ?>
        <div class="col-md-6">
          <article class="feature-card h-100">
            <div class="d-flex align-items-start justify-content-between">
              <div class="feature-icon"><i class="bi <?= $d[1] ?>"></i></div>
              <span class="stage-num"><?= str_pad((string) $i, 2, '0', STR_PAD_LEFT) ?></span>
            </div>
            <div class="small-caps mb-1">Stage <?= $i ?> · <?= e($d[0]) ?></div>
            <h2 class="h4"><?= e($d[2]) ?></h2>
            <p class="text-muted small"><?= e($d[3]) ?></p>
            <ul class="small text-muted ps-3 mb-0">
              <?php foreach ($d[4] as $action): ?><li class="mb-1"><?= e($action) ?></li><?php endforeach; ?>
            </ul>
          </article>
        </div>
      <?php $i++; endforeach; ?>
    </div>
  </div>
</section>

<section class="section-pad section-dark">
  <div class="container">
    <div class="row g-5 align-items-center">
      <div class="col-lg-6">
        <span class="eyebrow">What progress looks like</span>
        <h2 class="display-5 mt-2 mb-3">Small evidence beats a big promise.</h2>
        <p class="lead">The prototype measures progress through real activity: a submitted challenge, a published project, a completed review, a team formed, a mentor conversation, an opportunity saved. These counts come straight from the database.</p>
        <a class="btn btn-gold mt-2" href="<?= e(url('pages/register.php')) ?>">Start your journey</a>
      </div>
      <div class="col-lg-6">
        <div class="row g-3">
          <?php
          $examples = [
              ['First Submission', 'You put a real attempt in front of a reviewer.'],
              ['Team Player', 'You joined a collaboration team.'],
              ['Portfolio Builder', 'You published a project with evidence.'],
              ['Challenge Finisher', 'A reviewed challenge was marked complete.'],
          ];
          foreach ($examples as $ex): ?>
            <div class="col-sm-6">
              <div class="feature-card h-100">
                <i class="bi bi-award text-gold-bright fs-3"></i>
                <h3 class="h6 mt-2 mb-1"><?= e($ex[0]) ?></h3>
                <p class="small mb-0"><?= e($ex[1]) ?></p>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="section-pad">
  <div class="container">
    <div class="panel p-4 p-lg-5">
      <div class="row g-4 align-items-center">
        <div class="col-lg-8">
          <h2 class="h3 mb-2">A prototype, not a finished promise.</h2>
          <p class="mb-0 text-muted">Every feature on this site is working end to end, but the pilot is small and the data is seeded for testing. Email is simulated because XAMPP has no mail server, rooms use polling rather than websockets, and the community is not live yet. We say so because trust matters more than looking finished.</p>
        </div>
        <div class="col-lg-4 text-lg-end">
          <a class="btn btn-outline-brown" href="<?= e(url('pages/about.php')) ?>">About the pilot</a>
        </div>
      </div>
    </div>
  </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>

<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_login();
if (!is_member()) {
    redirect(redirect_after_login());
}

$uid = user_id();
$user = current_user();
[$completeness, $missing] = profile_completeness($uid);

$stats = [
    'challenges' => db_count('SELECT COUNT(*) FROM challenge_participants WHERE user_id = ?', [$uid]),
    'completed' => db_count("SELECT COUNT(*) FROM challenge_participants WHERE user_id = ? AND status = 'completed'", [$uid]),
    'projects' => db_count('SELECT COUNT(*) FROM projects WHERE user_id = ?', [$uid]),
    'badges' => db_count('SELECT COUNT(*) FROM user_badges WHERE user_id = ?', [$uid]),
    'teams' => db_count('SELECT COUNT(*) FROM team_members WHERE user_id = ?', [$uid]),
    'ideas' => db_count('SELECT COUNT(*) FROM ideas WHERE user_id = ?', [$uid]),
];
$unread = unread_notifications_count($uid);
$myChallenges = db_all(
    'SELECT c.id, c.title, c.deadline, c.status AS challenge_status, cp.status, cp.joined_at
     FROM challenge_participants cp JOIN challenges c ON c.id = cp.challenge_id
     WHERE cp.user_id = ? ORDER BY cp.joined_at DESC LIMIT 5',
    [$uid]
);
$myTeams = db_all(
    'SELECT t.id, t.name, tm.role, (SELECT COUNT(*) FROM team_members tm2 WHERE tm2.team_id = t.id) AS members
     FROM team_members tm JOIN teams t ON t.id = tm.team_id WHERE tm.user_id = ? ORDER BY tm.joined_at DESC LIMIT 4',
    [$uid]
);
$myProjects = db_all('SELECT id, title, status, summary FROM projects WHERE user_id = ? ORDER BY updated_at DESC LIMIT 4', [$uid]);
$notifications = db_all('SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 5', [$uid]);
$mentorThreads = db_all(
    "SELECT mr.id, mr.status, u.name FROM mentor_requests mr JOIN users u ON u.id = mr.mentor_id
     WHERE mr.member_id = ? ORDER BY mr.created_at DESC LIMIT 3",
    [$uid]
);
$suggestedChallenges = db_all(
    "SELECT c.id, c.title, c.category, c.deadline, c.difficulty
     FROM challenges c WHERE c.status = 'published'
       AND c.id NOT IN (SELECT challenge_id FROM challenge_participants WHERE user_id = ?)
       AND (c.deadline IS NULL OR c.deadline >= CURDATE())
     ORDER BY c.deadline IS NULL, c.deadline ASC LIMIT 3",
    [$uid]
);
$suggestedOpportunities = db_all(
    "SELECT id, title, type, organization, deadline FROM opportunities
     WHERE status = 'approved' AND (deadline IS NULL OR deadline >= CURDATE())
     ORDER BY deadline IS NULL, deadline ASC LIMIT 3"
);
$openSupport = db_all(
    "SELECT i.id, i.title, i.status, COUNT(m.id) AS interests
     FROM ideas i JOIN idea_matches m ON m.idea_id = i.id
     WHERE i.user_id = ? AND m.status IN ('interested','in_discussion')
     GROUP BY i.id, i.title, i.status ORDER BY i.updated_at DESC LIMIT 3",
    [$uid]
);

$nextActions = [];
if ($completeness < 100) {
    $nextActions[] = ['label' => 'Finish your profile', 'detail' => $completeness . '% complete · missing: ' . implode(', ', array_slice($missing, 0, 3)), 'link' => 'pages/profile-edit.php', 'icon' => 'bi-person-check'];
}
if ($stats['challenges'] === 0) {
    $nextActions[] = ['label' => 'Join your first challenge', 'detail' => 'A short brief with real feedback is the fastest way to build evidence.', 'link' => 'pages/challenges.php', 'icon' => 'bi-lightning-charge'];
}
if ($stats['projects'] === 0) {
    $nextActions[] = ['label' => 'Add a project to your portfolio', 'detail' => 'Even a small, tested project counts.', 'link' => 'pages/project-form.php', 'icon' => 'bi-collection'];
}
if ($stats['teams'] === 0) {
    $nextActions[] = ['label' => 'Find a team', 'detail' => 'Collaboration is one of the strongest parts of the hub.', 'link' => 'pages/teams.php', 'icon' => 'bi-people'];
}
if (!$mentorThreads) {
    $nextActions[] = ['label' => 'Talk to a mentor', 'detail' => 'Bring one specific decision or piece of work.', 'link' => 'pages/mentors.php', 'icon' => 'bi-person-check'];
}
$nextActions = array_slice($nextActions, 0, 3);

$page_title = 'Your dashboard';
$page_description = 'Your progress, next actions and recent activity in the Mindset Innovators Hub pilot.';
require __DIR__ . '/../includes/header.php';
?>
<section class="section-pad-sm section-cream">
  <div class="container">
    <div class="row align-items-end g-3">
      <div class="col-lg-8">
        <span class="eyebrow">Your journey</span>
        <h1 class="display-5 mt-2 mb-1">Hello, <?= e(explode(' ', $user['name'])[0]) ?>.</h1>
        <p class="text-muted mb-0"><?= $completeness < 100 ? 'A few small steps will make your profile and portfolio easier for others to understand.' : 'Your profile is complete. Keep building evidence and helping others.' ?></p>
      </div>
      <div class="col-lg-4 text-lg-end">
        <a class="btn btn-gold" href="<?= e(url('pages/portfolio.php?u=' . urlencode($user['username']))) ?>"><i class="bi bi-collection me-1"></i>View my portfolio</a>
      </div>
    </div>
    <div class="mt-4"><?= journey_tracker($user['journey_stage']) ?></div>
  </div>
</section>

<section class="section-pad-sm">
  <div class="container">
    <div class="row g-3 mb-4">
      <div class="col-6 col-lg-3"><div class="dash-stat"><div class="d-flex justify-content-between"><div><div class="number"><?= $stats['challenges'] ?></div><div class="label">Challenges joined</div></div><span class="icon"><i class="bi bi-lightning-charge"></i></span></div></div></div>
      <div class="col-6 col-lg-3"><div class="dash-stat"><div class="d-flex justify-content-between"><div><div class="number"><?= $stats['completed'] ?></div><div class="label">Completed</div></div><span class="icon"><i class="bi bi-check2-circle"></i></span></div></div></div>
      <div class="col-6 col-lg-3"><div class="dash-stat"><div class="d-flex justify-content-between"><div><div class="number"><?= $stats['projects'] ?></div><div class="label">Portfolio projects</div></div><span class="icon"><i class="bi bi-collection"></i></span></div></div></div>
      <div class="col-6 col-lg-3"><div class="dash-stat"><div class="d-flex justify-content-between"><div><div class="number"><?= $stats['badges'] ?></div><div class="label">Badges</div></div><span class="icon"><i class="bi bi-award"></i></span></div></div></div>
    </div>

    <?php if ($completeness < 100): ?>
      <div class="panel panel-body mb-4">
        <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-2">
          <h2 class="h5 mb-0">Profile completeness</h2>
          <span class="fw-semibold"><?= $completeness ?>%</span>
        </div>
        <div class="completeness mb-2" role="progressbar" aria-valuenow="<?= $completeness ?>" aria-valuemin="0" aria-valuemax="100"><span style="width:<?= $completeness ?>%"></span></div>
        <p class="small text-muted mb-2">Still missing: <?= e(implode(', ', $missing)) ?>.</p>
        <a class="btn btn-sm btn-outline-brown" href="<?= e(url('pages/profile-edit.php')) ?>">Complete my profile</a>
      </div>
    <?php endif; ?>

    <div class="row g-4">
      <div class="col-lg-8">
        <?php if ($nextActions): ?>
          <div class="panel mb-4">
            <div class="panel-head"><h2><i class="bi bi-signpost-split me-2 text-gold"></i>Your next best steps</h2></div>
            <div class="panel-body">
              <?php foreach ($nextActions as $action): ?>
                <a class="d-flex gap-3 text-decoration-none border-bottom py-3" href="<?= e(url($action['link'])) ?>">
                  <span class="icon" style="width:42px;height:42px;border-radius:.7rem;background:rgba(212,175,55,.16);display:inline-flex;align-items:center;justify-content:center;color:#6C520E;flex:0 0 auto"><i class="bi <?= e($action['icon']) ?>"></i></span>
                  <span><span class="fw-semibold text-dark-brown d-block"><?= e($action['label']) ?></span><span class="small text-muted"><?= e($action['detail']) ?></span></span>
                </a>
              <?php endforeach; ?>
            </div>
          </div>
        <?php endif; ?>

        <div class="panel panel-body mb-4">
          <div class="d-flex justify-content-between align-items-center mb-3">
            <h2 class="h5 mb-0">My challenges</h2>
            <a class="small" href="<?= e(url('pages/challenges.php')) ?>">Find more</a>
          </div>
          <?php if (!$myChallenges): ?><p class="small text-muted mb-0">You have not joined a challenge yet. <a href="<?= e(url('pages/challenges.php')) ?>">Browse challenges</a>.</p><?php endif; ?>
          <?php foreach ($myChallenges as $ch): ?>
            <div class="d-flex justify-content-between align-items-center gap-2 border-bottom py-3">
              <div class="min-w-0"><a class="fw-semibold text-decoration-none" href="<?= e(url('pages/challenge-detail.php?id=' . (int) $ch['id'])) ?>"><?= e($ch['title']) ?></a><div class="small text-muted"><?= $ch['deadline'] ? 'Deadline ' . e(format_date($ch['deadline'])) : 'No deadline' ?></div></div>
              <?= status_badge($ch['status']) ?>
            </div>
          <?php endforeach; ?>
        </div>

        <div class="panel panel-body mb-4">
          <div class="d-flex justify-content-between align-items-center mb-3">
            <h2 class="h5 mb-0">My projects</h2>
            <a class="small" href="<?= e(url('pages/project-form.php')) ?>">Add project</a>
          </div>
          <?php if (!$myProjects): ?><p class="small text-muted mb-0">No projects yet. Publish one and it will appear in the showcase.</p><?php endif; ?>
          <?php foreach ($myProjects as $p): ?>
            <div class="d-flex justify-content-between align-items-center gap-2 border-bottom py-2">
              <div class="min-w-0"><a class="fw-semibold text-decoration-none" href="<?= e(url('pages/project-detail.php?id=' . (int) $p['id'])) ?>"><?= e($p['title']) ?></a><div class="small text-muted"><?= e(excerpt($p['summary'], 80)) ?></div></div>
              <?= status_badge($p['status']) ?>
            </div>
          <?php endforeach; ?>
        </div>

        <?php if ($openSupport): ?>
          <div class="panel panel-body">
            <h2 class="h5">Ideas with partner interest</h2>
            <?php foreach ($openSupport as $idea): ?>
              <div class="d-flex justify-content-between align-items-center gap-2 border-bottom py-2">
                <a class="small fw-semibold text-decoration-none" href="<?= e(url('pages/idea-detail.php?id=' . (int) $idea['id'] . '#matching')) ?>"><?= e($idea['title']) ?></a>
                <span class="badge badge-stage"><?= (int) $idea['interests'] ?> interest<?= (int) $idea['interests'] === 1 ? '' : 's' ?></span>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>

      <aside class="col-lg-4">
        <div class="panel panel-body mb-4">
          <div class="d-flex justify-content-between align-items-center mb-2">
            <h2 class="h5 mb-0">Notifications</h2>
            <a class="small" href="<?= e(url('pages/notifications.php')) ?>">All<?= $unread ? ' (' . $unread . ')' : '' ?></a>
          </div>
          <?php if (!$notifications): ?><p class="small text-muted mb-0">Nothing new right now.</p><?php endif; ?>
          <?php foreach ($notifications as $n): ?>
            <a class="d-block border-bottom py-2 text-decoration-none <?= $n['is_read'] ? '' : 'fw-semibold' ?>" href="<?= e(url($n['link'] ?: 'pages/notifications.php')) ?>">
              <span class="small text-dark-brown"><?= e(excerpt($n['body'], 90)) ?></span>
              <span class="d-block small text-muted"><?= e(time_ago($n['created_at'])) ?></span>
            </a>
          <?php endforeach; ?>
        </div>

        <div class="panel panel-body mb-4">
          <div class="d-flex justify-content-between align-items-center mb-2">
            <h2 class="h5 mb-0">My teams</h2>
            <a class="small" href="<?= e(url('pages/teams.php')) ?>">All</a>
          </div>
          <?php if (!$myTeams): ?><p class="small text-muted mb-0">You are not in a team yet.</p><?php endif; ?>
          <?php foreach ($myTeams as $team): ?>
            <a class="d-block border-bottom py-2 text-decoration-none" href="<?= e(url('pages/team.php?id=' . (int) $team['id'])) ?>">
              <span class="small fw-semibold text-dark-brown"><?= e($team['name']) ?></span>
              <span class="d-block small text-muted"><?= e(ucfirst($team['role'])) ?> · <?= (int) $team['members'] ?> members</span>
            </a>
          <?php endforeach; ?>
        </div>

        <div class="panel panel-body mb-4">
          <div class="d-flex justify-content-between align-items-center mb-2">
            <h2 class="h5 mb-0">Mentor conversations</h2>
            <a class="small" href="<?= e(url('pages/messages.php')) ?>">All</a>
          </div>
          <?php if (!$mentorThreads): ?><p class="small text-muted mb-2">No mentor requests yet.</p><a class="btn btn-sm btn-outline-brown w-100" href="<?= e(url('pages/mentors.php')) ?>">Find a mentor</a><?php endif; ?>
          <?php foreach ($mentorThreads as $t): ?>
            <a class="d-flex justify-content-between align-items-center gap-2 border-bottom py-2 text-decoration-none" href="<?= e(url('pages/messages.php?request=' . (int) $t['id'])) ?>">
              <span class="small"><?= e($t['name']) ?></span>
              <?= status_badge($t['status']) ?>
            </a>
          <?php endforeach; ?>
        </div>

        <div class="panel panel-body">
          <div class="small-caps mb-2">Suggested opportunities</div>
          <?php if (!$suggestedOpportunities): ?><p class="small text-muted mb-0">No open opportunities right now.</p><?php endif; ?>
          <?php foreach ($suggestedOpportunities as $o): ?>
            <a class="d-block border-bottom py-2 text-decoration-none" href="<?= e(url('pages/opportunity-detail.php?id=' . (int) $o['id'])) ?>">
              <span class="small fw-semibold text-dark-brown"><?= e($o['title']) ?></span>
              <span class="d-block small text-muted"><?= e(ucfirst($o['type'])) ?> · <?= e($o['organization']) ?><?= $o['deadline'] ? ' · ' . e(format_date($o['deadline'])) : '' ?></span>
            </a>
          <?php endforeach; ?>
          <a class="btn btn-sm btn-outline-brown w-100 mt-2" href="<?= e(url('pages/opportunities.php')) ?>">All opportunities</a>
        </div>
      </aside>
    </div>
  </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>

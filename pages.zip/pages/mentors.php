<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';

$page_title = 'Find a Mentor';
$page_description = 'Browse mentors in the Mindset Innovators Hub pilot and request a focused conversation about your project or next step.';
$active = 'explore';
$breadcrumbs = [['Mentors', null]];

$q = get('q');
$page = current_page_number();
$perPage = 6;
$where = ["u.role = 'mentor'", "u.status = 'active'"];
$params = [];
if ($q !== '') {
    $where[] = '(u.name LIKE ? OR mp.expertise LIKE ? OR p.headline LIKE ? OR p.bio LIKE ?)';
    $like = '%' . $q . '%';
    array_push($params, $like, $like, $like, $like);
}
$whereSql = implode(' AND ', $where);
$total = db_count("SELECT COUNT(*) FROM users u JOIN mentor_profiles mp ON mp.user_id = u.id LEFT JOIN profiles p ON p.user_id = u.id WHERE $whereSql", $params);
$pages = max(1, (int) ceil($total / $perPage));
$page = min($page, $pages);
$offset = ($page - 1) * $perPage;

$stmt = db()->prepare(
    "SELECT u.id, u.name, u.username, u.is_demo, p.headline, p.bio, p.location, p.photo,
            mp.expertise, mp.availability, mp.capacity,
            (SELECT COUNT(*) FROM mentor_requests mr WHERE mr.mentor_id = u.id AND mr.status = 'accepted') AS active_mentees
     FROM users u JOIN mentor_profiles mp ON mp.user_id = u.id LEFT JOIN profiles p ON p.user_id = u.id
     WHERE $whereSql ORDER BY u.name LIMIT $perPage OFFSET $offset"
);
$stmt->execute($params);
$mentors = $stmt->fetchAll();

$myRequests = [];
if (is_logged_in()) {
    $rows = db_all('SELECT mentor_id, status FROM mentor_requests WHERE member_id = ? ORDER BY created_at DESC', [user_id()]);
    foreach ($rows as $row) {
        if (!isset($myRequests[(int) $row['mentor_id']])) {
            $myRequests[(int) $row['mentor_id']] = $row['status'];
        }
    }
}
$myMentorProfile = is_mentor() ? db_one('SELECT * FROM mentor_profiles WHERE user_id = ?', [user_id()]) : null;

require __DIR__ . '/../includes/header.php';
?>
<section class="section-pad-sm section-cream">
  <div class="container">
    <div class="row align-items-end g-3">
      <div class="col-lg-8">
        <span class="eyebrow">Guidance, not answers</span>
        <h1 class="display-5 mt-2 mb-1">Find a Mentor</h1>
        <p class="text-muted mb-0">A mentor can help you choose a small next step, test an assumption and present your work honestly. Requests are focused, not open-ended.</p>
      </div>
      <div class="col-lg-4 text-lg-end">
        <?php if (is_mentor()): ?>
          <a class="btn btn-gold" href="<?= e(url('pages/mentor-form.php')) ?>"><i class="bi bi-pencil me-1"></i><?= $myMentorProfile ? 'Edit my mentor profile' : 'Become a mentor' ?></a>
        <?php elseif (is_member()): ?>
          <a class="btn btn-outline-brown" href="<?= e(url('pages/messages.php')) ?>"><i class="bi bi-chat-dots me-1"></i>My mentor conversations</a>
        <?php endif; ?>
      </div>
    </div>
  </div>
</section>

<section class="section-pad-sm">
  <div class="container">
    <form class="filter-bar mb-4" method="get" action="<?= e(url('pages/mentors.php')) ?>">
      <div class="row g-2 align-items-end">
        <div class="col-lg-9">
          <label class="form-label" for="q">Search by name, skill or topic</label>
          <input class="form-control" id="q" name="q" value="<?= e($q) ?>" placeholder="For example: product, data, accessibility…">
        </div>
        <div class="col-lg-3 d-grid">
          <button class="btn btn-gold" type="submit"><i class="bi bi-search me-1"></i>Search mentors</button>
        </div>
      </div>
      <?php if ($q): ?><div class="mt-2"><a class="small" href="<?= e(url('pages/mentors.php')) ?>">Clear search</a></div><?php endif; ?>
    </form>

    <div class="alert alert-info small" role="note">
      <i class="bi bi-info-circle me-1"></i>Mentors in this prototype are demo accounts. They cannot provide emergency support, medical advice or guaranteed opportunities. For anything urgent, contact a trusted adult or local service.
    </div>

    <?php if (!$mentors): ?>
      <div class="panel empty-state mx-auto">
        <i class="bi bi-person-check display-4"></i>
        <h2>No mentors match</h2>
        <p>Try a different search. New mentors are added as the pilot grows.</p>
        <a class="btn btn-outline-brown" href="<?= e(url('pages/mentors.php')) ?>">Show all mentors</a>
      </div>
    <?php else: ?>
      <div class="row g-4">
        <?php foreach ($mentors as $m): $status = $myRequests[(int) $m['id']] ?? null; $places = max(0, (int) $m['capacity'] - (int) $m['active_mentees']); ?>
          <div class="col-md-6 col-lg-4">
            <article class="card h-100 card-hover">
              <div class="card-body d-flex flex-column">
                <div class="d-flex align-items-center gap-3 mb-3">
                  <?= avatar_html($m, $m, 'md') ?>
                  <div class="min-w-0">
                    <h2 class="h5 mb-0"><a class="text-decoration-none stretched-link" href="<?= e(url('pages/mentor-detail.php?id=' . (int) $m['id'])) ?>"><?= e($m['name']) ?></a></h2>
                    <div class="small text-muted"><?= e(excerpt((string) ($m['headline'] ?: 'Mentor'), 65)) ?></div>
                    <?= demo_badge($m['is_demo']) ?>
                  </div>
                </div>
                <p class="small text-muted mb-2"><i class="bi bi-stars me-1 text-gold"></i><strong class="text-dark-brown">Expertise:</strong> <?= e(excerpt($m['expertise'], 140)) ?></p>
                <?php if ($m['availability']): ?><p class="small text-muted mb-2"><i class="bi bi-calendar-week me-1 text-gold"></i><?= e($m['availability']) ?></p><?php endif; ?>
                <div class="mt-auto d-flex flex-wrap justify-content-between align-items-center gap-2 pt-2 border-top">
                  <span class="small <?= $places > 0 ? 'text-success' : 'text-danger' ?>"><?= $places > 0 ? $places . ' place' . ($places === 1 ? '' : 's') . ' available' : 'At capacity' ?></span>
                  <div class="d-flex gap-1 align-items-center">
                    <?php if ($status): ?><?= status_badge($status) ?><?php endif; ?>
                    <?php if ($m['location']): ?><span class="small text-muted"><i class="bi bi-geo-alt me-1"></i><?= e($m['location']) ?></span><?php endif; ?>
                  </div>
                </div>
              </div>
            </article>
          </div>
        <?php endforeach; ?>
      </div>
      <?= pagination($total, $page, $perPage, array_filter(['q' => $q])) ?>
    <?php endif; ?>
  </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>

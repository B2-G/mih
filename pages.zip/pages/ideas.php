<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';

$page_title = 'Idea Board';
$page_description = 'Share an idea, get constructive feedback and find the mentor or partner who can help you test it.';
$active = 'explore';
$breadcrumbs = [['Idea Board', null]];

$q = get('q');
$category = get('category');
$stage = get('stage');
$matching = get('matching');
$page = current_page_number();
$perPage = PER_PAGE;
$uid = user_id();

$where = [];
$params = [];
// Visibility: public ideas for everyone; member ideas for signed-in accounts;
// private ideas only for their owner and admins.
if (!is_logged_in()) {
    $where[] = "i.visibility = 'public'";
} elseif (is_admin()) {
    $where[] = '1 = 1';
} else {
    $where[] = "(i.visibility IN ('public','members') OR i.user_id = ?)";
    $params[] = $uid;
}
if ($q !== '') {
    $where[] = '(i.title LIKE ? OR i.problem LIKE ? OR i.solution LIKE ?)';
    $like = '%' . $q . '%';
    array_push($params, $like, $like, $like);
}
if ($category !== '') {
    $where[] = 'i.category = ?';
    $params[] = $category;
}
if ($stage !== '' && array_key_exists($stage, journey_stages())) {
    $where[] = 'i.stage = ?';
    $params[] = $stage;
}
if ($matching === 'ready') {
    $where[] = 'i.ready_for_matching = 1';
}
if (in_array($matching, ['open', 'in_discussion', 'matched'], true)) {
    $where[] = 'i.status = ?';
    $params[] = $matching;
}
$whereSql = $where ? implode(' AND ', $where) : '1 = 1';

$total = db_count("SELECT COUNT(*) FROM ideas i WHERE $whereSql", $params);
$pages = max(1, (int) ceil($total / $perPage));
$page = min($page, $pages);
$offset = ($page - 1) * $perPage;

$stmt = db()->prepare(
    "SELECT i.*, u.name, u.username, u.is_demo,
            (SELECT COUNT(*) FROM idea_supports s WHERE s.idea_id = i.id) AS supports,
            (SELECT COUNT(*) FROM idea_comments c WHERE c.idea_id = i.id) AS comments,
            (SELECT COUNT(*) FROM idea_matches m WHERE m.idea_id = i.id) AS matches
     FROM ideas i JOIN users u ON u.id = i.user_id
     WHERE $whereSql
     ORDER BY i.ready_for_matching DESC, i.created_at DESC
     LIMIT $perPage OFFSET $offset"
);
$stmt->execute($params);
$ideas = $stmt->fetchAll();
$categories = db_all('SELECT DISTINCT category FROM ideas ORDER BY category');
$readyCount = db_count("SELECT COUNT(*) FROM ideas i WHERE $whereSql AND i.ready_for_matching = 1", $params);

require __DIR__ . '/../includes/header.php';
?>
<section class="section-pad-sm section-cream">
  <div class="container">
    <div class="row align-items-end g-3">
      <div class="col-lg-8">
        <span class="eyebrow">Imagine · Test · Match</span>
        <h1 class="display-5 mt-2 mb-1">Idea Board</h1>
        <p class="text-muted mb-0">An idea does not have to be finished to be useful. Share the problem, the first solution you can imagine, and what help you need.</p>
      </div>
      <div class="col-lg-4 text-lg-end d-flex flex-wrap gap-2 justify-content-lg-end">
        <?php if (is_member() || is_admin()): ?><a class="btn btn-gold" href="<?= e(url('pages/idea-form.php')) ?>"><i class="bi bi-plus-lg me-1"></i>Share an idea</a><?php endif; ?>
        <span class="badge badge-soft align-self-center"><?= (int) $readyCount ?> ready for matching</span>
      </div>
    </div>
  </div>
</section>

<section class="section-pad-sm">
  <div class="container">
    <form class="filter-bar mb-4" method="get" action="<?= e(url('pages/ideas.php')) ?>">
      <div class="row g-2 align-items-end">
        <div class="col-lg-4 col-md-6">
          <label class="form-label" for="q">Search ideas</label>
          <input class="form-control" id="q" name="q" value="<?= e($q) ?>" placeholder="Problem, solution or title">
        </div>
        <div class="col-lg-2 col-md-6">
          <label class="form-label" for="category">Category</label>
          <select class="form-select" id="category" name="category">
            <option value="">All categories</option>
            <?php foreach ($categories as $cat): ?><option value="<?= e($cat['category']) ?>" <?= $category === $cat['category'] ? 'selected' : '' ?>><?= e($cat['category']) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="col-lg-2 col-md-6">
          <label class="form-label" for="stage">Stage</label>
          <select class="form-select" id="stage" name="stage">
            <option value="">All stages</option>
            <?php foreach (array_keys(journey_stages()) as $s): ?><option value="<?= e($s) ?>" <?= $stage === $s ? 'selected' : '' ?>><?= e($s) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="col-lg-2 col-md-6">
          <label class="form-label" for="matching">Status</label>
          <select class="form-select" id="matching" name="matching">
            <option value="">Any status</option>
            <option value="ready" <?= $matching === 'ready' ? 'selected' : '' ?>>Ready for matching</option>
            <option value="open" <?= $matching === 'open' ? 'selected' : '' ?>>Open</option>
            <option value="in_discussion" <?= $matching === 'in_discussion' ? 'selected' : '' ?>>In discussion</option>
            <option value="matched" <?= $matching === 'matched' ? 'selected' : '' ?>>Matched</option>
          </select>
        </div>
        <div class="col-lg-2 d-grid">
          <button class="btn btn-gold" type="submit"><i class="bi bi-search me-1"></i>Filter</button>
        </div>
      </div>
      <?php if ($q || $category || $stage || $matching): ?><div class="mt-2"><a class="small" href="<?= e(url('pages/ideas.php')) ?>">Clear filters</a></div><?php endif; ?>
    </form>

    <?php if (!$ideas): ?>
      <div class="panel empty-state mx-auto">
        <i class="bi bi-lightbulb display-4"></i>
        <h2>No ideas match yet</h2>
        <p>Try clearing the filters. If you are a member, you can be the first to share a problem worth solving.</p>
        <?php if (is_member() || is_admin()): ?><a class="btn btn-gold" href="<?= e(url('pages/idea-form.php')) ?>">Share an idea</a><?php else: ?><a class="btn btn-outline-brown" href="<?= e(url('pages/ideas.php')) ?>">Clear filters</a><?php endif; ?>
      </div>
    <?php else: ?>
      <div class="row g-3">
        <?php foreach ($ideas as $idea): ?>
          <div class="col-md-6">
            <article class="card idea-card card-hover">
              <div class="card-body d-flex flex-column">
                <div class="d-flex flex-wrap gap-2 mb-2">
                  <span class="badge badge-stage"><?= e($idea['category']) ?></span>
                  <span class="badge badge-tag"><?= e($idea['stage']) ?></span>
                  <?= status_badge($idea['status']) ?>
                  <?php if ($idea['ready_for_matching']): ?><span class="badge text-bg-warning"><i class="bi bi-link-45deg me-1"></i>Ready to match</span><?php endif; ?>
                  <?php if ($idea['visibility'] !== 'public'): ?><span class="badge badge-soft"><i class="bi bi-eye-slash me-1"></i><?= e(ucfirst($idea['visibility'])) ?></span><?php endif; ?>
                </div>
                <h2 class="h5"><a class="stretched-link text-decoration-none" href="<?= e(url('pages/idea-detail.php?id=' . (int) $idea['id'])) ?>"><?= e($idea['title']) ?></a></h2>
                <p class="problem mb-2"><strong class="text-dark-brown">Problem:</strong> <?= e(excerpt($idea['problem'], 150)) ?></p>
                <p class="small text-muted mb-3"><strong class="text-dark-brown">First idea:</strong> <?= e(excerpt($idea['solution'], 120)) ?></p>
                <div class="mt-auto d-flex justify-content-between align-items-center gap-2">
                  <div class="meta-row mb-0">
                    <span><i class="bi bi-hand-thumbs-up me-1"></i><?= (int) $idea['supports'] ?></span>
                    <span><i class="bi bi-chat me-1"></i><?= (int) $idea['comments'] ?></span>
                    <?php if ($idea['matches']): ?><span><i class="bi bi-people me-1"></i><?= (int) $idea['matches'] ?> interest</span><?php endif; ?>
                  </div>
                  <?= demo_badge($idea['is_demo']) ?>
                </div>
              </div>
              <div class="card-footer bg-transparent small text-muted d-flex justify-content-between">
                <span>By <?= e($idea['name']) ?> <?= demo_badge($idea['is_demo']) ?></span>
                <span><?= e(time_ago($idea['created_at'])) ?></span>
              </div>
            </article>
          </div>
        <?php endforeach; ?>
      </div>
      <?= pagination($total, $page, $perPage, array_filter(['q' => $q, 'category' => $category, 'stage' => $stage, 'matching' => $matching])) ?>
    <?php endif; ?>
  </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>

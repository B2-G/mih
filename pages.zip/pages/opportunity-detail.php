<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';

$id = get_int('id') ?: (int) post('opportunity_id');
$opportunity = $id ? db_one(
    'SELECT o.*, u.name AS poster_name, u.username AS poster_username, u.role AS poster_role, u.is_demo AS poster_demo
     FROM opportunities o LEFT JOIN users u ON u.id = o.posted_by WHERE o.id = ?',
    [$id]
) : null;
if (!$opportunity) {
    not_found('That opportunity could not be found.');
}
$uid = user_id();
$isPoster = $uid > 0 && (int) $opportunity['posted_by'] === $uid;
$isAdmin = is_admin();
if ($opportunity['status'] !== 'approved' && !$isPoster && !$isAdmin) {
    not_found('That opportunity is not published.');
}
$types = ['competition' => 'Competition', 'internship' => 'Internship', 'training' => 'Training', 'grant' => 'Grant', 'job' => 'Job', 'event' => 'Event'];
$label = $types[$opportunity['type']] ?? $opportunity['type'];
$expired = $opportunity['deadline'] && strtotime($opportunity['deadline']) < strtotime('today');

if (is_post()) {
    require_login();
    require_csrf();
    $action = post('action');

    if (in_array($action, ['saved', 'interested', 'applied'], true)) {
        if ($opportunity['status'] !== 'approved') {
            flash('warning', 'Actions are only available on approved opportunities.');
            redirect('pages/opportunity-detail.php?id=' . $id);
        }
        if ($expired && $action !== 'saved') {
            flash('warning', 'The deadline has passed, so interest and application tracking are closed.');
            redirect('pages/opportunity-detail.php?id=' . $id);
        }
        $exists = db_count('SELECT COUNT(*) FROM opportunity_actions WHERE opportunity_id = ? AND user_id = ? AND action = ?', [$id, $uid, $action]);
        if ($exists) {
            db_run('DELETE FROM opportunity_actions WHERE opportunity_id = ? AND user_id = ? AND action = ?', [$id, $uid, $action]);
            flash('info', 'The "' . $action . '" mark was removed.');
        } else {
            db_run('INSERT INTO opportunity_actions (opportunity_id, user_id, action) VALUES (?, ?, ?)', [$id, $uid, $action]);
            if (in_array($action, ['interested', 'applied'], true) && $opportunity['posted_by'] && !$isPoster) {
                notify((int) $opportunity['posted_by'], 'opportunity', current_user()['name'] . ' marked "' . $action . '" for ' . $opportunity['title'] . '.', 'pages/opportunity-detail.php?id=' . $id);
            }
            log_activity('opportunity.' . $action, 'opportunity', $id, $opportunity['title']);
            flash('success', 'Your "' . $action . '" mark was saved.');
        }
        redirect('pages/opportunity-detail.php?id=' . $id);

    } elseif ($action === 'moderate') {
        if (!$isAdmin) {
            forbidden('Only admins can approve or reject opportunities.');
        }
        $status = post('status');
        if (!in_array($status, ['approved', 'rejected', 'closed', 'pending'], true)) {
            flash('danger', 'Choose a valid status.');
        } else {
            db_run('UPDATE opportunities SET status = ? WHERE id = ?', [$status, $id]);
            if ($opportunity['posted_by'] && (int) $opportunity['posted_by'] !== $uid) {
                notify((int) $opportunity['posted_by'], 'opportunity', 'Your opportunity "' . $opportunity['title'] . '" is now ' . $status . '.', 'pages/opportunity-detail.php?id=' . $id);
            }
            log_activity('opportunity.moderated', 'opportunity', $id, $status);
            flash('success', 'The opportunity status is now ' . $status . '.');
        }
        redirect('pages/opportunity-detail.php?id=' . $id);
    }
}

$counts = ['saved' => 0, 'interested' => 0, 'applied' => 0];
$rows = db_all('SELECT action, COUNT(*) AS total FROM opportunity_actions WHERE opportunity_id = ? GROUP BY action', [$id]);
foreach ($rows as $row) {
    $counts[$row['action']] = (int) $row['total'];
}
$mine = [];
if ($uid) {
    $rows = db_all('SELECT action FROM opportunity_actions WHERE opportunity_id = ? AND user_id = ?', [$id, $uid]);
    foreach ($rows as $row) {
        $mine[$row['action']] = true;
    }
}

$page_title = $opportunity['title'];
$page_description = excerpt($opportunity['description'], 155);
$breadcrumbs = [['Opportunities', 'pages/opportunities.php'], [$opportunity['title'], null]];
require __DIR__ . '/../includes/header.php';
?>
<section class="section-pad-sm section-cream">
  <div class="container">
    <div class="row g-4 align-items-start">
      <div class="col-lg-8">
        <div class="d-flex flex-wrap gap-2 mb-2">
          <span class="badge badge-stage text-uppercase"><?= e($label) ?></span>
          <?= status_badge($opportunity['status']) ?>
          <?= demo_badge($opportunity['is_demo']) ?>
          <?php if ($expired): ?><span class="badge text-bg-danger">Deadline passed</span><?php endif; ?>
        </div>
        <h1 class="display-6 mt-2 mb-2"><?= e($opportunity['title']) ?></h1>
        <p class="lead"><?= e($opportunity['organization']) ?></p>
        <div class="meta-row mb-4">
          <span><i class="bi bi-calendar3 me-1"></i><?= $opportunity['deadline'] ? 'Deadline ' . e(format_date($opportunity['deadline'])) : 'No stated deadline' ?></span>
          <span><i class="bi bi-bookmark me-1"></i><?= $counts['saved'] ?> saved</span>
          <span><i class="bi bi-star me-1"></i><?= $counts['interested'] ?> interested</span>
          <span><i class="bi bi-send me-1"></i><?= $counts['applied'] ?> marked applied</span>
        </div>
      </div>
      <div class="col-lg-4">
        <div class="panel panel-body">
          <div class="small-caps mb-2">Take action</div>
          <a class="btn btn-gold w-100 mb-2" href="<?= e($opportunity['link']) ?>" target="_blank" rel="noopener noreferrer nofollow"><i class="bi bi-box-arrow-up-right me-1"></i>Open official listing</a>
          <?php if ($opportunity['status'] !== 'approved'): ?>
            <p class="small text-muted mb-0">This listing is <?= e($opportunity['status']) ?>, so member actions are unavailable.</p>
          <?php elseif (!is_logged_in()): ?>
            <p class="small text-muted mb-2">Sign in to save or track this opportunity.</p>
            <a class="btn btn-outline-brown w-100" href="<?= e(url('pages/login.php?next=' . urlencode('pages/opportunity-detail.php?id=' . $id))) ?>">Sign in</a>
          <?php elseif (!is_member() && !$isAdmin): ?>
            <p class="small text-muted mb-0">You are signed in as a <?= e(user_role()) ?>. Saving and application tracking are for member accounts.</p>
          <?php else: ?>
            <div class="d-grid gap-2">
              <?php foreach (['saved' => 'Save for later', 'interested' => 'Mark interested', 'applied' => 'Mark as applied'] as $key => $text): ?>
                <form method="post" action="<?= e(url('pages/opportunity-detail.php?id=' . $id)) ?>">
                  <?= csrf_field() ?>
                  <input type="hidden" name="action" value="<?= e($key) ?>">
                  <button class="btn <?= !empty($mine[$key]) ? 'btn-brown' : 'btn-outline-brown' ?> w-100" type="submit" <?= ($expired && $key !== 'saved') ? 'disabled' : '' ?>>
                    <i class="bi <?= $key === 'saved' ? 'bi-bookmark' : ($key === 'interested' ? 'bi-star' : 'bi-send') ?> me-1"></i><?= !empty($mine[$key]) ? 'Remove: ' . e($text) : e($text) ?>
                  </button>
                </form>
              <?php endforeach; ?>
            </div>
            <p class="form-text mt-2 mb-0">These marks are private to you. The prototype does not submit an application to the organisation.</p>
          <?php endif; ?>
          <?php if ($isPoster || $isAdmin): ?>
            <hr>
            <a class="btn btn-sm btn-outline-brown w-100" href="<?= e(url('pages/opportunity-form.php?id=' . $id)) ?>"><i class="bi bi-pencil me-1"></i>Edit listing</a>
          <?php endif; ?>
          <?php if ($isAdmin): ?>
            <form method="post" action="<?= e(url('pages/opportunity-detail.php?id=' . $id)) ?>" class="mt-2">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="moderate">
              <label class="form-label" for="status">Admin status</label>
              <select class="form-select form-select-sm" id="status" name="status">
                <?php foreach (['pending', 'approved', 'rejected', 'closed'] as $st): ?><option value="<?= e($st) ?>" <?= $opportunity['status'] === $st ? 'selected' : '' ?>><?= e(ucfirst($st)) ?></option><?php endforeach; ?>
              </select>
              <button class="btn btn-sm btn-brown w-100 mt-2" type="submit">Update status</button>
            </form>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="section-pad-sm">
  <div class="container">
    <div class="row g-4">
      <div class="col-lg-8">
        <div class="panel panel-body mb-4">
          <h2 class="h5">About this opportunity</h2>
          <div class="text-muted" style="white-space:pre-line"><?= e($opportunity['description']) ?></div>
          <?php if ($opportunity['tags']): ?>
            <h3 class="h6 mt-4">Tags</h3>
            <div><?php foreach (tags_to_array($opportunity['tags']) as $tag): ?><span class="skill-chip"><?= e($tag) ?></span><?php endforeach; ?></div>
          <?php endif; ?>
        </div>
        <div class="alert alert-info small" role="note">
          <strong>Before you apply:</strong> check the official listing, confirm the deadline and eligibility, and never pay a fee. This prototype listing is demo data and is not an endorsement.
        </div>
      </div>
      <aside class="col-lg-4">
        <div class="panel panel-body">
          <div class="small-caps mb-2">Posted by</div>
          <?php if ($opportunity['poster_name']): ?>
            <a class="fw-semibold text-decoration-none" href="<?= e(url('pages/profile.php?u=' . urlencode($opportunity['poster_username']))) ?>"><?= e($opportunity['poster_name']) ?></a> <?= demo_badge($opportunity['poster_demo']) ?>
            <div class="small text-muted"><?= e(role_label($opportunity['poster_role'])) ?> · <?= e(format_date($opportunity['created_at'])) ?></div>
          <?php else: ?><p class="small text-muted mb-0">Unknown</p><?php endif; ?>
        </div>
      </aside>
    </div>
  </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>

<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';

if (is_logged_in()) {
    redirect(redirect_after_login());
}

$page_title = 'Create an account';
$page_description = 'Join the Mindset Innovators Hub pilot as a member, mentor or partner organisation.';
$errors = [];
$form = ['name' => '', 'username' => '', 'email' => '', 'role' => 'member'];
$roles = ['member' => 'Member — young innovator', 'mentor' => 'Mentor — experienced professional', 'partner' => 'Partner — organisation or institution'];

if (is_post()) {
    require_csrf();
    $form['name'] = post('name');
    $form['username'] = strtolower(post('username'));
    $form['email'] = strtolower(post('email'));
    $form['role'] = post('role', 'member');
    $password = (string) ($_POST['password'] ?? '');
    $confirm = (string) ($_POST['password_confirm'] ?? '');
    $terms = isset($_POST['terms']);

    if (mb_strlen($form['name']) < 2 || mb_strlen($form['name']) > 120) {
        $errors['name'] = 'Please enter your full name.';
    }
    if (!valid_username($form['username'])) {
        $errors['username'] = 'Use 3–30 letters, numbers, dots, dashes or underscores.';
    }
    if (!valid_email($form['email'])) {
        $errors['email'] = 'Please enter a valid email address.';
    }
    if (mb_strlen($password) < 8 || !preg_match('/[A-Za-z]/', $password) || !preg_match('/[0-9]/', $password)) {
        $errors['password'] = 'Use at least 8 characters, including a letter and a number.';
    }
    if ($password !== $confirm) {
        $errors['password_confirm'] = 'The passwords do not match.';
    }
    if (!array_key_exists($form['role'], $roles)) {
        $errors['role'] = 'Please choose a valid account type.';
    }
    if (!$terms) {
        $errors['terms'] = 'Please confirm that you understand this is a prototype.';
    }
    if (!isset($errors['username']) && db_count('SELECT COUNT(*) FROM users WHERE username = ?', [$form['username']])) {
        $errors['username'] = 'That username is already taken. Try another.';
    }
    if (!isset($errors['email']) && db_count('SELECT COUNT(*) FROM users WHERE email = ?', [$form['email']])) {
        $errors['email'] = 'An account already uses that email. Try signing in or resetting your password.';
    }
    if (!rate_limit_hit('register', 5, 60)) {
        $errors['form'] = 'Too many sign-up attempts from this connection. Please try again later.';
    }

    if (!$errors) {
        $status = $form['role'] === 'member' ? 'active' : 'pending';
        try {
            db()->beginTransaction();
            db_run(
                'INSERT INTO users (name, username, email, password_hash, role, status) VALUES (?, ?, ?, ?, ?, ?)',
                [$form['name'], $form['username'], $form['email'], password_hash($password, PASSWORD_DEFAULT), $form['role'], $status]
            );
            $newId = (int) db()->lastInsertId();
            db_run('INSERT INTO profiles (user_id, journey_stage, privacy) VALUES (?, ?, ?)', [$newId, 'Discover', 'members']);

            $token = bin2hex(random_bytes(32));
            db_run(
                'INSERT INTO email_verifications (user_id, token_hash, expires_at) VALUES (?, ?, ?)',
                [$newId, hash('sha256', $token), date('Y-m-d H:i:s', time() + TOKEN_TTL)]
            );
            db()->commit();
        } catch (PDOException $ex) {
            if (db()->inTransaction()) {
                db()->rollBack();
            }
            $errors['form'] = 'We could not create the account. Please try again.';
        }
    }

    if (!$errors) {
        $verifyLink = url('pages/verify.php?token=' . urlencode($token));
        simulated_mail(
            $form['email'],
            'Verify your Mindset Innovators Hub email (prototype)',
            "Hello " . $form['name'] . ",\n\nWelcome to the Mindset Innovators Hub prototype. Verify your email within one hour:\n" . $verifyLink,
            $verifyLink
        );
        log_activity('auth.register', 'user', $newId, $form['role'], $newId);
        login_user($newId);
        if ($status === 'pending') {
            notify_admins('account_pending', 'A new ' . $form['role'] . ' account is waiting for approval: ' . $form['name'] . '.', 'admin/users.php?status=pending');
            flash('info', 'Your ' . $form['role'] . ' account has been created and is waiting for admin approval. You can complete your profile in the meantime.');
            redirect('pages/dashboard.php');
        }
        flash('info', 'Your account is ready. Take one minute to choose your interests and starting stage.');
        redirect('pages/onboarding.php');
    }
}

require __DIR__ . '/../includes/header.php';
?>
<section class="section-pad">
  <div class="container">
    <div class="row g-4 align-items-stretch justify-content-center">
      <div class="col-lg-5 d-none d-lg-block">
        <div class="auth-side h-100">
          <span class="eyebrow text-gold-bright">Join the pilot</span>
          <h2 class="display-6 mt-2">One account. A whole pathway.</h2>
          <p>Members get the full journey tools. Mentors and partners can apply to review work, share opportunities and support ideas.</p>
          <ul class="step-list">
            <li><span class="n">1</span><span>Create your account and choose your role.</span></li>
            <li><span class="n">2</span><span>Tell us what you care about and where you are starting.</span></li>
            <li><span class="n">3</span><span>Take one small, practical next step.</span></li>
          </ul>
          <div class="alert alert-warning small mt-4 mb-0"><i class="bi bi-shield-check me-1"></i>Mentor and partner accounts are reviewed by an admin before their special tools become available.</div>
        </div>
      </div>
      <div class="col-lg-6">
        <div class="auth-card">
          <h1 class="h3 mb-1">Create your account</h1>
          <p class="text-muted small mb-4">This is a prototype. Use a real email only if you are comfortable testing with it.</p>
          <?= error_summary($errors) ?>
          <?php if (!empty($errors['form'])): ?><div class="alert alert-danger"><?= e($errors['form']) ?></div><?php endif; ?>
          <form method="post" action="<?= e(url('pages/register.php')) ?>" class="needs-validation" novalidate data-single-submit>
            <?= csrf_field() ?>
            <div class="row g-3">
              <div class="col-12">
                <label class="form-label" for="name">Full name <span class="text-danger">*</span></label>
                <input class="form-control <?= isset($errors['name']) ? 'is-invalid' : '' ?>" id="name" name="name" required maxlength="120" autocomplete="name" value="<?= e($form['name']) ?>">
                <?= field_error($errors, 'name') ?>
              </div>
              <div class="col-md-6">
                <label class="form-label" for="username">Username <span class="text-danger">*</span></label>
                <div class="input-group">
                  <span class="input-group-text">@</span>
                  <input class="form-control <?= isset($errors['username']) ? 'is-invalid' : '' ?>" id="username" name="username" required minlength="3" maxlength="30" pattern="[a-zA-Z0-9._\-]{3,30}" autocomplete="username" value="<?= e($form['username']) ?>">
                  <?= field_error($errors, 'username') ?>
                </div>
                <div class="form-text">Used in your portfolio link.</div>
              </div>
              <div class="col-md-6">
                <label class="form-label" for="email">Email <span class="text-danger">*</span></label>
                <input type="email" class="form-control <?= isset($errors['email']) ? 'is-invalid' : '' ?>" id="email" name="email" required maxlength="190" autocomplete="email" value="<?= e($form['email']) ?>">
                <?= field_error($errors, 'email') ?>
              </div>
              <div class="col-12">
                <span class="form-label d-block">I am joining as <span class="text-danger">*</span></span>
                <div class="row g-2">
                  <?php foreach ($roles as $value => $label): ?>
                    <div class="col-md-4">
                      <label class="choice-card small" for="role_<?= e($value) ?>">
                        <input type="radio" id="role_<?= e($value) ?>" name="role" value="<?= e($value) ?>" <?= $form['role'] === $value ? 'checked' : '' ?> required>
                        <?= e($label) ?>
                      </label>
                    </div>
                  <?php endforeach; ?>
                </div>
                <?= field_error($errors, 'role') ?>
              </div>
              <div class="col-md-6">
                <label class="form-label" for="password">Password <span class="text-danger">*</span></label>
                <input type="password" class="form-control <?= isset($errors['password']) ? 'is-invalid' : '' ?>" id="password" name="password" required minlength="8" autocomplete="new-password">
                <div class="form-text">At least 8 characters, with a letter and a number.</div>
                <?= field_error($errors, 'password') ?>
              </div>
              <div class="col-md-6">
                <label class="form-label" for="password_confirm">Confirm password <span class="text-danger">*</span></label>
                <input type="password" class="form-control <?= isset($errors['password_confirm']) ? 'is-invalid' : '' ?>" id="password_confirm" name="password_confirm" required autocomplete="new-password">
                <?= field_error($errors, 'password_confirm') ?>
              </div>
              <div class="col-12">
                <div class="form-check">
                  <input class="form-check-input <?= isset($errors['terms']) ? 'is-invalid' : '' ?>" type="checkbox" id="terms" name="terms" <?= isset($_POST['terms']) ? 'checked' : '' ?> required>
                  <label class="form-check-label small" for="terms">I understand this is an early-stage prototype, not a launched service, and I agree to respectful participation.</label>
                  <?= field_error($errors, 'terms') ?>
                </div>
              </div>
            </div>
            <button class="btn btn-gold w-100 mt-4" type="submit">Create account</button>
            <p class="text-center small text-muted mt-3 mb-0">Already have an account? <a href="<?= e(url('pages/login.php')) ?>">Sign in</a></p>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>

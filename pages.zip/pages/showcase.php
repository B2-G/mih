<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';

$page_title = 'Showcase';
$page_description = 'Explore projects built by members of the Mindset Innovators Hub pilot, with the skills and evidence behind them.';
$active = 'explore';
$breadcrumbs = [['Showcase', null]];

$q = get('q');
$category = get('category');
$page = current_page_number();
$perPage = PER_PAGE;

$where = ["p.status = 'published'"];
$params = [];
if ($q !== '') {
    $where[] = '(p.title LIKE ? OR p.summary LIKE ? OR p.description LIKE ? OR p.skills_used LIKE ?)';
    $like = '%' . $q . '%';
    array_push($params, $like, $like, $like, $like);
}
if ($category !== '') {
    $where[] = 'p.category = ?';
    $params[] = $category;
}
$whereSql = implode(' AND ', $where);
$total = db_count("SELECT COUNT(*) FROM projects p WHERE $whereSql", $params);
$pages = max(1, (int) ceil($total / $perPage));
$page = min($page, $pages);
$offset = ($page - 1) * $perPage;

$stmt = db()->prepare(
    "SELECT p.*, u.name, u.username, u.is_demo AS user_demo,
            (SELECT COUNT(*) FROM project_feedback f WHERE f.project_id = p.id) AS feedback_count
     FROM projects p JOIN users u ON u.id = p.user_id
     WHERE $whereSql ORDER BY p.created_at DESC LIMIT $perPage OFFSET $offset"
);
$stmt->execute($params);
$projects = $stmt->fetchAll();
$categories = db_all("SELECT DISTINCT category FROM projects WHERE status = 'published' ORDER BY category");

require __DIR__ . '/../includes/header.php';
?>
<section class="section-pad-sm section-cream">
  <div class="container">
    <div class="row align-items-end g-3">
      <div class="col-lg-8">
        <span class="eyebrow">Show what you built</span>
        <h1 class="display-5 mt-2 mb-1">Impact Portfolio &amp; Showcase</h1>
        <p class="text-muted mb-0">Real, small projects with honest notes about what was tested and what still needs work. This is evidence of learning, not a polished startup pitch.</p>
      </div>
      <div class="col-lg-4 text-lg-end">
        <?php if (is_member() || is_admin()): ?><a class="btn btn-gold" href="<?= e(url('pages/project-form.php')) ?>"><i class="bi bi-plus-lg me-1"></i>Add a project</a><?php endif; ?>
      </div>
    </div>
  </div>
</section>

<section class="section-pad-sm">
  <div class="container">
    <form class="filter-bar mb-4" method="get" action="<?= e(url('pages/showcase.php')) ?>">
      <div class="row g-2 align-items-end">
        <div class="col-lg-7 col-md-6">
          <label class="form-label" for="q">Search projects</label>
          <input class="form-control" id="q" name="q" value="<?= e($q) ?>" placeholder="Title, skill or topic">
        </div>
        <div class="col-lg-3 col-md-6">
          <label class="form-label" for="category">Category</label>
          <select class="form-select" id="category" name="category">
            <option value="">All categories</option>
            <?php foreach ($categories as $cat): ?><option value="<?= e($cat['category']) ?>" <?= $category === $cat['category'] ? 'selected' : '' ?>><?= e($cat['category']) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="col-lg-2 d-grid">
          <button class="btn btn-gold" type="submit"><i class="bi bi-search me-1"></i>Filter</button>
        </div>
      </div>
      <?php if ($q || $category): ?><div class="mt-2"><a class="small" href="<?= e(url('pages/showcase.php')) ?>">Clear filters</a></div><?php endif; ?>
    </form>

    <?php if (!$projects): ?>
      <div class="panel empty-state mx-auto">
        <i class="bi bi-collection display-4"></i>
        <h2>No projects here yet</h2>
        <p>Try clearing the filters. Members can publish a first project from their portfolio.</p>
        <a class="btn btn-outline-brown" href="<?= e(url('pages/showcase.php')) ?>">Show all projects</a>
      </div>
    <?php else: ?>
      <div class="row g-4">
        <?php foreach ($projects as $p): ?>
          <div class="col-md-6 col-lg-4">
            <article class="card project-card card-hover">
              <div class="project-cover">
                <?php if ($p['image']): ?><img src="<?= e(url($p['image'])) ?>" alt="Cover image for <?= e($p['title']) ?>"><?php else: ?><span class="cover-initials" aria-hidden="true"><?= e(initials($p['title'])) ?></span><?php endif; ?>
              </div>
              <div class="card-body d-flex flex-column">
                <div class="d-flex justify-content-between align-items-start gap-2 mb-2">
                  <span class="badge badge-tag"><?= e($p['category']) ?></span>
                  <?= demo_badge($p['is_demo']) ?>
                </div>
                <h2 class="h5"><a class="stretched-link text-decoration-none" href="<?= e(url('pages/project-detail.php?id=' . (int) $p['id'])) ?>"><?= e($p['title']) ?></a></h2>
                <p class="summary"><?= e(excerpt($p['summary'], 130)) ?></p>
                <?php if ($p['skills_used']): ?>
                  <div class="mb-2"><?php foreach (array_slice(tags_to_array($p['skills_used'], 4), 0, 3) as $skill): ?><span class="skill-chip"><?= e($skill) ?></span><?php endforeach; ?></div>
                <?php endif; ?>
                <div class="mt-auto d-flex justify-content-between align-items-center small text-muted pt-2">
                  <span><?= e($p['name']) ?> <?= demo_badge($p['user_demo']) ?></span>
                  <span><i class="bi bi-chat me-1"></i><?= (int) $p['feedback_count'] ?></span>
                </div>
              </div>
            </article>
          </div>
        <?php endforeach; ?>
      </div>
      <?= pagination($total, $page, $perPage, array_filter(['q' => $q, 'category' => $category])) ?>
    <?php endif; ?>
  </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>

<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';

$page_title = 'For Institutions and Partners';
$page_description = 'Collaborate with Mindset Innovators Hub as a school, university, NGO, training provider, company, mentor or sponsor.';
$active = 'partners';
$breadcrumbs = [['For partners', null]];

$errors = [];
$form = ['org_name' => '', 'contact_name' => '', 'email' => '', 'phone' => '', 'org_type' => '', 'message' => ''];

if (is_post()) {
    require_csrf();
    foreach ($form as $key => $_) {
        $form[$key] = post($key);
    }
    $honeypot = post('website_url');
    if ($honeypot !== '') {
        flash('success', 'Thank you. Your enquiry has been received.');
        redirect('pages/partners.php');
    }
    if (!rate_limit_hit('partner_enquiry', 3, 60)) {
        $errors['form'] = 'Too many enquiries from this connection. Please try again later.';
    }
    if (mb_strlen($form['org_name']) < 2 || mb_strlen($form['org_name']) > 180) {
        $errors['org_name'] = 'Please enter your organisation name.';
    }
    if (mb_strlen($form['contact_name']) < 2 || mb_strlen($form['contact_name']) > 120) {
        $errors['contact_name'] = 'Please enter a contact name.';
    }
    if (!valid_email($form['email'])) {
        $errors['email'] = 'Please enter a valid email address.';
    }
    $allowedTypes = ['School', 'University', 'NGO', 'Training provider', 'Company', 'Sponsor', 'Mentor network', 'Other'];
    if (!in_array($form['org_type'], $allowedTypes, true)) {
        $errors['org_type'] = 'Please choose an organisation type.';
    }
    if (mb_strlen($form['message']) < 20) {
        $errors['message'] = 'Please tell us a little more (at least 20 characters).';
    }
    if ($form['phone'] !== '' && !preg_match('/^[0-9 +()\-]{7,30}$/', $form['phone'])) {
        $errors['phone'] = 'Please enter a valid phone number, or leave it blank.';
    }
    if (!$errors) {
        db_run(
            'INSERT INTO partner_enquiries (org_name, contact_name, email, phone, org_type, message, ip) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [$form['org_name'], $form['contact_name'], $form['email'], $form['phone'] ?: null, $form['org_type'], $form['message'], client_ip()]
        );
        log_activity('partner.enquiry', 'partner_enquiry', (int) db()->lastInsertId(), $form['org_name']);
        notify_admins('partner_enquiry', 'New partnership enquiry from ' . $form['org_name'] . '.', 'admin/enquiries.php');
        flash('success', 'Thank you. Your partnership enquiry has been saved. This prototype does not send email automatically, so the team will follow up through the contact details you provided.');
        redirect('pages/partners.php');
    }
}

$partnerCount = db_count("SELECT COUNT(*) FROM users WHERE role = 'partner' AND status = 'active'");
$opportunityCount = db_count("SELECT COUNT(*) FROM opportunities WHERE status = 'approved'");
$sponsoredCount = db_count("SELECT COUNT(*) FROM challenges WHERE status = 'published' AND sponsor_name IS NOT NULL");
require __DIR__ . '/../includes/header.php';
?>
<section class="section-pad-sm section-cream">
  <div class="container">
    <div class="row g-4 align-items-center">
      <div class="col-lg-8">
        <span class="eyebrow">For institutions and partners</span>
        <h1 class="display-4 mt-2 mb-3">Help young people move from learning to doing.</h1>
        <p class="lead-lg mb-0">Schools, universities, NGOs, training providers, companies, mentors and sponsors can all contribute something concrete: a brief, a piece of feedback, a room, an opportunity or a first chance.</p>
      </div>
      <div class="col-lg-4">
        <div class="row g-2">
          <div class="col-4"><div class="dash-stat text-center"><div class="number"><?= number_format($partnerCount) ?></div><div class="label">Partners</div></div></div>
          <div class="col-4"><div class="dash-stat text-center"><div class="number"><?= number_format($opportunityCount) ?></div><div class="label">Live listings</div></div></div>
          <div class="col-4"><div class="dash-stat text-center"><div class="number"><?= number_format($sponsoredCount) ?></div><div class="label">Sponsored</div></div></div>
        </div>
        <p class="small text-muted mt-2 mb-0">Live prototype counts, including labelled demo records.</p>
      </div>
    </div>
  </div>
</section>

<section class="section-pad">
  <div class="container">
    <div class="row g-4">
      <?php
      $ways = [
          ['bi-mortarboard', 'Schools and universities', 'Use challenges as practical assignments, invite students into the pilot and help them build evidence of their skills.'],
          ['bi-heart', 'NGOs and community organisations', 'Bring a real community problem into the Idea Board, sponsor a challenge or help members understand local context.'],
          ['bi-briefcase', 'Companies and employers', 'Post internships, jobs, competitions or events. Review portfolios that show evidence of work, not just grades.'],
          ['bi-person-video3', 'Mentors and professionals', 'Offer a small amount of focused time. Review submissions, join a room or take on one or two mentees.'],
          ['bi-trophy', 'Sponsors', 'Sponsor a challenge with a clear, useful brief. Sponsorship is shown on the challenge card and tracked in the prototype.'],
          ['bi-diagram-3', 'Training providers', 'Share training opportunities and collaborate on a pathway from learning to practice.'],
      ];
      foreach ($ways as $w): ?>
        <div class="col-md-6 col-lg-4">
          <div class="feature-card h-100">
            <div class="feature-icon"><i class="bi <?= $w[0] ?>"></i></div>
            <h2 class="h5"><?= e($w[1]) ?></h2>
            <p class="text-muted small mb-0"><?= e($w[2]) ?></p>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="section-pad section-cream" id="enquiry">
  <div class="container">
    <div class="row g-5">
      <div class="col-lg-5">
        <span class="eyebrow">Start a conversation</span>
        <h2 class="display-6 mt-2 mb-3">Partnership enquiry</h2>
        <p class="lead">Tell us what you have in mind. This form saves your enquiry to the prototype database so an admin can review it. It does not send an automatic email.</p>
        <ul class="list-clean small">
          <li><i class="bi bi-check2-circle text-gold me-2"></i>A small pilot is more useful than a big announcement.</li>
          <li><i class="bi bi-check2-circle text-gold me-2"></i>We will not publish your organisation as a partner without permission.</li>
          <li><i class="bi bi-check2-circle text-gold me-2"></i>You can also email <a href="mailto:<?= e(CONTACT_EMAIL) ?>"><?= e(CONTACT_EMAIL) ?></a>.</li>
        </ul>
        <div class="alert alert-warning small mt-4 mb-0"><i class="bi bi-info-circle me-1"></i>Partnership enquiries submitted here are demo/pilot enquiries, stored only in this installation.</div>
      </div>
      <div class="col-lg-7">
        <div class="panel panel-body">
          <?= error_summary($errors) ?>
          <?php if (!empty($errors['form'])): ?><div class="alert alert-danger"><?= e($errors['form']) ?></div><?php endif; ?>
          <form method="post" action="<?= e(url('pages/partners.php#enquiry')) ?>" class="needs-validation" novalidate data-single-submit>
            <?= csrf_field() ?>
            <div class="d-none" aria-hidden="true">
              <label for="website_url">Leave this field blank</label>
              <input type="text" id="website_url" name="website_url" tabindex="-1" autocomplete="off">
            </div>
            <div class="row g-3">
              <div class="col-md-6">
                <label class="form-label" for="org_name">Organisation name <span class="text-danger">*</span></label>
                <input class="form-control <?= isset($errors['org_name']) ? 'is-invalid' : '' ?>" id="org_name" name="org_name" required maxlength="180" value="<?= e($form['org_name']) ?>">
                <?= field_error($errors, 'org_name') ?>
              </div>
              <div class="col-md-6">
                <label class="form-label" for="contact_name">Your name <span class="text-danger">*</span></label>
                <input class="form-control <?= isset($errors['contact_name']) ? 'is-invalid' : '' ?>" id="contact_name" name="contact_name" required maxlength="120" value="<?= e($form['contact_name']) ?>">
                <?= field_error($errors, 'contact_name') ?>
              </div>
              <div class="col-md-6">
                <label class="form-label" for="email">Email <span class="text-danger">*</span></label>
                <input type="email" class="form-control <?= isset($errors['email']) ? 'is-invalid' : '' ?>" id="email" name="email" required maxlength="190" value="<?= e($form['email']) ?>">
                <?= field_error($errors, 'email') ?>
              </div>
              <div class="col-md-6">
                <label class="form-label" for="phone">Phone <span class="text-muted">(optional)</span></label>
                <input type="tel" class="form-control <?= isset($errors['phone']) ? 'is-invalid' : '' ?>" id="phone" name="phone" maxlength="30" value="<?= e($form['phone']) ?>">
                <?= field_error($errors, 'phone') ?>
              </div>
              <div class="col-12">
                <label class="form-label" for="org_type">Organisation type <span class="text-danger">*</span></label>
                <select class="form-select <?= isset($errors['org_type']) ? 'is-invalid' : '' ?>" id="org_type" name="org_type" required>
                  <option value="">Choose one…</option>
                  <?php foreach ($allowedTypes as $t): ?>
                    <option value="<?= e($t) ?>" <?= $form['org_type'] === $t ? 'selected' : '' ?>><?= e($t) ?></option>
                  <?php endforeach; ?>
                </select>
                <?= field_error($errors, 'org_type') ?>
              </div>
              <div class="col-12">
                <label class="form-label" for="message">What would you like to explore? <span class="text-danger">*</span></label>
                <textarea class="form-control <?= isset($errors['message']) ? 'is-invalid' : '' ?>" id="message" name="message" required minlength="20" maxlength="3000" data-counter="#msgCount"><?= e($form['message']) ?></textarea>
                <div class="d-flex justify-content-between"><div class="form-text">Please include the kind of collaboration you have in mind.</div><div class="form-text" id="msgCount"></div></div>
                <?= field_error($errors, 'message') ?>
              </div>
            </div>
            <button class="btn btn-gold mt-4" type="submit">Send partnership enquiry</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>

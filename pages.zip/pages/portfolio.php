<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';

$username = get('u');
if ($username === '' && is_logged_in()) {
    $username = current_user()['username'];
}
if ($username === '') {
    flash('warning', 'Choose a member to view their portfolio.');
    redirect('pages/login.php?next=' . urlencode('pages/portfolio.php'));
}
$person = db_one(
    'SELECT u.*, p.* FROM users u LEFT JOIN profiles p ON p.user_id = u.id WHERE u.username = ?',
    [$username]
);
if (!$person) {
    not_found('That portfolio could not be found.');
}
$uid = user_id();
$isOwner = $uid > 0 && (int) $person['id'] === $uid;
$isAdmin = is_admin();
$privacy = $person['privacy'] ?? 'members';
if (($privacy === 'private' || $person['status'] !== 'active') && !$isOwner && !$isAdmin) {
    forbidden('This portfolio is private.');
}
if ($privacy === 'members' && !is_logged_in()) {
    flash('warning', 'Sign in to view this portfolio.');
    redirect('pages/login.php?next=' . urlencode('pages/portfolio.php?u=' . $username));
}

$personId = (int) $person['id'];
$includeDrafts = $isOwner || $isAdmin;
$projectSql = $includeDrafts
    ? 'SELECT * FROM projects WHERE user_id = ? ORDER BY created_at DESC'
    : "SELECT * FROM projects WHERE user_id = ? AND status = 'published' ORDER BY created_at DESC";

$projects = db_all($projectSql, [$personId]);
$skills = db_all(
    'SELECT s.name, us.level FROM user_skills us JOIN skills s ON s.id = us.skill_id WHERE us.user_id = ? ORDER BY us.level DESC, s.name',
    [$personId]
);
$badges = db_all(
    'SELECT b.*, ub.awarded_at FROM user_badges ub JOIN badges b ON b.id = ub.badge_id WHERE ub.user_id = ? ORDER BY ub.awarded_at DESC',
    [$personId]
);
$completed = db_all(
    "SELECT c.id, c.title, c.category, s.score, s.feedback, s.reviewed_at
     FROM submissions s JOIN challenges c ON c.id = s.challenge_id
     WHERE s.user_id = ? AND s.status = 'completed' ORDER BY s.reviewed_at DESC",
    [$personId]
);
$teams = db_all(
    'SELECT t.id, t.name, tm.role, tm.joined_at FROM team_members tm JOIN teams t ON t.id = tm.team_id
     WHERE tm.user_id = ? ORDER BY tm.joined_at DESC',
    [$personId]
);
$ideas = db_all(
    "SELECT id, title, category, status, created_at FROM ideas WHERE user_id = ? AND visibility = 'public' ORDER BY created_at DESC LIMIT 6",
    [$personId]
);
$mentorProfile = $person['role'] === 'mentor'
    ? db_one('SELECT * FROM mentor_profiles WHERE user_id = ?', [$personId]) : null;
$stats = [
    'projects' => count($projects),
    'completed' => count($completed),
    'badges' => count($badges),
    'teams' => count($teams),
];

$page_title = ($person['name'] ?? $username) . ' · Portfolio';
$page_description = excerpt((string) ($person['headline'] ?: $person['bio'] ?: 'An impact portfolio on the Mindset Innovators Hub pilot.'), 155);
$active = 'explore';
$breadcrumbs = [['Showcase', 'pages/showcase.php'], ['Portfolio', null]];
require __DIR__ . '/../includes/header.php';
?>
<div class="print-header container pt-3">
  <h1 class="h3 mb-0"><?= e($person['name']) ?> — Impact Portfolio</h1>
  <p class="small text-muted">Mindset Innovators Hub pilot · Printed <?= e(date('j M Y')) ?> · Demo profile: <?= $person['is_demo'] ? 'yes' : 'no' ?></p>
</div>

<section class="section-pad-sm section-cream">
  <div class="container">
    <div class="profile-hero">
      <div class="row g-4 align-items-center">
        <div class="col-md-auto text-center text-md-start">
          <?= avatar_html($person, $person, 'xl') ?>
        </div>
        <div class="col-md">
          <div class="d-flex flex-wrap gap-2 mb-2">
            <span class="badge badge-stage"><?= e(role_label($person['role'])) ?></span>
            <?= demo_badge($person['is_demo']) ?>
            <?php if ($person['journey_stage']): ?><span class="badge badge-prototype"><i class="bi bi-signpost-split me-1"></i><?= e($person['journey_stage']) ?></span><?php endif; ?>
            <?php if ($person['status'] !== 'active'): ?><?= status_badge($person['status']) ?><?php endif; ?>
          </div>
          <h1 class="display-6 mb-1"><?= e($person['name']) ?></h1>
          <?php if ($person['headline']): ?><p class="lead mb-2"><?= e($person['headline']) ?></p><?php endif; ?>
          <div class="meta-row">
            <?php if ($person['location']): ?><span><i class="bi bi-geo-alt me-1"></i><?= e($person['location']) ?></span><?php endif; ?>
            <span><i class="bi bi-calendar3 me-1"></i>Member since <?= e(format_date($person['created_at'], 'M Y')) ?></span>
            <?php if ($person['role'] === 'mentor'): ?><span><i class="bi bi-person-check me-1"></i>Mentor</span><?php endif; ?>
          </div>
        </div>
        <div class="col-md-auto no-print">
          <div class="d-flex flex-column gap-2">
            <?php if ($isOwner): ?><a class="btn btn-gold" href="<?= e(url('pages/project-form.php')) ?>"><i class="bi bi-plus-lg me-1"></i>Add project</a><?php endif; ?>
            <button class="btn btn-outline-gold" type="button" onclick="window.print()"><i class="bi bi-printer me-1"></i>Print portfolio</button>
            <button class="btn btn-outline-gold" type="button" data-copy="<?= e(url('pages/portfolio.php?u=' . urlencode($username))) ?>"><i class="bi bi-link-45deg me-1"></i>Copy link</button>
          </div>
        </div>
      </div>
      <?php if ($person['journey_stage']): ?>
        <div class="mt-4"><?= journey_tracker($person['journey_stage']) ?></div>
      <?php endif; ?>
    </div>

    <div class="row g-3 mt-1">
      <div class="col-6 col-lg-3"><div class="dash-stat"><div class="d-flex justify-content-between"><div><div class="number"><?= $stats['projects'] ?></div><div class="label">Projects</div></div><span class="icon"><i class="bi bi-collection"></i></span></div></div></div>
      <div class="col-6 col-lg-3"><div class="dash-stat"><div class="d-flex justify-content-between"><div><div class="number"><?= $stats['completed'] ?></div><div class="label">Completed challenges</div></div><span class="icon"><i class="bi bi-check2-circle"></i></span></div></div></div>
      <div class="col-6 col-lg-3"><div class="dash-stat"><div class="d-flex justify-content-between"><div><div class="number"><?= $stats['badges'] ?></div><div class="label">Badges</div></div><span class="icon"><i class="bi bi-award"></i></span></div></div></div>
      <div class="col-6 col-lg-3"><div class="dash-stat"><div class="d-flex justify-content-between"><div><div class="number"><?= $stats['teams'] ?></div><div class="label">Teams</div></div><span class="icon"><i class="bi bi-people"></i></span></div></div></div>
    </div>
  </div>
</section>

<section class="section-pad-sm">
  <div class="container">
    <div class="row g-4">
      <div class="col-lg-8">
        <div class="panel panel-body mb-4">
          <h2 class="h5">About</h2>
          <?php if ($person['bio']): ?><div class="text-muted" style="white-space:pre-line"><?= e($person['bio']) ?></div><?php else: ?><p class="text-muted small mb-0">This member has not added a bio yet.</p><?php endif; ?>
          <?php if ($person['goals']): ?>
            <h3 class="h6 mt-4">What I am working towards</h3>
            <div class="text-muted" style="white-space:pre-line"><?= e($person['goals']) ?></div>
          <?php endif; ?>
          <?php if ($person['interests']): ?>
            <h3 class="h6 mt-4">Interests</h3>
            <div><?php foreach (tags_to_array($person['interests'], 12) as $interest): ?><span class="skill-chip"><?= e($interest) ?></span><?php endforeach; ?></div>
          <?php endif; ?>
          <?php if ($skills): ?>
            <h3 class="h6 mt-4">Skills</h3>
            <div><?php foreach ($skills as $skill): ?><span class="skill-chip"><?= e($skill['name']) ?> <span class="level"><?= e($skill['level']) ?></span></span><?php endforeach; ?></div>
          <?php endif; ?>
          <?php if ($mentorProfile): ?>
            <h3 class="h6 mt-4">Mentoring</h3>
            <p class="small text-muted mb-1"><strong>Expertise:</strong> <?= e($mentorProfile['expertise']) ?></p>
            <?php if ($mentorProfile['availability']): ?><p class="small text-muted mb-0"><strong>Availability:</strong> <?= e($mentorProfile['availability']) ?></p><?php endif; ?>
          <?php endif; ?>
          <?php if ($person['website'] || $person['linkedin'] || $person['github']): ?>
            <h3 class="h6 mt-4">Links</h3>
            <div class="d-flex flex-wrap gap-3 small">
              <?php if ($person['website']): ?><a href="<?= e($person['website']) ?>" target="_blank" rel="noopener noreferrer nofollow"><i class="bi bi-globe me-1"></i>Website</a><?php endif; ?>
              <?php if ($person['linkedin']): ?><a href="<?= e($person['linkedin']) ?>" target="_blank" rel="noopener noreferrer nofollow"><i class="bi bi-linkedin me-1"></i>LinkedIn</a><?php endif; ?>
              <?php if ($person['github']): ?><a href="<?= e($person['github']) ?>" target="_blank" rel="noopener noreferrer nofollow"><i class="bi bi-github me-1"></i>GitHub</a><?php endif; ?>
            </div>
          <?php endif; ?>
        </div>

        <div class="panel panel-body mb-4">
          <div class="d-flex justify-content-between align-items-center mb-3">
            <h2 class="h5 mb-0">Projects</h2>
            <?php if ($isOwner): ?><a class="small" href="<?= e(url('pages/project-form.php')) ?>">Add project</a><?php endif; ?>
          </div>
          <?php if (!$projects): ?><p class="small text-muted mb-0">No published projects yet.</p><?php endif; ?>
          <div class="row g-3">
            <?php foreach ($projects as $p): ?>
              <div class="col-md-6">
                <div class="card project-card">
                  <div class="project-cover">
                    <?php if ($p['image']): ?><img src="<?= e(url($p['image'])) ?>" alt="Cover image for <?= e($p['title']) ?>"><?php else: ?><span class="cover-initials" aria-hidden="true"><?= e(initials($p['title'])) ?></span><?php endif; ?>
                  </div>
                  <div class="card-body">
                    <div class="d-flex justify-content-between gap-2 mb-1"><span class="badge badge-tag"><?= e($p['category']) ?></span><?php if ($p['status'] === 'draft'): ?><?= status_badge('draft') ?><?php endif; ?></div>
                    <h3><a class="stretched-link text-decoration-none" href="<?= e(url('pages/project-detail.php?id=' . (int) $p['id'])) ?>"><?= e($p['title']) ?></a></h3>
                    <p class="summary"><?= e(excerpt($p['summary'], 110)) ?></p>
                  </div>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        </div>

        <div class="panel panel-body mb-4">
          <h2 class="h5">Completed challenges</h2>
          <?php if (!$completed): ?><p class="small text-muted mb-0">No completed challenges yet. Completed work and reviewer feedback will appear here.</p><?php endif; ?>
          <?php foreach ($completed as $c): ?>
            <div class="border-bottom py-3">
              <div class="d-flex flex-wrap justify-content-between gap-2">
                <div><a class="fw-semibold text-decoration-none" href="<?= e(url('pages/challenge-detail.php?id=' . (int) $c['id'])) ?>"><?= e($c['title']) ?></a> <span class="badge badge-tag"><?= e($c['category']) ?></span></div>
                <?php if ($c['score'] !== null): ?><span class="badge text-bg-success"><?= (int) $c['score'] ?>/100</span><?php endif; ?>
              </div>
              <?php if ($c['feedback']): ?><p class="small text-muted mb-0 mt-1"><i class="bi bi-chat-quote me-1"></i><?= e(excerpt($c['feedback'], 220)) ?></p><?php endif; ?>
              <div class="small text-muted mt-1">Reviewed <?= e(format_date($c['reviewed_at'])) ?></div>
            </div>
          <?php endforeach; ?>
        </div>

        <?php if ($ideas): ?>
          <div class="panel panel-body">
            <h2 class="h5">Public ideas</h2>
            <?php foreach ($ideas as $idea): ?>
              <div class="border-bottom py-2 d-flex justify-content-between gap-2">
                <a class="small text-decoration-none fw-semibold" href="<?= e(url('pages/idea-detail.php?id=' . (int) $idea['id'])) ?>"><?= e($idea['title']) ?></a>
                <?= status_badge($idea['status']) ?>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>

      <aside class="col-lg-4">
        <div class="panel panel-body mb-4">
          <div class="small-caps mb-2">Badges earned</div>
          <?php if (!$badges): ?><p class="small text-muted mb-0">No badges yet.</p><?php endif; ?>
          <?php foreach ($badges as $badge): ?>
            <div class="badge-earned">
              <i class="bi <?= e($badge['icon'] ?: 'bi-award') ?>"></i>
              <div><div class="fw-semibold small"><?= e($badge['name']) ?></div><div class="small text-muted"><?= e($badge['description']) ?></div><div class="small text-muted">Earned <?= e(format_date($badge['awarded_at'])) ?></div></div>
            </div>
          <?php endforeach; ?>
        </div>
        <div class="panel panel-body">
          <div class="small-caps mb-2">Teams</div>
          <?php if (!$teams): ?><p class="small text-muted mb-0">Not in a team yet.</p><?php endif; ?>
          <?php foreach ($teams as $team): ?>
            <div class="d-flex justify-content-between align-items-center border-bottom py-2">
              <div><a class="small fw-semibold text-decoration-none" href="<?= e(url('pages/team.php?id=' . (int) $team['id'])) ?>"><?= e($team['name']) ?></a><div class="small text-muted"><?= e(ucfirst($team['role'])) ?> · joined <?= e(format_date($team['joined_at'], 'M Y')) ?></div></div>
              <i class="bi bi-people text-gold"></i>
            </div>
          <?php endforeach; ?>
        </div>
      </aside>
    </div>
  </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>

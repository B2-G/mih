<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_login();
$page_title = 'Leaderboard';
$page_description = 'Live points and activity leaderboard';
require __DIR__ . '/../includes/header.php';
?>
<main id="main-content">
<section class="section-pad-lg">
  <div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h1>Leaderboard</h1>
    </div>
    <div class="table-responsive">
      <table class="table table-bordered small">
        <thead>
          <tr>
            <th>Rank</th>
            <th>Name</th>
            <th>Role</th>
            <th>Points</th>
            <th>Badges</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $leaders = db_all(
              'SELECT u.id, u.username, u.role, u.is_demo,
                      COALESCE(SUM(n.points), 0) as points,
                      COUNT(DISTINCT nb.badge_id) as badge_count
               FROM users u
               LEFT JOIN notifications n ON n.user_id = u.id AND n.is_read = 1
               LEFT JOIN user_badges nb ON nb.user_id = u.id
               GROUP BY u.id, u.username, u.role, u.is_demo
               ORDER BY points DESC, badge_count DESC
               LIMIT 10'
          );
          foreach ($leaders as $i => $l): 
            $rank = $i + 1;
            $demo = $l['is_demo'] ? ' (demo)' : '';
            $roleLabel = role_label($l['role']);
          ?>
          <tr>
            <td><span class="badge bg-gold"><?= $rank ?></span></td>
            <td><strong><?= e($l['username']) ?><?= $demo ?></strong></td>
            <td><span class="badge bg-brown small"><?= e($roleLabel) ?></span></td>
            <td><strong><?= e($l['points']) ?></strong></td>
            <td><span class="badge bg-gold small"><?= e($l['badge_count']) ?></span></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <div class="mt-3 text-center small text-muted">
      Points earned from accepted mentor requests, completed challenges, and published projects.
    </div>
  </div>
</section>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
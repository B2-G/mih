<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';

$page_title = 'Verify your email';
$page_description = 'Verify the email address on your Mindset Innovators Hub account.';
$token = get('token');
$message = null;
$messageType = 'info';

if ($token !== '') {
    $row = db_one(
        "SELECT * FROM email_verifications WHERE token_hash = ? AND used_at IS NULL AND expires_at > NOW() LIMIT 1",
        [hash('sha256', $token)]
    );
    if ($row) {
        db_run('UPDATE email_verifications SET used_at = NOW() WHERE id = ?', [(int) $row['id']]);
        db_run('UPDATE users SET email_verified = 1 WHERE id = ?', [(int) $row['user_id']]);
        log_activity('auth.email_verified', 'user', (int) $row['user_id'], null, (int) $row['user_id']);
        $message = 'Thank you. Your email address has been verified.';
        $messageType = 'success';
        if (is_logged_in() && user_id() === (int) $row['user_id']) {
            // refresh the cached current user for the pending banner
            flash('success', $message);
            redirect(redirect_after_login());
        }
    } else {
        $message = 'This verification link is invalid, already used or expired. You can request a new one below if you are signed in.';
        $messageType = 'danger';
    }
}

$errors = [];
if (is_post() && is_logged_in()) {
    require_csrf();
    if (!rate_limit_hit('verify_resend', 3, 60)) {
        $errors['form'] = 'Too many verification requests. Please try again later.';
    } else {
        $tokenNew = bin2hex(random_bytes(32));
        db_run('DELETE FROM email_verifications WHERE user_id = ? AND used_at IS NULL', [user_id()]);
        db_run(
            'INSERT INTO email_verifications (user_id, token_hash, expires_at) VALUES (?, ?, ?)',
            [user_id(), hash('sha256', $tokenNew), date('Y-m-d H:i:s', time() + TOKEN_TTL)]
        );
        $link = url('pages/verify.php?token=' . urlencode($tokenNew));
        simulated_mail(
            current_user()['email'],
            'Verify your Mindset Innovators Hub email (prototype)',
            "Hello " . current_user()['name'] . ",\n\nVerify your email within one hour:\n" . $link,
            $link
        );
        flash('success', 'A new verification link has been generated. Check storage/mail.log or the debug panel.');
        redirect('pages/verify.php');
    }
}

$user = current_user();
$breadcrumbs = [['Verify email', null]];
require __DIR__ . '/../includes/header.php';
?>
<section class="section-pad">
  <div class="container">
    <div class="auth-wrap">
      <div class="auth-card text-center">
        <i class="bi <?= $user && $user['email_verified'] ? 'bi-patch-check' : 'bi-envelope-check' ?> display-4 text-gold"></i>
        <h1 class="h3 mt-3">Email verification</h1>
        <?php if ($message): ?><div class="alert alert-<?= e($messageType) ?> text-start"><?= e($message) ?></div><?php endif; ?>
        <?php if ($user && (int) $user['email_verified'] === 1): ?>
          <p class="text-muted">Your email address is verified.</p>
          <a class="btn btn-gold" href="<?= e(url(redirect_after_login())) ?>">Go to dashboard</a>
        <?php elseif ($user): ?>
          <p class="text-muted">Your email is still unverified. Verification is simulated in this prototype: the link is written to <code>storage/mail.log</code> and shown in the debug panel when debug mode is on.</p>
          <?= error_summary($errors) ?>
          <?php if (!empty($errors['form'])): ?><div class="alert alert-danger"><?= e($errors['form']) ?></div><?php endif; ?>
          <form method="post" action="<?= e(url('pages/verify.php')) ?>" data-single-submit>
            <?= csrf_field() ?>
            <button class="btn btn-gold" type="submit">Generate a new verification link</button>
          </form>
        <?php else: ?>
          <p class="text-muted">This link does not match a signed-in account. Open the verification link from the simulated email, or sign in to request a new one.</p>
          <a class="btn btn-gold" href="<?= e(url('pages/login.php')) ?>">Sign in</a>
        <?php endif; ?>
      </div>
    </div>
  </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>

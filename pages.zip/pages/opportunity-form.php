<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_role(['partner', 'admin']);

$id = get_int('id') ?: (int) post('opportunity_id');
$opportunity = $id ? db_one('SELECT * FROM opportunities WHERE id = ?', [$id]) : null;
if ($id && !$opportunity) {
    not_found('That opportunity could not be found.');
}
if ($opportunity && (int) $opportunity['posted_by'] !== user_id() && !is_admin()) {
    forbidden('You can only edit opportunities you posted.');
}

$types = ['competition' => 'Competition', 'internship' => 'Internship', 'training' => 'Training', 'grant' => 'Grant', 'job' => 'Job', 'event' => 'Event'];
$errors = [];
$values = [
    'title' => $opportunity['title'] ?? '',
    'type' => $opportunity['type'] ?? 'competition',
    'organization' => $opportunity['organization'] ?? '',
    'description' => $opportunity['description'] ?? '',
    'link' => $opportunity['link'] ?? '',
    'deadline' => $opportunity['deadline'] ?? '',
    'tags' => $opportunity['tags'] ?? '',
    'status' => $opportunity['status'] ?? 'pending',
];

if (is_post()) {
    require_csrf();
    $values = [
        'title' => post('title'),
        'type' => post('type'),
        'organization' => post('organization'),
        'description' => post('description'),
        'link' => post('link'),
        'deadline' => post('deadline'),
        'tags' => post('tags'),
        'status' => post('status', 'pending'),
    ];
    if (mb_strlen($values['title']) < 7 || mb_strlen($values['title']) > 180) {
        $errors['title'] = 'Give the opportunity a title between 7 and 180 characters.';
    }
    if (!isset($types[$values['type']])) {
        $errors['type'] = 'Choose a valid opportunity type.';
    }
    if (mb_strlen($values['organization']) < 2 || mb_strlen($values['organization']) > 180) {
        $errors['organization'] = 'Add the organisation name.';
    }
    if (mb_strlen($values['description']) < 60) {
        $errors['description'] = 'Describe the opportunity in at least 60 characters, including who it is for.';
    }
    if (!valid_url($values['link']) || $values['link'] === '') {
        $errors['link'] = 'Add the official link, starting with http:// or https://.';
    }
    if ($values['deadline'] !== '' && !strtotime($values['deadline'])) {
        $errors['deadline'] = 'Choose a valid deadline date.';
    }
    if (!is_admin()) {
        $values['status'] = 'pending';
    } elseif (!in_array($values['status'], ['pending', 'approved', 'rejected', 'closed'], true)) {
        $errors['status'] = 'Choose a valid status.';
    }
    if (!$errors) {
        $tags = implode(', ', tags_to_array($values['tags'], 8));
        if ($opportunity) {
            db_run(
                'UPDATE opportunities SET title = ?, type = ?, organization = ?, description = ?, link = ?, deadline = ?, tags = ?, status = ? WHERE id = ?',
                [$values['title'], $values['type'], $values['organization'], $values['description'], $values['link'], $values['deadline'] ?: null, $tags ?: null, $values['status'], $id]
            );
            log_activity('opportunity.updated', 'opportunity', $id, $values['title']);
            flash('success', is_admin() ? 'The opportunity was updated.' : 'Your changes were saved and sent for admin review.');
        } else {
            db_run(
                'INSERT INTO opportunities (title, type, organization, description, link, deadline, tags, status, posted_by)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                [$values['title'], $values['type'], $values['organization'], $values['description'], $values['link'], $values['deadline'] ?: null, $tags ?: null, $values['status'], user_id()]
            );
            $id = (int) db()->lastInsertId();
            notify_admins('opportunity', 'A new opportunity is waiting for review: ' . $values['title'] . '.', 'admin/opportunities.php');
            log_activity('opportunity.posted', 'opportunity', $id, $values['title']);
            flash('success', 'The opportunity was saved. ' . (is_admin() ? '' : 'An admin will review it before it is published.'));
        }
        redirect('pages/opportunity-detail.php?id=' . $id);
    }
    flash('danger', 'Please fix the errors below.');
}

$page_title = $opportunity ? 'Edit opportunity' : 'Post an opportunity';
$page_description = 'Add a verified opportunity for members of the Mindset Innovators Hub pilot.';
$breadcrumbs = [['Opportunities', 'pages/opportunities.php'], [$page_title, null]];
require __DIR__ . '/../includes/header.php';
?>
<section class="section-pad-sm section-cream">
  <div class="container">
    <div class="auth-wrap" style="max-width:820px">
      <span class="eyebrow">Opportunity Bridge</span>
      <h1 class="display-6 mt-2"><?= e($page_title) ?></h1>
      <p class="text-muted">Only post opportunities you can point to an official source for. Do not include fees, vague prizes or eligibility claims you cannot support.</p>
    </div>
  </div>
</section>

<section class="section-pad-sm">
  <div class="container">
    <div class="panel panel-body mx-auto" style="max-width:820px">
      <?= error_summary($errors) ?>
      <?php if (!is_admin()): ?><div class="alert alert-info small"><i class="bi bi-shield-check me-1"></i>Partner listings are reviewed by an admin before they appear publicly.</div><?php endif; ?>
      <form method="post" action="<?= e(url('pages/opportunity-form.php' . ($id ? '?id=' . $id : ''))) ?>" class="needs-validation" novalidate data-single-submit>
        <?= csrf_field() ?>
        <?php if ($opportunity): ?><input type="hidden" name="opportunity_id" value="<?= $id ?>"><?php endif; ?>
        <div class="mb-3">
          <label class="form-label" for="title">Opportunity title <span class="text-danger">*</span></label>
          <input class="form-control <?= isset($errors['title']) ? 'is-invalid' : '' ?>" id="title" name="title" maxlength="180" required value="<?= e($values['title']) ?>">
          <?= field_error($errors, 'title') ?>
        </div>
        <div class="row g-3">
          <div class="col-md-4">
            <label class="form-label" for="type">Type</label>
            <select class="form-select" id="type" name="type">
              <?php foreach ($types as $value => $label): ?><option value="<?= e($value) ?>" <?= $values['type'] === $value ? 'selected' : '' ?>><?= e($label) ?></option><?php endforeach; ?>
            </select>
            <?= field_error($errors, 'type') ?>
          </div>
          <div class="col-md-5">
            <label class="form-label" for="organization">Organisation <span class="text-danger">*</span></label>
            <input class="form-control <?= isset($errors['organization']) ? 'is-invalid' : '' ?>" id="organization" name="organization" maxlength="180" required value="<?= e($values['organization']) ?>">
            <?= field_error($errors, 'organization') ?>
          </div>
          <div class="col-md-3">
            <label class="form-label" for="deadline">Deadline</label>
            <input type="date" class="form-control <?= isset($errors['deadline']) ? 'is-invalid' : '' ?>" id="deadline" name="deadline" value="<?= e($values['deadline']) ?>">
            <?= field_error($errors, 'deadline') ?>
          </div>
        </div>
        <div class="mb-3 mt-3">
          <label class="form-label" for="description">Description <span class="text-danger">*</span></label>
          <textarea class="form-control <?= isset($errors['description']) ? 'is-invalid' : '' ?>" id="description" name="description" rows="6" required minlength="60" maxlength="6000" placeholder="Who is it for? What does it involve? What should applicants check before applying?"><?= e($values['description']) ?></textarea>
          <?= field_error($errors, 'description') ?>
        </div>
        <div class="row g-3">
          <div class="col-md-8">
            <label class="form-label" for="link">Official link <span class="text-danger">*</span></label>
            <input type="url" class="form-control <?= isset($errors['link']) ? 'is-invalid' : '' ?>" id="link" name="link" maxlength="500" required value="<?= e($values['link']) ?>" placeholder="https://">
            <?= field_error($errors, 'link') ?>
          </div>
          <div class="col-md-4">
            <label class="form-label" for="tags">Tags</label>
            <input class="form-control" id="tags" name="tags" maxlength="255" value="<?= e($values['tags']) ?>" placeholder="students, remote, funding">
            <div class="form-text">Comma separated, up to eight.</div>
          </div>
        </div>
        <?php if (is_admin()): ?>
          <div class="mt-3">
            <label class="form-label" for="status">Status</label>
            <select class="form-select" id="status" name="status">
              <?php foreach (['pending' => 'Pending review', 'approved' => 'Approved and visible', 'rejected' => 'Rejected', 'closed' => 'Closed'] as $value => $label): ?><option value="<?= e($value) ?>" <?= $values['status'] === $value ? 'selected' : '' ?>><?= e($label) ?></option><?php endforeach; ?>
            </select>
            <?= field_error($errors, 'status') ?>
          </div>
        <?php endif; ?>
        <div class="d-flex gap-2 mt-4">
          <button class="btn btn-gold" type="submit"><?= $opportunity ? 'Save changes' : 'Submit opportunity' ?></button>
          <a class="btn btn-outline-brown" href="<?= e($opportunity ? url('pages/opportunity-detail.php?id=' . $id) : url('pages/opportunities.php')) ?>">Cancel</a>
        </div>
      </form>
    </div>
  </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>

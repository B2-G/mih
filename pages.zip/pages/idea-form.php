<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_login();
if (!is_member() && !is_admin()) {
    forbidden('Only member accounts can share ideas on the board.');
}

$id = get_int('id') ?: (int) post('idea_id');
$idea = $id ? db_one('SELECT * FROM ideas WHERE id = ?', [$id]) : null;
if ($id && !$idea) {
    not_found('That idea could not be found.');
}
if ($idea && (int) $idea['user_id'] !== user_id() && !is_admin()) {
    forbidden('You can only edit your own ideas.');
}

$errors = [];
$values = [
    'title' => $idea['title'] ?? '',
    'problem' => $idea['problem'] ?? '',
    'solution' => $idea['solution'] ?? '',
    'category' => $idea['category'] ?? '',
    'stage' => $idea['stage'] ?? 'Discover',
    'visibility' => $idea['visibility'] ?? 'members',
    'ready_for_matching' => (int) ($idea['ready_for_matching'] ?? 0),
];

if (is_post()) {
    require_csrf();
    $values = [
        'title' => post('title'),
        'problem' => post('problem'),
        'solution' => post('solution'),
        'category' => post('category'),
        'stage' => post('stage'),
        'visibility' => post('visibility'),
        'ready_for_matching' => post('ready_for_matching') === '1' ? 1 : 0,
    ];
    if (mb_strlen($values['title']) < 6 || mb_strlen($values['title']) > 180) {
        $errors['title'] = 'Give the idea a title between 6 and 180 characters.';
    }
    if (mb_strlen($values['problem']) < 30) {
        $errors['problem'] = 'Describe the problem in at least 30 characters.';
    }
    if (mb_strlen($values['solution']) < 20) {
        $errors['solution'] = 'Describe your first idea in at least 20 characters.';
    }
    if (mb_strlen($values['category']) < 2 || mb_strlen($values['category']) > 80) {
        $errors['category'] = 'Add a short category, for example Health or Education.';
    }
    if (!array_key_exists($values['stage'], journey_stages())) {
        $errors['stage'] = 'Choose a valid journey stage.';
    }
    if (!in_array($values['visibility'], ['public', 'members', 'private'], true)) {
        $errors['visibility'] = 'Choose who can see this idea.';
    }
    if (!$errors) {
        if ($idea) {
            db_run(
                'UPDATE ideas SET title = ?, problem = ?, solution = ?, category = ?, stage = ?, visibility = ?, ready_for_matching = ? WHERE id = ?',
                [$values['title'], $values['problem'], $values['solution'], $values['category'], $values['stage'], $values['visibility'], $values['ready_for_matching'], $id]
            );
            log_activity('idea.updated', 'idea', $id, $values['title']);
            flash('success', 'Your idea has been updated.');
        } else {
            db_run(
                'INSERT INTO ideas (user_id, title, problem, solution, category, stage, visibility, ready_for_matching) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                [user_id(), $values['title'], $values['problem'], $values['solution'], $values['category'], $values['stage'], $values['visibility'], $values['ready_for_matching']]
            );
            $id = (int) db()->lastInsertId();
            advance_stage(user_id(), 'Discover');
            log_activity('idea.created', 'idea', $id, $values['title']);
            if ($values['ready_for_matching']) {
                notify_admins('idea', 'A new idea is ready for matching: ' . $values['title'] . '.', 'pages/idea-detail.php?id=' . $id);
            }
            flash('success', 'Your idea is on the board. You can edit it at any time.');
        }
        redirect('pages/idea-detail.php?id=' . $id);
    }
    flash('danger', 'Please fix the errors below.');
}

$page_title = $idea ? 'Edit idea' : 'Share an idea';
$page_description = 'Describe a real problem and the first idea you would test.';
$active = 'explore';
$breadcrumbs = [['Idea Board', 'pages/ideas.php'], [$page_title, null]];
require __DIR__ . '/../includes/header.php';
?>
<section class="section-pad-sm section-cream">
  <div class="container">
    <div class="auth-wrap" style="max-width:820px">
      <span class="eyebrow"><?= $idea ? 'Refine your thinking' : 'Start with a problem' ?></span>
      <h1 class="display-6 mt-2"><?= e($page_title) ?></h1>
      <p class="text-muted">Be specific about who experiences the problem and what you would test first. A rough but honest idea is more useful than a polished pitch.</p>
    </div>
  </div>
</section>

<section class="section-pad-sm">
  <div class="container">
    <div class="panel panel-body mx-auto" style="max-width:820px">
      <?= error_summary($errors) ?>
      <form method="post" action="<?= e(url('pages/idea-form.php' . ($id ? '?id=' . $id : ''))) ?>" class="needs-validation" novalidate data-single-submit>
        <?= csrf_field() ?>
        <?php if ($idea): ?><input type="hidden" name="idea_id" value="<?= $id ?>"><?php endif; ?>
        <div class="mb-3">
          <label class="form-label" for="title">Idea title <span class="text-danger">*</span></label>
          <input class="form-control <?= isset($errors['title']) ? 'is-invalid' : '' ?>" id="title" name="title" maxlength="180" required value="<?= e($values['title']) ?>" placeholder="A short, concrete name">
          <?= field_error($errors, 'title') ?>
        </div>
        <div class="mb-3">
          <label class="form-label" for="problem">What problem does it address? <span class="text-danger">*</span></label>
          <textarea class="form-control <?= isset($errors['problem']) ? 'is-invalid' : '' ?>" id="problem" name="problem" rows="4" required minlength="30" maxlength="4000" data-counter="#problemCounter"><?= e($values['problem']) ?></textarea>
          <div class="form-text" id="problemCounter"></div>
          <?= field_error($errors, 'problem') ?>
        </div>
        <div class="mb-3">
          <label class="form-label" for="solution">Your first idea <span class="text-danger">*</span></label>
          <textarea class="form-control <?= isset($errors['solution']) ? 'is-invalid' : '' ?>" id="solution" name="solution" rows="4" required minlength="20" maxlength="4000" data-counter="#solutionCounter"><?= e($values['solution']) ?></textarea>
          <div class="form-text" id="solutionCounter"></div>
          <?= field_error($errors, 'solution') ?>
        </div>
        <div class="row g-3">
          <div class="col-md-4">
            <label class="form-label" for="category">Category <span class="text-danger">*</span></label>
            <input class="form-control <?= isset($errors['category']) ? 'is-invalid' : '' ?>" id="category" name="category" maxlength="80" required value="<?= e($values['category']) ?>" placeholder="Health, Energy, Education…" list="ideaCategories">
            <datalist id="ideaCategories">
              <?php foreach (['Education', 'Health', 'Environment', 'Agriculture', 'Technology', 'Business', 'Civic tech', 'Energy', 'Creative'] as $cat): ?><option value="<?= e($cat) ?>"></option><?php endforeach; ?>
            </datalist>
            <?= field_error($errors, 'category') ?>
          </div>
          <div class="col-md-4">
            <label class="form-label" for="stage">Journey stage</label>
            <select class="form-select" id="stage" name="stage">
              <?php foreach (array_keys(journey_stages()) as $s): ?><option value="<?= e($s) ?>" <?= $values['stage'] === $s ? 'selected' : '' ?>><?= e($s) ?></option><?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-4">
            <label class="form-label" for="visibility">Who can see it?</label>
            <select class="form-select" id="visibility" name="visibility">
              <option value="public" <?= $values['visibility'] === 'public' ? 'selected' : '' ?>>Everyone</option>
              <option value="members" <?= $values['visibility'] === 'members' ? 'selected' : '' ?>>Signed-in members only</option>
              <option value="private" <?= $values['visibility'] === 'private' ? 'selected' : '' ?>>Only me and admins</option>
            </select>
            <?= field_error($errors, 'visibility') ?>
          </div>
        </div>
        <div class="form-check my-3">
          <input class="form-check-input" type="checkbox" id="ready" name="ready_for_matching" value="1" <?= $values['ready_for_matching'] ? 'checked' : '' ?>>
          <label class="form-check-label" for="ready">I am ready for matching with a mentor or partner</label>
          <div class="form-text">This signals that you welcome a conversation. It does not commit you to anything.</div>
        </div>
        <div class="d-flex gap-2">
          <button class="btn btn-gold" type="submit"><?= $idea ? 'Save changes' : 'Publish idea' ?></button>
          <a class="btn btn-outline-brown" href="<?= e($idea ? url('pages/idea-detail.php?id=' . $id) : url('pages/ideas.php')) ?>">Cancel</a>
        </div>
      </form>
    </div>
  </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>

<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';

$id = get_int('id') ?: (int) post('mentor_id');
$mentor = $id ? db_one(
    "SELECT u.id, u.name, u.username, u.is_demo, u.created_at, p.headline, p.bio, p.location, p.photo,
            p.website, p.linkedin, p.github, mp.expertise, mp.availability, mp.capacity
     FROM users u JOIN mentor_profiles mp ON mp.user_id = u.id LEFT JOIN profiles p ON p.user_id = u.id
     WHERE u.id = ? AND u.role = 'mentor' AND u.status = 'active'",
    [$id]
) : null;
if (!$mentor) {
    not_found('That mentor could not be found.');
}

$uid = user_id();
$errors = [];
$activeMentees = db_count("SELECT COUNT(*) FROM mentor_requests WHERE mentor_id = ? AND status = 'accepted'", [$id]);
$places = max(0, (int) $mentor['capacity'] - $activeMentees);
$myRequest = $uid ? db_one('SELECT * FROM mentor_requests WHERE member_id = ? AND mentor_id = ? ORDER BY created_at DESC LIMIT 1', [$uid, $id]) : null;
$openRequest = $myRequest && in_array($myRequest['status'], ['pending', 'accepted'], true) ? $myRequest : null;

if (is_post()) {
    require_login();
    require_csrf();
    $action = post('action');

    if ($action === 'request') {
        if (!is_member()) {
            flash('warning', 'Only member accounts can request a mentor.');
            redirect('pages/mentor-detail.php?id=' . $id);
        }
        if ($openRequest) {
            flash('info', 'You already have an open request with this mentor.');
            redirect('pages/mentor-detail.php?id=' . $id);
        }
        if ($places < 1) {
            flash('warning', 'This mentor is currently at capacity. You can still explore other mentors.');
            redirect('pages/mentor-detail.php?id=' . $id);
        }
        $message = post('message');
        if (mb_strlen($message) < 20) {
            $errors['message'] = 'Describe what you want help with in at least 20 characters.';
        }
        if (mb_strlen($message) > 2000) {
            $errors['message'] = 'Keep the request under 2,000 characters.';
        }
        if (!$errors) {
            db_run("INSERT INTO mentor_requests (member_id, mentor_id, message, status) VALUES (?, ?, ?, 'pending')", [$uid, $id, $message]);
            $requestId = (int) db()->lastInsertId();
            notify($id, 'mentor_request', current_user()['name'] . ' sent you a mentor request.', 'pages/messages.php?request=' . $requestId);
            log_activity('mentor.requested', 'mentor_request', $requestId, 'Mentor #' . $id);
            flash('success', 'Your request has been sent. You can follow the conversation in Messages.');
            redirect('pages/messages.php?request=' . $requestId);
        }

    } elseif ($action === 'cancel') {
        $requestId = (int) post('request_id');
        $request = db_one('SELECT * FROM mentor_requests WHERE id = ? AND member_id = ? AND mentor_id = ?', [$requestId, $uid, $id]);
        if ($request && $request['status'] === 'pending') {
            db_run("UPDATE mentor_requests SET status = 'declined', responded_at = NOW() WHERE id = ?", [$requestId]);
            notify($id, 'mentor_request', current_user()['name'] . ' cancelled a mentor request.', 'pages/mentor-dashboard.php');
            flash('success', 'The pending request was cancelled.');
        } else {
            flash('warning', 'Only a pending request can be cancelled.');
        }
        redirect('pages/mentor-detail.php?id=' . $id);
    }
}

$skills = db_all('SELECT s.name, us.level FROM user_skills us JOIN skills s ON s.id = us.skill_id WHERE us.user_id = ? ORDER BY s.name', [$id]);
$projects = db_all("SELECT id, title, summary, image, category FROM projects WHERE user_id = ? AND status = 'published' ORDER BY created_at DESC LIMIT 3", [$id]);
$page_title = $mentor['name'];
$page_description = excerpt((string) ($mentor['expertise'] ?? $mentor['headline']), 155);
$breadcrumbs = [['Mentors', 'pages/mentors.php'], [$mentor['name'], null]];
require __DIR__ . '/../includes/header.php';
?>
<section class="section-pad-sm section-cream">
  <div class="container">
    <div class="row g-4 align-items-start">
      <div class="col-lg-8">
        <div class="d-flex flex-wrap gap-2 mb-2">
          <?= demo_badge($mentor['is_demo']) ?>
          <span class="badge <?= $places > 0 ? 'text-bg-success' : 'text-bg-warning' ?>"><?= $places > 0 ? $places . ' place' . ($places === 1 ? '' : 's') . ' available' : 'At capacity' ?></span>
        </div>
        <div class="d-flex align-items-center gap-3 mb-3">
          <?= avatar_html($mentor, $mentor, 'lg') ?>
          <div>
            <h1 class="display-6 mb-0"><?= e($mentor['name']) ?></h1>
            <p class="text-muted mb-0"><?= e($mentor['headline'] ?: 'Mentor in the Mindset Innovators Hub pilot') ?></p>
            <?php if ($mentor['location']): ?><div class="small text-muted"><i class="bi bi-geo-alt me-1"></i><?= e($mentor['location']) ?></div><?php endif; ?>
          </div>
        </div>
        <?php if ($mentor['bio']): ?><p><?= e($mentor['bio']) ?></p><?php endif; ?>
        <div class="panel panel-body mt-4">
          <h2 class="h5">What I can help with</h2>
          <p class="text-muted mb-3" style="white-space:pre-line"><?= e($mentor['expertise']) ?></p>
          <?php if ($mentor['availability']): ?><p class="small mb-0"><i class="bi bi-calendar-week me-1 text-gold"></i><strong>Availability:</strong> <?= e($mentor['availability']) ?></p><?php endif; ?>
        </div>
        <?php if ($skills): ?>
          <div class="panel panel-body mt-3">
            <h2 class="h5">Skills</h2>
            <div><?php foreach ($skills as $skill): ?><span class="skill-chip"><?= e($skill['name']) ?> <span class="level"><?= e($skill['level']) ?></span></span><?php endforeach; ?></div>
          </div>
        <?php endif; ?>
        <?php if ($projects): ?>
          <div class="panel panel-body mt-3">
            <h2 class="h5">Public work</h2>
            <div class="row g-2">
              <?php foreach ($projects as $p): ?>
                <div class="col-md-4"><a class="small text-decoration-none" href="<?= e(url('pages/project-detail.php?id=' . (int) $p['id'])) ?>"><span class="badge badge-tag mb-1"><?= e($p['category']) ?></span><div class="fw-semibold"><?= e($p['title']) ?></div><span class="text-muted"><?= e(excerpt($p['summary'], 70)) ?></span></a></div>
              <?php endforeach; ?>
            </div>
          </div>
        <?php endif; ?>
      </div>

      <aside class="col-lg-4">
        <div class="panel panel-body">
          <div class="small-caps mb-2">Request a conversation</div>
          <?php if (!is_logged_in()): ?>
            <p class="small text-muted">Sign in as a member to send a focused request.</p>
            <a class="btn btn-gold w-100" href="<?= e(url('pages/login.php?next=' . urlencode('pages/mentor-detail.php?id=' . $id))) ?>">Sign in</a>
          <?php elseif ($openRequest): ?>
            <p class="small text-muted mb-2">Your latest request is <?= status_badge($openRequest['status']) ?>.</p>
            <p class="small text-muted">Sent <?= e(format_date($openRequest['created_at'])) ?>. The mentor's response and messages are in your conversation.</p>
            <a class="btn btn-gold w-100" href="<?= e(url('pages/messages.php?request=' . (int) $openRequest['id'])) ?>"><i class="bi bi-chat-dots me-1"></i>Open conversation</a>
            <?php if ($openRequest['status'] === 'pending'): ?>
              <form class="mt-2" method="post" action="<?= e(url('pages/mentor-detail.php?id=' . $id)) ?>" data-confirm="Cancel this pending request?">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="cancel">
                <input type="hidden" name="mentor_id" value="<?= $id ?>">
                <input type="hidden" name="request_id" value="<?= (int) $openRequest['id'] ?>">
                <button class="btn btn-sm btn-outline-brown w-100" type="submit">Cancel request</button>
              </form>
            <?php endif; ?>
          <?php elseif ($myRequest && $myRequest['status'] === 'declined'): ?>
            <p class="small text-muted">Your previous request was not taken forward. You can send a new, shorter request if your need has changed.</p>
            <?php if ($places > 0): ?>
              <form method="post" action="<?= e(url('pages/mentor-detail.php?id=' . $id)) ?>">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="request">
                <input type="hidden" name="mentor_id" value="<?= $id ?>">
                <label class="form-label" for="message">What do you want help with?</label>
                <textarea class="form-control <?= isset($errors['message']) ? 'is-invalid' : '' ?>" id="message" name="message" rows="4" maxlength="2000" required placeholder="Be specific: one decision, one piece of work, one next step."></textarea>
                <?= field_error($errors, 'message') ?>
                <button class="btn btn-gold w-100 mt-2" type="submit">Send request</button>
              </form>
            <?php else: ?><div class="alert alert-warning small mb-0">This mentor is at capacity.</div><?php endif; ?>
          <?php elseif (is_member()): ?>
            <?php if ($places > 0): ?>
              <p class="small text-muted">One clear ask is easier to answer than a general request. Mention the project or decision you are working on.</p>
              <form method="post" action="<?= e(url('pages/mentor-detail.php?id=' . $id)) ?>">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="request">
                <input type="hidden" name="mentor_id" value="<?= $id ?>">
                <label class="form-label" for="message">What do you want help with?</label>
                <textarea class="form-control <?= isset($errors['message']) ? 'is-invalid' : '' ?>" id="message" name="message" rows="4" maxlength="2000" required minlength="20" placeholder="For example: I need help choosing a first user test for my market-finder prototype."></textarea>
                <?= field_error($errors, 'message') ?>
                <button class="btn btn-gold w-100 mt-2" type="submit">Send request</button>
              </form>
            <?php else: ?>
              <div class="alert alert-warning small mb-0">This mentor is at capacity. Try another mentor or check back later.</div>
            <?php endif; ?>
          <?php else: ?>
            <p class="small text-muted mb-0">Mentor requests are for member accounts. You are signed in as a <?= e(user_role()) ?>.</p>
          <?php endif; ?>
          <hr>
          <button class="btn btn-sm btn-outline-brown w-100" type="button" data-copy="<?= e(url('pages/mentor-detail.php?id=' . $id)) ?>"><i class="bi bi-link-45deg me-1"></i>Copy profile link</button>
        </div>
      </aside>
    </div>
  </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>

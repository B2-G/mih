<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';

$id = get_int('id') ?: (int) post('project_id');
if (!$id) {
    not_found('No project was selected.');
}
$project = db_one(
    'SELECT p.*, u.name, u.username, u.is_demo AS owner_demo, u.role AS owner_role, pr.headline, pr.photo
     FROM projects p JOIN users u ON u.id = p.user_id LEFT JOIN profiles pr ON pr.user_id = u.id
     WHERE p.id = ?',
    [$id]
);
if (!$project) {
    not_found('That project could not be found.');
}
$uid = user_id();
$isOwner = $uid > 0 && (int) $project['user_id'] === $uid;
$isAdmin = is_admin();
if ($project['status'] !== 'published' && !$isOwner && !$isAdmin) {
    not_found('That project is not published.');
}

$errors = [];
if (is_post()) {
    require_login();
    require_csrf();
    $action = post('action');

    if ($action === 'feedback') {
        $body = post('feedback');
        if ($isOwner) {
            $errors['feedback'] = 'You cannot leave feedback on your own project.';
        }
        if (mb_strlen($body) < 10) {
            $errors['feedback'] = 'Write at least 10 characters of feedback.';
        }
        if (!array_key_exists('feedback', $errors)) {
            db_run('INSERT INTO project_feedback (project_id, user_id, feedback) VALUES (?, ?, ?)', [$id, $uid, $body]);
            notify((int) $project['user_id'], 'feedback', current_user()['name'] . ' left feedback on your project: ' . $project['title'] . '.', 'pages/project-detail.php?id=' . $id . '#feedback');
            log_activity('project.feedback', 'project', $id, $project['title']);
            flash('success', 'Your feedback was added. Thank you for being specific and constructive.');
            redirect('pages/project-detail.php?id=' . $id . '#feedback');
        }

    } elseif ($action === 'delete_feedback') {
        $feedbackId = (int) post('feedback_id');
        $row = db_one('SELECT * FROM project_feedback WHERE id = ? AND project_id = ?', [$feedbackId, $id]);
        if ($row && ((int) $row['user_id'] === $uid || $isAdmin)) {
            db_run('DELETE FROM project_feedback WHERE id = ?', [$feedbackId]);
            log_activity('project.feedback_deleted', 'project', $id, 'Feedback #' . $feedbackId);
            flash('success', 'The feedback was removed.');
        } else {
            flash('warning', 'You cannot remove that feedback.');
        }
        redirect('pages/project-detail.php?id=' . $id . '#feedback');

    } elseif ($action === 'toggle_status') {
        if (!$isOwner && !$isAdmin) {
            forbidden('Only the owner can change this project.');
        }
        $new = $project['status'] === 'published' ? 'draft' : 'published';
        db_run('UPDATE projects SET status = ? WHERE id = ?', [$new, $id]);
        if ($new === 'published') {
            advance_stage((int) $project['user_id'], 'Showcase');
            refresh_badges((int) $project['user_id']);
        }
        log_activity('project.status', 'project', $id, $new);
        flash('success', $new === 'published' ? 'The project is now visible on the showcase.' : 'The project has been moved back to draft.');
        redirect('pages/project-detail.php?id=' . $id);
    }
}

$feedback = db_all(
    'SELECT f.*, u.name, u.username, u.is_demo, u.role, pr.photo FROM project_feedback f
     JOIN users u ON u.id = f.user_id LEFT JOIN profiles pr ON pr.user_id = u.id
     WHERE f.project_id = ? ORDER BY f.created_at ASC',
    [$id]
);
$collaborators = db_all('SELECT * FROM project_members WHERE project_id = ? ORDER BY id', [$id]);
$owner = ['name' => $project['name'], 'headline' => $project['headline'], 'photo' => $project['photo']];

$page_title = $project['title'];
$page_description = excerpt($project['summary'], 155);
$active = 'explore';
$breadcrumbs = [['Showcase', 'pages/showcase.php'], [$project['title'], null]];
require __DIR__ . '/../includes/header.php';
?>
<section class="section-pad-sm section-cream">
  <div class="container">
    <div class="row g-4 align-items-start">
      <div class="col-lg-8">
        <div class="d-flex flex-wrap gap-2 mb-2">
          <span class="badge badge-stage"><?= e($project['category']) ?></span>
          <?= status_badge($project['status']) ?>
          <?= demo_badge($project['is_demo']) ?>
        </div>
        <h1 class="display-5 mt-2 mb-2"><?= e($project['title']) ?></h1>
        <p class="lead"><?= e($project['summary']) ?></p>
        <div class="meta-row mb-3">
          <span><i class="bi bi-person me-1"></i><a href="<?= e(url('pages/portfolio.php?u=' . urlencode($project['username']))) ?>"><?= e($project['name']) ?></a></span>
          <span><i class="bi bi-calendar3 me-1"></i><?= e(format_date($project['created_at'], 'M Y')) ?></span>
          <?php if ($feedback): ?><span><i class="bi bi-chat me-1"></i><?= count($feedback) ?> feedback note<?= count($feedback) === 1 ? '' : 's' ?></span><?php endif; ?>
        </div>
        <?php if ($project['image']): ?><img class="img-fluid rounded-3 mb-4 w-100" style="max-height:360px;object-fit:cover" src="<?= e(url($project['image'])) ?>" alt="Cover image for <?= e($project['title']) ?>"><?php endif; ?>
      </div>
      <div class="col-lg-4">
        <div class="panel panel-body">
          <div class="d-flex align-items-center gap-2 mb-2">
            <?= avatar_html($owner, $owner, 'sm') ?>
            <div>
              <a class="fw-semibold text-decoration-none" href="<?= e(url('pages/portfolio.php?u=' . urlencode($project['username']))) ?>"><?= e($project['name']) ?></a>
              <div class="small text-muted"><?= e(role_label($project['owner_role'])) ?> <?= demo_badge($project['owner_demo']) ?></div>
            </div>
          </div>
          <?php if ($project['repo_link'] || $project['demo_link']): ?>
            <div class="d-grid gap-2 mb-2">
              <?php if ($project['demo_link']): ?><a class="btn btn-gold" href="<?= e($project['demo_link']) ?>" target="_blank" rel="noopener noreferrer nofollow"><i class="bi bi-box-arrow-up-right me-1"></i>Open live demo</a><?php endif; ?>
              <?php if ($project['repo_link']): ?><a class="btn btn-outline-brown" href="<?= e($project['repo_link']) ?>" target="_blank" rel="noopener noreferrer nofollow"><i class="bi bi-code-slash me-1"></i>View repository</a><?php endif; ?>
            </div>
          <?php endif; ?>
          <button class="btn btn-sm btn-outline-brown w-100" type="button" data-copy="<?= e(url('pages/project-detail.php?id=' . $id)) ?>"><i class="bi bi-link-45deg me-1"></i>Copy project link</button>
          <?php if ($isOwner || $isAdmin): ?>
            <hr>
            <a class="btn btn-sm btn-outline-brown w-100 mb-2" href="<?= e(url('pages/project-form.php?id=' . $id)) ?>"><i class="bi bi-pencil me-1"></i>Edit project</a>
            <form method="post" action="<?= e(url('pages/project-detail.php?id=' . $id)) ?>">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="toggle_status">
              <button class="btn btn-sm <?= $project['status'] === 'published' ? 'btn-outline-brown' : 'btn-gold' ?> w-100" type="submit"><?= $project['status'] === 'published' ? 'Move to draft' : 'Publish project' ?></button>
            </form>
          <?php endif; ?>
          <hr>
          <a class="small" href="<?= e(url('pages/portfolio.php?u=' . urlencode($project['username']))) ?>">See the full portfolio <i class="bi bi-arrow-right"></i></a>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="section-pad-sm">
  <div class="container">
    <?= error_summary($errors) ?>
    <div class="row g-4">
      <div class="col-lg-8">
        <div class="panel panel-body mb-4">
          <h2 class="h5">About this project</h2>
          <div class="text-muted" style="white-space:pre-line"><?= e($project['description']) ?></div>
          <?php if ($project['skills_used']): ?>
            <h3 class="h6 mt-4">Skills used</h3>
            <div><?php foreach (tags_to_array($project['skills_used']) as $skill): ?><span class="skill-chip"><?= e($skill) ?></span><?php endforeach; ?></div>
          <?php endif; ?>
          <?php if ($collaborators): ?>
            <h3 class="h6 mt-4">Collaborators</h3>
            <ul class="small text-muted mb-0">
              <?php foreach ($collaborators as $c): ?>
                <li><?php if ($c['user_id']): ?><a href="<?= e(url('pages/profile.php?u=' . urlencode(user_username((int) $c['user_id'])))) ?>"><?= e($c['name']) ?></a><?php else: ?><?= e($c['name']) ?><?php endif; ?><?= $c['role'] ? ' — ' . e($c['role']) : '' ?></li>
              <?php endforeach; ?>
            </ul>
          <?php endif; ?>
        </div>

        <div class="panel panel-body" id="feedback">
          <div class="d-flex justify-content-between align-items-center mb-2">
            <h2 class="h5 mb-0">Feedback</h2>
            <span class="badge badge-soft"><?= count($feedback) ?></span>
          </div>
          <p class="small text-muted">Feedback should be specific, respectful and useful. Say what works and what could be clearer.</p>
          <?php if (!$feedback): ?><p class="small text-muted">No feedback yet.</p><?php endif; ?>
          <?php foreach ($feedback as $f): ?>
            <div class="d-flex gap-3 border-bottom py-3">
              <?= avatar_html($f, $f, 'sm') ?>
              <div class="flex-grow-1">
                <div class="d-flex justify-content-between gap-2">
                  <div class="small"><a class="fw-semibold text-decoration-none" href="<?= e(url('pages/profile.php?u=' . urlencode($f['username']))) ?>"><?= e($f['name']) ?></a> <span class="badge badge-tag"><?= e(role_label($f['role'])) ?></span> <?= demo_badge($f['is_demo']) ?> <span class="text-muted">· <?= e(time_ago($f['created_at'])) ?></span></div>
                  <?php if ($uid && ((int) $f['user_id'] === $uid || $isAdmin)): ?>
                    <form method="post" action="<?= e(url('pages/project-detail.php?id=' . $id . '#feedback')) ?>" data-confirm="Remove this feedback?">
                      <?= csrf_field() ?>
                      <input type="hidden" name="action" value="delete_feedback">
                      <input type="hidden" name="feedback_id" value="<?= (int) $f['id'] ?>">
                      <button class="btn btn-link btn-sm p-0 text-muted" type="submit">Remove</button>
                    </form>
                  <?php endif; ?>
                </div>
                <p class="small mb-0 mt-1" style="white-space:pre-line"><?= e($f['feedback']) ?></p>
              </div>
            </div>
          <?php endforeach; ?>

          <?php if (!is_logged_in()): ?>
            <div class="alert alert-info mt-3 mb-0 small"><a href="<?= e(url('pages/login.php?next=' . urlencode('pages/project-detail.php?id=' . $id . '#feedback'))) ?>">Sign in</a> to leave constructive feedback.</div>
          <?php elseif ($isOwner): ?>
            <div class="alert alert-info mt-3 mb-0 small">This is your project. Feedback from others appears here and in your notifications.</div>
          <?php else: ?>
            <form class="mt-3" method="post" action="<?= e(url('pages/project-detail.php?id=' . $id . '#feedback')) ?>">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="feedback">
              <label class="form-label" for="feedback-body">Your feedback</label>
              <textarea class="form-control <?= isset($errors['feedback']) ? 'is-invalid' : '' ?>" id="feedback-body" name="feedback" rows="3" maxlength="2000" required placeholder="What is clear? What would you test next?"></textarea>
              <?= field_error($errors, 'feedback') ?>
              <button class="btn btn-brown mt-2" type="submit">Add feedback</button>
            </form>
          <?php endif; ?>
        </div>
      </div>
      <aside class="col-lg-4">
        <div class="panel panel-body">
          <div class="small-caps mb-2">Project snapshot</div>
          <ul class="list-clean small">
            <li class="d-flex justify-content-between"><span>Category</span><strong><?= e($project['category']) ?></strong></li>
            <li class="d-flex justify-content-between"><span>Created</span><strong><?= e(format_date($project['created_at'])) ?></strong></li>
            <li class="d-flex justify-content-between"><span>Last updated</span><strong><?= e(format_date($project['updated_at'])) ?></strong></li>
            <li class="d-flex justify-content-between"><span>Feedback</span><strong><?= count($feedback) ?></strong></li>
          </ul>
        </div>
      </aside>
    </div>
  </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>

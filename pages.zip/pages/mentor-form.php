<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_role(['mentor', 'admin']);

$targetId = user_id();
if (is_admin() && get_int('id')) {
    $targetId = get_int('id');
}
$target = db_one("SELECT id, name, role FROM users WHERE id = ? AND role = 'mentor'", [$targetId]);
if (!$target) {
    not_found('That mentor account could not be found.');
}
$profile = db_one('SELECT * FROM mentor_profiles WHERE user_id = ?', [$targetId]);
$errors = [];
$values = [
    'expertise' => $profile['expertise'] ?? '',
    'availability' => $profile['availability'] ?? '',
    'capacity' => (string) ($profile['capacity'] ?? '2'),
];

if (is_post()) {
    require_csrf();
    $values = [
        'expertise' => post('expertise'),
        'availability' => post('availability'),
        'capacity' => post('capacity'),
    ];
    if (mb_strlen($values['expertise']) < 20) {
        $errors['expertise'] = 'Describe your expertise in at least 20 characters.';
    }
    if (mb_strlen($values['availability']) > 160) {
        $errors['availability'] = 'Keep availability under 160 characters.';
    }
    if (!ctype_digit($values['capacity']) || (int) $values['capacity'] < 0 || (int) $values['capacity'] > 10) {
        $errors['capacity'] = 'Choose a capacity between 0 and 10 active mentees.';
    }
    if (!$errors) {
        if ($profile) {
            db_run('UPDATE mentor_profiles SET expertise = ?, availability = ?, capacity = ? WHERE user_id = ?', [$values['expertise'], $values['availability'] ?: null, (int) $values['capacity'], $targetId]);
        } else {
            db_run('INSERT INTO mentor_profiles (user_id, expertise, availability, capacity) VALUES (?, ?, ?, ?)', [$targetId, $values['expertise'], $values['availability'] ?: null, (int) $values['capacity']]);
        }
        advance_stage($targetId, 'Advance');
        log_activity('mentor.profile_updated', 'mentor', $targetId);
        flash('success', 'Your mentor profile has been saved.');
        redirect('pages/mentor-detail.php?id=' . $targetId);
    }
}

$page_title = $profile ? 'Edit mentor profile' : 'Become a mentor';
$page_description = 'Describe the experience you can share and how many mentees you can support.';
$breadcrumbs = [['Mentors', 'pages/mentors.php'], [$page_title, null]];
require __DIR__ . '/../includes/header.php';
?>
<section class="section-pad-sm section-cream">
  <div class="container">
    <div class="auth-wrap">
      <span class="eyebrow">Offer practical guidance</span>
      <h1 class="display-6 mt-2"><?= e($page_title) ?></h1>
      <p class="text-muted">Be specific about what you can help with and honest about your availability. A focused offer is easier to respond to than "any help".</p>
    </div>
  </div>
</section>

<section class="section-pad-sm">
  <div class="container">
    <div class="panel panel-body auth-wrap">
      <?= error_summary($errors) ?>
      <form method="post" action="<?= e(url('pages/mentor-form.php' . (is_admin() && $targetId !== user_id() ? '?id=' . $targetId : ''))) ?>" class="needs-validation" novalidate data-single-submit>
        <?= csrf_field() ?>
        <div class="mb-3">
          <label class="form-label" for="expertise">What can you help with? <span class="text-danger">*</span></label>
          <textarea class="form-control <?= isset($errors['expertise']) ? 'is-invalid' : '' ?>" id="expertise" name="expertise" rows="4" required minlength="20" maxlength="1000" placeholder="For example: product thinking, user research, PHP and accessible web design."><?= e($values['expertise']) ?></textarea>
          <?= field_error($errors, 'expertise') ?>
          <div class="form-text">Your own limits matter too: say what you can and cannot support.</div>
        </div>
        <div class="mb-3">
          <label class="form-label" for="availability">Availability</label>
          <input class="form-control <?= isset($errors['availability']) ? 'is-invalid' : '' ?>" id="availability" name="availability" maxlength="160" value="<?= e($values['availability']) ?>" placeholder="For example: Tuesdays 5–7pm WAT, one call per month">
          <?= field_error($errors, 'availability') ?>
        </div>
        <div class="mb-3">
          <label class="form-label" for="capacity">Active mentee capacity</label>
          <input type="number" class="form-control <?= isset($errors['capacity']) ? 'is-invalid' : '' ?>" id="capacity" name="capacity" min="0" max="10" required value="<?= e($values['capacity']) ?>">
          <div class="form-text">This is a self-set limit. The prototype warns members when you are at capacity; it does not enforce a waitlist automatically.</div>
          <?= field_error($errors, 'capacity') ?>
        </div>
        <div class="alert alert-info small">
          <i class="bi bi-shield-check me-1"></i>Mentoring here is voluntary and bounded. Do not ask members for money, personal documents or private contact details. If a conversation needs a different kind of support, direct the member to a trusted adult or local service.
        </div>
        <button class="btn btn-gold" type="submit">Save mentor profile</button>
        <a class="btn btn-outline-brown" href="<?= e(url('pages/mentor-detail.php?id=' . $targetId)) ?>">Cancel</a>
      </form>
    </div>
  </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>

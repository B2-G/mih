<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_login();

$me = current_user();
$profile = db_one('SELECT * FROM profiles WHERE user_id = ?', [user_id()]);
if (!$profile) {
    db_run('INSERT INTO profiles (user_id) VALUES (?)', [user_id()]);
    $profile = db_one('SELECT * FROM profiles WHERE user_id = ?', [user_id()]);
}

$page_title = 'Edit profile';
$page_description = 'Edit your Mindset Innovators Hub profile, skills, privacy and journey stage.';
$breadcrumbs = [['My profile', 'pages/profile.php'], ['Edit', null]];

$allSkills = db_all('SELECT * FROM skills ORDER BY name');
$userSkillRows = db_all('SELECT skill_id, level FROM user_skills WHERE user_id = ?', [user_id()]);
$userSkillLevels = [];
foreach ($userSkillRows as $row) {
    $userSkillLevels[(int) $row['skill_id']] = $row['level'];
}

$errors = [];
$form = [
    'headline' => $profile['headline'] ?? '',
    'bio' => $profile['bio'] ?? '',
    'location' => $profile['location'] ?? '',
    'interests' => $profile['interests'] ?? '',
    'goals' => $profile['goals'] ?? '',
    'website' => $profile['website'] ?? '',
    'linkedin' => $profile['linkedin'] ?? '',
    'github' => $profile['github'] ?? '',
    'journey_stage' => $profile['journey_stage'] ?? 'Discover',
    'privacy' => $profile['privacy'] ?? 'members',
];

if (is_post()) {
    require_csrf();
    foreach ($form as $key => $_) {
        $form[$key] = post($key, is_string($_) ? $_ : '');
    }
    if (mb_strlen($form['headline']) > 160) {
        $errors['headline'] = 'Keep your headline to 160 characters or fewer.';
    }
    if (mb_strlen($form['bio']) > 5000) {
        $errors['bio'] = 'Keep your bio to 5,000 characters or fewer.';
    }
    if (mb_strlen($form['location']) > 120) {
        $errors['location'] = 'Keep your location to 120 characters or fewer.';
    }
    if (mb_strlen($form['interests']) > 500) {
        $errors['interests'] = 'Please use 500 characters or fewer for interests.';
    }
    if (mb_strlen($form['goals']) > 2000) {
        $errors['goals'] = 'Keep your goals to 2,000 characters or fewer.';
    }
    foreach (['website' => 'Website', 'linkedin' => 'LinkedIn', 'github' => 'GitHub'] as $field => $label) {
        if ($form[$field] !== '' && !valid_url($form[$field])) {
            $errors[$field] = $label . ' must be a full http:// or https:// link.';
        }
    }
    if (!in_array($form['journey_stage'], array_keys(journey_stages()), true)) {
        $errors['journey_stage'] = 'Choose a valid stage.';
    }
    if (!in_array($form['privacy'], ['public', 'members', 'private'], true)) {
        $errors['privacy'] = 'Choose a valid privacy option.';
    }

    $photoPath = $profile['photo'];
    if (!$errors) {
        try {
            $uploaded = save_upload('photo', 'image', 'profiles');
            if ($uploaded) {
                $photoPath = $uploaded;
            }
        } catch (RuntimeException $ex) {
            $errors['photo'] = $ex->getMessage();
        }
    }
    if (isset($_POST['remove_photo']) && !$errors) {
        remove_upload($profile['photo']);
        $photoPath = null;
    }

    $newSkillNames = tags_to_array(post('new_skills'), 10);

    if (!$errors) {
        try {
            db()->beginTransaction();
            db_run(
                'UPDATE profiles SET photo = ?, headline = ?, bio = ?, location = ?, interests = ?, goals = ?,
                        website = ?, linkedin = ?, github = ?, journey_stage = ?, privacy = ? WHERE user_id = ?',
                [
                    $photoPath, $form['headline'] ?: null, $form['bio'] ?: null, $form['location'] ?: null,
                    $form['interests'] ?: null, $form['goals'] ?: null, $form['website'] ?: null,
                    $form['linkedin'] ?: null, $form['github'] ?: null, $form['journey_stage'], $form['privacy'], user_id(),
                ]
            );

            $levels = $_POST['skill_levels'] ?? [];
            $keep = [];
            if (is_array($levels)) {
                foreach ($levels as $sid => $level) {
                    $sid = (int) $sid;
                    if (!in_array($level, ['Beginner', 'Intermediate', 'Advanced'], true)) {
                        $level = 'Beginner';
                    }
                    if (db_count('SELECT COUNT(*) FROM skills WHERE id = ?', [$sid])) {
                        $keep[] = $sid;
                        db_run(
                            'INSERT INTO user_skills (user_id, skill_id, level) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE level = VALUES(level)',
                            [user_id(), $sid, $level]
                        );
                    }
                }
            }
            if ($keep) {
                $placeholders = implode(',', array_fill(0, count($keep), '?'));
                db_run('DELETE FROM user_skills WHERE user_id = ? AND skill_id NOT IN (' . $placeholders . ')', array_merge([user_id()], $keep));
            } else {
                db_run('DELETE FROM user_skills WHERE user_id = ?', [user_id()]);
            }
            foreach ($newSkillNames as $name) {
                db_run('INSERT INTO skills (name) VALUES (?) ON DUPLICATE KEY UPDATE name = VALUES(name)', [$name]);
                $s = db_one('SELECT id FROM skills WHERE name = ?', [$name]);
                if ($s) {
                    db_run('INSERT INTO user_skills (user_id, skill_id, level) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE level = VALUES(level)', [user_id(), (int) $s['id'], 'Beginner']);
                }
            }
            db()->commit();
            if ($profile['photo'] && $photoPath !== $profile['photo']) {
                remove_upload($profile['photo']);
            }
            refresh_badges(user_id());
            log_activity('profile.updated', 'profile', user_id(), $form['journey_stage']);
            flash('success', 'Your profile has been updated.');
            redirect('pages/profile-edit.php');
        } catch (Throwable $ex) {
            if (db()->inTransaction()) {
                db()->rollBack();
            }
            if ($photoPath && $photoPath !== $profile['photo']) {
                remove_upload($photoPath);
            }
            $errors['form'] = APP_DEBUG ? $ex->getMessage() : 'Could not save the profile. Please try again.';
        }
    }
}

$fresh = db_one('SELECT * FROM profiles WHERE user_id = ?', [user_id()]);
$freshSkills = db_all('SELECT skill_id FROM user_skills WHERE user_id = ?', [user_id()]);
$freshSkillIds = array_map(static fn($r) => (int) $r['skill_id'], $freshSkills);
$selectedLevels = $userSkillLevels;
if (is_post() && !empty($_POST['skill_levels']) && is_array($_POST['skill_levels'])) {
    $selectedLevels = array_map('strval', $_POST['skill_levels']);
}
[$completeness, $missing] = profile_completeness(user_id());

require __DIR__ . '/../includes/header.php';
?>
<section class="section-pad-sm section-cream">
  <div class="container">
    <div class="d-flex flex-wrap justify-content-between align-items-end gap-3">
      <div>
        <span class="eyebrow">Potential profile</span>
        <h1 class="display-5 mt-2 mb-1">Edit your profile</h1>
        <p class="text-muted mb-0">Your profile is the public face of your potential. Keep it honest and specific.</p>
      </div>
      <a class="btn btn-outline-brown" href="<?= e(url('pages/profile.php')) ?>"><i class="bi bi-eye me-1"></i>View profile</a>
    </div>
  </div>
</section>

<section class="section-pad">
  <div class="container">
    <?= error_summary($errors) ?>
    <?php if (!empty($errors['form'])): ?><div class="alert alert-danger"><?= e($errors['form']) ?></div><?php endif; ?>
    <div class="row g-4">
      <div class="col-lg-8">
        <div class="panel panel-body">
          <form method="post" action="<?= e(url('pages/profile-edit.php')) ?>" enctype="multipart/form-data" class="needs-validation" novalidate data-single-submit>
            <?= csrf_field() ?>

            <h2 class="h5 mb-3"><i class="bi bi-person me-2 text-gold"></i>About you</h2>
            <div class="row g-3">
              <div class="col-md-7">
                <label class="form-label" for="headline">Headline</label>
                <input class="form-control <?= isset($errors['headline']) ? 'is-invalid' : '' ?>" id="headline" name="headline" maxlength="160" value="<?= e($form['headline']) ?>" placeholder="For example: Product designer exploring civic technology">
                <?= field_error($errors, 'headline') ?>
              </div>
              <div class="col-md-5">
                <label class="form-label" for="location">Location</label>
                <input class="form-control <?= isset($errors['location']) ? 'is-invalid' : '' ?>" id="location" name="location" maxlength="120" value="<?= e($form['location']) ?>" placeholder="City, Country">
                <?= field_error($errors, 'location') ?>
              </div>
              <div class="col-12">
                <label class="form-label" for="bio">Short bio</label>
                <textarea class="form-control <?= isset($errors['bio']) ? 'is-invalid' : '' ?>" id="bio" name="bio" rows="5" maxlength="5000" data-counter="#bioCount"><?= e($form['bio']) ?></textarea>
                <div class="form-text text-end" id="bioCount"></div>
                <?= field_error($errors, 'bio') ?>
              </div>
              <div class="col-12">
                <label class="form-label" for="interests">Interests</label>
                <input class="form-control <?= isset($errors['interests']) ? 'is-invalid' : '' ?>" id="interests" name="interests" maxlength="500" value="<?= e($form['interests']) ?>" placeholder="Civic tech, Design, Local markets">
                <div class="form-text">Separate interests with commas. They power the member directory filters.</div>
                <?= field_error($errors, 'interests') ?>
              </div>
              <div class="col-12">
                <label class="form-label" for="goals">Goals</label>
                <textarea class="form-control <?= isset($errors['goals']) ? 'is-invalid' : '' ?>" id="goals" name="goals" rows="3" maxlength="2000"><?= e($form['goals']) ?></textarea>
                <?= field_error($errors, 'goals') ?>
              </div>
            </div>

            <hr class="my-4">
            <h2 class="h5 mb-1"><i class="bi bi-tools me-2 text-gold"></i>Skills you are practising</h2>
            <p class="small text-muted mb-3">Select a skill and choose your current level. This is self-reported, so be honest; it is not a certificate.</p>
            <div class="row g-2">
              <?php foreach ($allSkills as $skill): $sid = (int) $skill['id']; $checked = isset($selectedLevels[$sid]); ?>
                <div class="col-md-6">
                  <div class="d-flex align-items-center gap-2 border rounded-3 p-2" style="border-color:var(--mi-line) !important">
                    <input class="form-check-input mt-0" type="checkbox" id="skill_<?= $sid ?>" data-skill-toggle="<?= $sid ?>" <?= $checked ? 'checked' : '' ?>>
                    <label class="form-check-label small flex-grow-1" for="skill_<?= $sid ?>"><?= e($skill['name']) ?></label>
                    <select class="form-select form-select-sm" name="skill_levels[<?= $sid ?>]" aria-label="Level for <?= e($skill['name']) ?>" <?= $checked ? '' : 'disabled' ?> data-skill-level="<?= $sid ?>" style="width:130px">
                      <?php foreach (['Beginner', 'Intermediate', 'Advanced'] as $level): ?>
                        <option value="<?= e($level) ?>" <?= (($selectedLevels[$sid] ?? 'Beginner') === $level) ? 'selected' : '' ?>><?= e($level) ?></option>
                      <?php endforeach; ?>
                    </select>
                  </div>
                </div>
              <?php endforeach; ?>
            </div>
            <div class="mt-3">
              <label class="form-label" for="new_skills">Add a skill not in the list</label>
              <input class="form-control" id="new_skills" name="new_skills" maxlength="400" placeholder="For example: Public speaking, Carpentry, Community facilitation">
              <div class="form-text">Comma separated. New skills are added as Beginner; adjust the level after saving if needed.</div>
            </div>

            <hr class="my-4">
            <h2 class="h5 mb-3"><i class="bi bi-link-45deg me-2 text-gold"></i>Links</h2>
            <div class="row g-3">
              <div class="col-md-4">
                <label class="form-label" for="website">Website</label>
                <input type="url" class="form-control <?= isset($errors['website']) ? 'is-invalid' : '' ?>" id="website" name="website" maxlength="255" value="<?= e($form['website']) ?>" placeholder="https://">
                <?= field_error($errors, 'website') ?>
              </div>
              <div class="col-md-4">
                <label class="form-label" for="linkedin">LinkedIn</label>
                <input type="url" class="form-control <?= isset($errors['linkedin']) ? 'is-invalid' : '' ?>" id="linkedin" name="linkedin" maxlength="255" value="<?= e($form['linkedin']) ?>" placeholder="https://linkedin.com/in/">
                <?= field_error($errors, 'linkedin') ?>
              </div>
              <div class="col-md-4">
                <label class="form-label" for="github">GitHub</label>
                <input type="url" class="form-control <?= isset($errors['github']) ? 'is-invalid' : '' ?>" id="github" name="github" maxlength="255" value="<?= e($form['github']) ?>" placeholder="https://github.com/">
                <?= field_error($errors, 'github') ?>
              </div>
            </div>

            <hr class="my-4">
            <h2 class="h5 mb-3"><i class="bi bi-signpost-split me-2 text-gold"></i>Journey and privacy</h2>
            <div class="row g-3">
              <div class="col-md-6">
                <label class="form-label" for="journey_stage">Current journey stage</label>
                <select class="form-select" id="journey_stage" name="journey_stage">
                  <?php foreach (journey_stages() as $stage => $desc): ?>
                    <option value="<?= e($stage) ?>" <?= $form['journey_stage'] === $stage ? 'selected' : '' ?>><?= e($stage) ?> — <?= e($desc) ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="col-md-6">
                <label class="form-label" for="privacy">Profile visibility</label>
                <select class="form-select" id="privacy" name="privacy">
                  <option value="public" <?= $form['privacy'] === 'public' ? 'selected' : '' ?>>Public — anyone with the link</option>
                  <option value="members" <?= $form['privacy'] === 'members' ? 'selected' : '' ?>>Members only — signed-in members</option>
                  <option value="private" <?= $form['privacy'] === 'private' ? 'selected' : '' ?>>Private — only me and admins</option>
                </select>
                <div class="form-text">Your portfolio project visibility is controlled separately.</div>
              </div>
              <div class="col-12">
                <label class="form-label" for="photo">Profile photo</label>
                <input type="file" class="form-control <?= isset($errors['photo']) ? 'is-invalid' : '' ?>" id="photo" name="photo" accept="image/jpeg,image/png,image/webp" data-preview="#photoPreview">
                <div class="form-text">JPG, PNG or WebP, up to 3 MB. A square image works best.</div>
                <?= field_error($errors, 'photo') ?>
                <div id="photoPreview" class="mt-2"></div>
                <?php if (!empty($profile['photo'])): ?>
                  <div class="form-check mt-2">
                    <input class="form-check-input" type="checkbox" id="remove_photo" name="remove_photo">
                    <label class="form-check-label small" for="remove_photo">Remove my current photo</label>
                  </div>
                <?php endif; ?>
              </div>
            </div>

            <div class="d-flex flex-wrap gap-2 mt-4">
              <button class="btn btn-gold" type="submit">Save profile</button>
              <a class="btn btn-outline-brown" href="<?= e(url('pages/profile.php')) ?>">Cancel</a>
            </div>
          </form>
        </div>
      </div>

      <div class="col-lg-4">
        <div class="panel panel-body mb-3">
          <div class="d-flex align-items-center gap-3 mb-3">
            <?= avatar_html($me, $profile, 'lg') ?>
            <div>
              <div class="h6 mb-0"><?= e($me['name']) ?></div>
              <div class="small text-muted">@<?= e($me['username']) ?></div>
            </div>
          </div>
          <div class="d-flex justify-content-between small mb-1"><span>Profile completeness</span><strong><?= $completeness ?>%</strong></div>
          <div class="completeness"><span style="width:<?= $completeness ?>%"></span></div>
          <?php if ($missing): ?>
            <p class="small text-muted mt-2 mb-0">Still to add: <?= e(implode(', ', $missing)) ?>.</p>
          <?php else: ?>
            <p class="small text-success mt-2 mb-0"><i class="bi bi-check2-circle me-1"></i>Everything is filled in. Nice.</p>
          <?php endif; ?>
        </div>
        <div class="panel panel-body mb-3">
          <div class="small-caps mb-2">Your journey</div>
          <?= journey_tracker($fresh['journey_stage'] ?? 'Discover') ?>
          <div class="small text-muted mt-2"><?= e(journey_stages()[$fresh['journey_stage'] ?? 'Discover']) ?></div>
        </div>
        <div class="panel panel-body">
          <div class="small-caps mb-2">Why this matters</div>
          <p class="small text-muted mb-2">A complete profile helps mentors understand your context and helps teammates find you in the directory.</p>
          <a class="small" href="<?= e(url('pages/portfolio.php')) ?>">Open my portfolio <i class="bi bi-arrow-right"></i></a>
        </div>
      </div>
    </div>
  </div>
</section>
<?php
$page_scripts = <<<'JS'
<script>
document.querySelectorAll('[data-skill-toggle]').forEach(function(cb){
  cb.addEventListener('change', function(){
    var sel = document.querySelector('[data-skill-level="' + cb.getAttribute('data-skill-toggle') + '"]');
    if (sel) { sel.disabled = !cb.checked; }
  });
});
</script>
JS;
require __DIR__ . '/../includes/footer.php';
?>

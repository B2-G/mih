<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_login();

$page_title = 'Member Directory';
$page_description = 'Search and filter young innovators in the Mindset Innovators Hub pilot by skill, interest, location and journey stage.';
$breadcrumbs = [['Member directory', null]];

$q = get('q');
$skillId = get_int('skill');
$interest = get('interest');
$location = get('location');
$stage = get('stage');
$page = current_page_number();
$perPage = 12;

$where = ["u.role = 'member'", "u.status = 'active'", "p.privacy <> 'private'"];
$params = [];
if ($q !== '') {
    $where[] = '(u.name LIKE ? OR p.headline LIKE ? OR p.bio LIKE ? OR p.interests LIKE ? OR p.location LIKE ?)';
    $like = '%' . $q . '%';
    array_push($params, $like, $like, $like, $like, $like);
}
if ($skillId > 0) {
    $where[] = 'EXISTS (SELECT 1 FROM user_skills us WHERE us.user_id = u.id AND us.skill_id = ?)';
    $params[] = $skillId;
}
if ($interest !== '') {
    $where[] = 'p.interests LIKE ?';
    $params[] = '%' . $interest . '%';
}
if ($location !== '') {
    $where[] = 'p.location LIKE ?';
    $params[] = '%' . $location . '%';
}
if ($stage !== '' && array_key_exists($stage, journey_stages())) {
    $where[] = 'p.journey_stage = ?';
    $params[] = $stage;
}
$whereSql = implode(' AND ', $where);
$total = db_count("SELECT COUNT(*) FROM users u JOIN profiles p ON p.user_id = u.id WHERE $whereSql", $params);
$pages = max(1, (int) ceil($total / $perPage));
$page = min($page, $pages);
$offset = ($page - 1) * $perPage;

$members = db_all(
    "SELECT u.id, u.name, u.username, u.is_demo, p.photo, p.headline, p.location, p.interests, p.journey_stage
     FROM users u JOIN profiles p ON p.user_id = u.id
     WHERE $whereSql ORDER BY p.updated_at DESC, u.name ASC
     LIMIT $perPage OFFSET $offset",
    $params
);

$skillsByUser = [];
if ($members) {
    $ids = array_map(static fn($m) => (int) $m['id'], $members);
    $ph = implode(',', array_fill(0, count($ids), '?'));
    $rows = db_all(
        "SELECT us.user_id, s.name, us.level FROM user_skills us JOIN skills s ON s.id = us.skill_id
         WHERE us.user_id IN ($ph) ORDER BY s.name",
        $ids
    );
    foreach ($rows as $r) {
        $skillsByUser[(int) $r['user_id']][] = $r;
    }
}
$allSkills = db_all('SELECT * FROM skills ORDER BY name');

require __DIR__ . '/../includes/header.php';
?>
<section class="section-pad-sm section-cream">
  <div class="container">
    <div class="row align-items-end g-3">
      <div class="col-lg-8">
        <span class="eyebrow">People</span>
        <h1 class="display-5 mt-2 mb-1">Find someone to learn with.</h1>
        <p class="text-muted mb-0">Directory of active members whose profiles are visible to members. Search by skill, interest or place.</p>
      </div>
      <div class="col-lg-4 text-lg-end">
        <span class="badge badge-soft"><?= number_format($total) ?> member<?= $total === 1 ? '' : 's' ?> found</span>
      </div>
    </div>
  </div>
</section>

<section class="section-pad-sm">
  <div class="container">
    <form class="filter-bar mb-4" method="get" action="<?= e(url('pages/directory.php')) ?>">
      <div class="row g-2 align-items-end">
        <div class="col-lg-3 col-md-6">
          <label class="form-label" for="q">Search</label>
          <input class="form-control" id="q" name="q" value="<?= e($q) ?>" placeholder="Name, headline, interest">
        </div>
        <div class="col-lg-2 col-md-6">
          <label class="form-label" for="skill">Skill</label>
          <select class="form-select" id="skill" name="skill">
            <option value="">All skills</option>
            <?php foreach ($allSkills as $s): ?><option value="<?= (int) $s['id'] ?>" <?= $skillId === (int) $s['id'] ? 'selected' : '' ?>><?= e($s['name']) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="col-lg-2 col-md-4">
          <label class="form-label" for="interest">Interest</label>
          <input class="form-control" id="interest" name="interest" value="<?= e($interest) ?>" placeholder="e.g. Health">
        </div>
        <div class="col-lg-2 col-md-4">
          <label class="form-label" for="location">Location</label>
          <input class="form-control" id="location" name="location" value="<?= e($location) ?>" placeholder="e.g. Kano">
        </div>
        <div class="col-lg-2 col-md-4">
          <label class="form-label" for="stage">Stage</label>
          <select class="form-select" id="stage" name="stage">
            <option value="">All stages</option>
            <?php foreach (array_keys(journey_stages()) as $s): ?><option value="<?= e($s) ?>" <?= $stage === $s ? 'selected' : '' ?>><?= e($s) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="col-lg-1 col-12 d-grid">
          <button class="btn btn-gold" type="submit" aria-label="Apply filters"><i class="bi bi-search"></i></button>
        </div>
      </div>
      <?php if ($q || $skillId || $interest || $location || $stage): ?>
        <div class="mt-2"><a class="small" href="<?= e(url('pages/directory.php')) ?>">Clear filters</a></div>
      <?php endif; ?>
    </form>

    <?php if (!$members): ?>
      <div class="panel empty-state mx-auto">
        <i class="bi bi-people display-4"></i>
        <h2>No members match those filters</h2>
        <p>Try a broader search, or invite someone to join the pilot.</p>
        <a class="btn btn-outline-brown" href="<?= e(url('pages/directory.php')) ?>">Reset filters</a>
      </div>
    <?php else: ?>
      <div class="row g-3">
        <?php foreach ($members as $m): ?>
          <div class="col-md-6 col-lg-4">
            <div class="feature-card h-100 d-flex flex-column">
              <div class="d-flex align-items-start gap-3 mb-3">
                <?= avatar_html($m, $m, 'md') ?>
                <div class="min-w-0">
                  <h2 class="h6 mb-1"><a class="text-decoration-none" href="<?= e(url('pages/profile.php?u=' . urlencode($m['username']))) ?>"><?= e($m['name']) ?></a> <?= demo_badge($m['is_demo']) ?></h2>
                  <div class="small text-muted">@<?= e($m['username']) ?></div>
                  <?php if ($m['location']): ?><div class="small text-muted"><i class="bi bi-geo-alt me-1"></i><?= e($m['location']) ?></div><?php endif; ?>
                </div>
              </div>
              <p class="small text-muted mb-2"><?= e(excerpt($m['headline'] ?: 'No headline yet.', 90)) ?></p>
              <div class="d-flex flex-wrap gap-1 mb-3">
                <span class="badge badge-stage"><?= e($m['journey_stage']) ?></span>
                <?php foreach (array_slice($skillsByUser[(int) $m['id']] ?? [], 0, 2) as $s): ?><span class="badge badge-tag"><?= e($s['name']) ?></span><?php endforeach; ?>
              </div>
              <div class="mt-auto d-flex justify-content-between align-items-center">
                <a class="small fw-semibold" href="<?= e(url('pages/profile.php?u=' . urlencode($m['username']))) ?>">View profile <i class="bi bi-arrow-right"></i></a>
                <a class="small text-muted" href="<?= e(url('pages/portfolio.php?u=' . urlencode($m['username']))) ?>">Portfolio</a>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
      <?= pagination($total, $page, $perPage, array_filter(['q' => $q, 'skill' => $skillId ?: null, 'interest' => $interest, 'location' => $location, 'stage' => $stage])) ?>
    <?php endif; ?>

    <p class="small text-muted mt-3 mb-0"><i class="bi bi-shield-lock me-1"></i>Profiles marked private are excluded. Members-only profiles are visible because you are signed in.</p>
  </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>

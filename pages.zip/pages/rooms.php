<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_login();

$page_title = 'Collaboration Rooms';
$page_description = 'Join public conversations and your team rooms in the Mindset Innovators Hub pilot.';
$active = 'explore';
$breadcrumbs = [['Collaboration Rooms', null]];

$uid = user_id();
$errors = [];

if (is_post()) {
    require_csrf();
    if (post('action') === 'create_public' && is_admin()) {
        $name = post('name');
        $description = post('description');
        if (mb_strlen($name) < 4 || mb_strlen($name) > 160) {
            $errors['name'] = 'Give the room a name between 4 and 160 characters.';
        }
        if (mb_strlen($description) > 1000) {
            $errors['description'] = 'Keep the description under 1,000 characters.';
        }
        if (!$errors) {
            db_run("INSERT INTO rooms (name, description, type, created_by) VALUES (?, ?, 'public', ?)", [$name, $description ?: null, $uid]);
            $newId = (int) db()->lastInsertId();
            log_activity('room.created', 'room', $newId, $name);
            flash('success', 'The public room has been created.');
            redirect('pages/room.php?id=' . $newId);
        }
    } else {
        flash('warning', 'You do not have permission to create a public room.');
        redirect('pages/rooms.php');
    }
}

$publicRooms = db_all(
    "SELECT r.*, (SELECT COUNT(*) FROM room_messages m WHERE m.room_id = r.id AND m.is_deleted = 0) AS message_count,
            (SELECT MAX(m.created_at) FROM room_messages m WHERE m.room_id = r.id AND m.is_deleted = 0) AS last_at,
            (SELECT u2.name FROM room_messages m2 JOIN users u2 ON u2.id = m2.user_id
              WHERE m2.room_id = r.id AND m2.is_deleted = 0 ORDER BY m2.id DESC LIMIT 1) AS last_author
     FROM rooms r WHERE r.type = 'public' ORDER BY COALESCE(last_at, r.created_at) DESC"
);

if (is_admin()) {
    $teamRooms = db_all(
        "SELECT r.*, t.name AS team_name,
                (SELECT COUNT(*) FROM room_messages m WHERE m.room_id = r.id AND m.is_deleted = 0) AS message_count,
                (SELECT MAX(m.created_at) FROM room_messages m WHERE m.room_id = r.id AND m.is_deleted = 0) AS last_at
         FROM rooms r LEFT JOIN teams t ON t.id = r.team_id
         WHERE r.type = 'team' ORDER BY COALESCE(last_at, r.created_at) DESC"
    );
} else {
    $teamRooms = db_all(
        "SELECT r.*, t.name AS team_name,
                (SELECT COUNT(*) FROM room_messages m WHERE m.room_id = r.id AND m.is_deleted = 0) AS message_count,
                (SELECT MAX(m.created_at) FROM room_messages m WHERE m.room_id = r.id AND m.is_deleted = 0) AS last_at
         FROM rooms r
         JOIN team_members tm ON tm.team_id = r.team_id AND tm.user_id = ?
         LEFT JOIN teams t ON t.id = r.team_id
         WHERE r.type = 'team' ORDER BY COALESCE(last_at, r.created_at) DESC",
        [$uid]
    );
}

require __DIR__ . '/../includes/header.php';
?>
<section class="section-pad-sm section-cream">
  <div class="container">
    <div class="row align-items-end g-3">
      <div class="col-lg-8">
        <span class="eyebrow">Talk · Share · Build</span>
        <h1 class="display-5 mt-2 mb-1">Collaboration Rooms</h1>
        <p class="text-muted mb-0">Ask questions, share progress and keep your team moving. Messages refresh automatically. Be kind, be specific and respect privacy.</p>
      </div>
      <div class="col-lg-4 text-lg-end">
        <span class="badge badge-soft align-self-center"><i class="bi bi-chat-square-text me-1"></i><?= count($publicRooms) + count($teamRooms) ?> room<?= count($publicRooms) + count($teamRooms) === 1 ? '' : 's' ?> available</span>
      </div>
    </div>
  </div>
</section>

<section class="section-pad-sm">
  <div class="container">
    <div class="row g-4">
      <div class="col-lg-8">
        <div class="panel mb-4">
          <div class="panel-head">
            <h2><i class="bi bi-globe2 me-2 text-gold"></i>Public rooms</h2>
            <span class="small text-muted">Open to signed-in members</span>
          </div>
          <div class="list-group list-group-flush">
            <?php if (!$publicRooms): ?><div class="panel-body text-muted small">No public rooms yet.</div><?php endif; ?>
            <?php foreach ($publicRooms as $room): ?>
              <a class="list-group-item list-group-item-action py-3 px-3 border-0 border-bottom" href="<?= e(url('pages/room.php?id=' . (int) $room['id'])) ?>">
                <div class="d-flex justify-content-between align-items-start gap-3">
                  <div class="min-w-0">
                    <div class="fw-semibold text-dark-brown">#<?= e($room['name']) ?> <?= demo_badge($room['is_demo']) ?></div>
                    <div class="small text-muted"><?= e(excerpt((string) $room['description'], 120)) ?></div>
                    <?php if ($room['last_at']): ?><div class="small text-muted mt-1"><i class="bi bi-clock me-1"></i>Last message <?= e(time_ago($room['last_at'])) ?><?= $room['last_author'] ? ' by ' . e($room['last_author']) : '' ?></div><?php endif; ?>
                  </div>
                  <span class="badge badge-soft flex-shrink-0"><?= (int) $room['message_count'] ?> <i class="bi bi-chat-dots ms-1"></i></span>
                </div>
              </a>
            <?php endforeach; ?>
          </div>
        </div>

        <div class="panel">
          <div class="panel-head">
            <h2><i class="bi bi-people me-2 text-gold"></i>Your team rooms</h2>
            <a class="small" href="<?= e(url('pages/teams.php')) ?>">Find a team</a>
          </div>
          <div class="list-group list-group-flush">
            <?php if (!$teamRooms): ?>
              <div class="panel-body">
                <p class="small text-muted mb-2">You are not in a team room yet. Join a team to get a private space for your group.</p>
                <a class="btn btn-sm btn-outline-brown" href="<?= e(url('pages/teams.php')) ?>">Browse teams</a>
              </div>
            <?php endif; ?>
            <?php foreach ($teamRooms as $room): ?>
              <a class="list-group-item list-group-item-action py-3 px-3 border-0 border-bottom" href="<?= e(url('pages/room.php?id=' . (int) $room['id'])) ?>">
                <div class="d-flex justify-content-between align-items-start gap-3">
                  <div class="min-w-0">
                    <div class="fw-semibold text-dark-brown"><i class="bi bi-lock me-1 small"></i><?= e($room['name']) ?> <?= demo_badge($room['is_demo']) ?></div>
                    <div class="small text-muted"><?= e($room['team_name'] ?: 'Team room') ?><?= $room['last_at'] ? ' · last message ' . e(time_ago($room['last_at'])) : '' ?></div>
                  </div>
                  <span class="badge badge-soft flex-shrink-0"><?= (int) $room['message_count'] ?> <i class="bi bi-chat-dots ms-1"></i></span>
                </div>
              </a>
            <?php endforeach; ?>
          </div>
        </div>
      </div>

      <aside class="col-lg-4">
        <div class="panel panel-body mb-4">
          <div class="small-caps mb-2">Room guidelines</div>
          <ul class="small text-muted ps-3 mb-0">
            <li class="mb-2">Share progress and ask specific questions.</li>
            <li class="mb-2">Do not post personal contact details or anyone else's private information.</li>
            <li class="mb-2">Give feedback on the work, not the person.</li>
            <li>Use the report link on a message if something feels unsafe. Reports go to admins.</li>
          </ul>
        </div>

        <?php if (is_admin()): ?>
          <div class="panel panel-body">
            <div class="small-caps mb-2">Admin: create a public room</div>
            <p class="small text-muted">Public rooms are visible to every signed-in account. Team rooms are created automatically when a team is formed.</p>
            <?= error_summary($errors) ?>
            <form method="post" action="<?= e(url('pages/rooms.php')) ?>">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="create_public">
              <div class="mb-2">
                <label class="form-label" for="name">Room name</label>
                <input class="form-control form-control-sm <?= isset($errors['name']) ? 'is-invalid' : '' ?>" id="name" name="name" maxlength="160" required value="<?= e(post('name')) ?>">
                <?= field_error($errors, 'name') ?>
              </div>
              <div class="mb-2">
                <label class="form-label" for="description">Description</label>
                <textarea class="form-control form-control-sm" id="description" name="description" rows="3" maxlength="1000"><?= e(post('description')) ?></textarea>
                <?= field_error($errors, 'description') ?>
              </div>
              <button class="btn btn-sm btn-gold w-100" type="submit">Create public room</button>
            </form>
          </div>
        <?php else: ?>
          <div class="panel panel-body">
            <div class="small-caps mb-2">Need a room for your team?</div>
            <p class="small text-muted mb-2">Every team gets a private room automatically. Create a team from the team page and invite others to join.</p>
            <a class="btn btn-sm btn-outline-brown w-100" href="<?= e(url('pages/teams.php')) ?>">Go to teams</a>
          </div>
        <?php endif; ?>
      </aside>
    </div>
  </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>

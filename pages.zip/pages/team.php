<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_login();

$id = get_int('id') ?: (int) post('team_id');
$team = db_one(
    'SELECT t.*, c.title AS challenge_title, u.name AS creator_name
     FROM teams t LEFT JOIN challenges c ON c.id = t.challenge_id LEFT JOIN users u ON u.id = t.created_by
     WHERE t.id = ?',
    [$id]
);
if (!$team) {
    not_found('That team could not be found.');
}

$isMember = is_team_member($id);
if (is_post()) {
    require_csrf();
    $action = post('action');
    if ($action === 'join' && !$isMember) {
        db_run("INSERT INTO team_members (team_id, user_id, role) VALUES (?, ?, 'member')", [$id, user_id()]);
        advance_stage(user_id(), 'Build');
        refresh_badges(user_id());
        log_activity('team.joined', 'team', $id, $team['name']);
        if ($team['created_by'] && (int) $team['created_by'] !== user_id()) {
            notify((int) $team['created_by'], 'team', 'A new member joined your team: ' . $team['name'] . '.', 'pages/team.php?id=' . $id);
        }
        flash('success', 'You joined the team. The room is ready.');
        redirect('pages/team.php?id=' . $id);
    }
    if ($action === 'leave' && $isMember) {
        $mine = db_one('SELECT role FROM team_members WHERE team_id = ? AND user_id = ?', [$id, user_id()]);
        if ($mine && $mine['role'] === 'lead') {
            flash('warning', 'Team leads cannot leave while they are the only lead. This prototype does not yet support transferring a team.');
        } else {
            db_run('DELETE FROM team_members WHERE team_id = ? AND user_id = ?', [$id, user_id()]);
            log_activity('team.left', 'team', $id, $team['name']);
            flash('success', 'You left the team.');
            redirect('pages/teams.php');
        }
        redirect('pages/team.php?id=' . $id);
    }
}

$members = db_all(
    'SELECT u.id, u.name, u.username, u.is_demo, u.role AS user_role, p.headline, p.photo, tm.role, tm.joined_at
     FROM team_members tm JOIN users u ON u.id = tm.user_id LEFT JOIN profiles p ON p.user_id = u.id
     WHERE tm.team_id = ? ORDER BY tm.role = "lead" DESC, tm.joined_at ASC',
    [$id]
);
$room = db_one("SELECT * FROM rooms WHERE team_id = ? AND type = 'team' LIMIT 1", [$id]);
if (!$room && $isMember) {
    db_run("INSERT INTO rooms (name, description, type, team_id, created_by) VALUES (?, ?, 'team', ?, ?)", [
        mb_substr($team['name'], 0, 140) . ' room', 'Team room for ' . $team['name'] . '.', $id, user_id(),
    ]);
    $room = db_one('SELECT * FROM rooms WHERE id = ?', [(int) db()->lastInsertId()]);
}
$recent = [];
if ($room && $isMember) {
    $recent = db_all(
        'SELECT rm.*, u.name FROM room_messages rm JOIN users u ON u.id = rm.user_id
         WHERE rm.room_id = ? AND rm.is_deleted = 0 ORDER BY rm.id DESC LIMIT 5',
        [(int) $room['id']]
    );
    $recent = array_reverse($recent);
}

$page_title = $team['name'];
$page_description = excerpt($team['description'], 155);
$breadcrumbs = [['Teams', 'pages/teams.php'], [$team['name'], null]];
require __DIR__ . '/../includes/header.php';
?>
<section class="section-pad-sm section-cream">
  <div class="container">
    <div class="row g-4 align-items-start">
      <div class="col-lg-8">
        <div class="d-flex flex-wrap gap-2 mb-2">
          <span class="badge badge-soft"><i class="bi bi-people me-1"></i><?= count($members) ?> member<?= count($members) === 1 ? '' : 's' ?></span>
          <?= demo_badge($team['is_demo']) ?>
          <?php if ($isMember): ?><span class="badge text-bg-success">You are a member</span><?php endif; ?>
        </div>
        <h1 class="display-5 mt-2 mb-2"><?= e($team['name']) ?></h1>
        <p class="lead"><?= e($team['description']) ?></p>
        <div class="meta-row">
          <span><i class="bi bi-person me-1"></i>Created by <?= e($team['creator_name'] ?: 'a member') ?></span>
          <?php if ($team['challenge_title']): ?><span><i class="bi bi-lightning-charge me-1"></i><a href="<?= e(url('pages/challenge-detail.php?id=' . (int) $team['challenge_id'])) ?>"><?= e($team['challenge_title']) ?></a></span><?php endif; ?>
        </div>
      </div>
      <div class="col-lg-4">
        <div class="panel panel-body">
          <?php if ($isMember): ?>
            <div class="small-caps mb-2">Your team room</div>
            <?php if ($room): ?><a class="btn btn-gold w-100" href="<?= e(url('pages/room.php?id=' . (int) $room['id'])) ?>"><i class="bi bi-chat-square-text me-1"></i>Open team room</a><?php endif; ?>
            <?php if ($isMember): ?>
              <form class="mt-2" method="post" action="<?= e(url('pages/team.php?id=' . $id)) ?>" data-confirm="Leave this team? You can rejoin later.">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="leave">
                <input type="hidden" name="team_id" value="<?= $id ?>">
                <button class="btn btn-sm btn-outline-brown w-100" type="submit">Leave team</button>
              </form>
            <?php endif; ?>
          <?php else: ?>
            <p class="small text-muted">Join the team to access its room and work with the group.</p>
            <form method="post" action="<?= e(url('pages/team.php?id=' . $id)) ?>">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="join">
              <input type="hidden" name="team_id" value="<?= $id ?>">
              <button class="btn btn-gold w-100" type="submit">Join team</button>
            </form>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="section-pad-sm">
  <div class="container">
    <div class="row g-4">
      <div class="col-lg-7">
        <div class="panel panel-body">
          <h2 class="h5">Team members</h2>
          <?php foreach ($members as $m): ?>
            <div class="d-flex align-items-center gap-3 border-bottom py-3">
              <?= avatar_html($m, $m, 'sm') ?>
              <div class="flex-grow-1">
                <a class="fw-semibold text-decoration-none" href="<?= e(url('pages/profile.php?u=' . urlencode($m['username']))) ?>"><?= e($m['name']) ?></a>
                <?php if ($m['role'] === 'lead'): ?><span class="badge badge-stage ms-1">Lead</span><?php endif; ?>
                <?= demo_badge($m['is_demo']) ?>
                <div class="small text-muted"><?= e(excerpt($m['headline'] ?: 'Member', 80)) ?></div>
              </div>
              <span class="small text-muted"><?= e(format_date($m['joined_at'], 'M Y')) ?></span>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
      <div class="col-lg-5">
        <?php if ($isMember && $recent): ?>
          <div class="panel panel-body">
            <div class="d-flex justify-content-between align-items-center mb-2">
              <h2 class="h5 mb-0">Recent room activity</h2>
              <?php if ($room): ?><a class="small" href="<?= e(url('pages/room.php?id=' . (int) $room['id'])) ?>">Open</a><?php endif; ?>
            </div>
            <?php foreach ($recent as $msg): ?>
              <div class="border-bottom py-2">
                <div class="small fw-semibold"><?= e($msg['name']) ?> <span class="text-muted fw-normal">· <?= e(time_ago($msg['created_at'])) ?></span></div>
                <div class="small text-muted"><?= e(excerpt($msg['body'], 110)) ?></div>
              </div>
            <?php endforeach; ?>
          </div>
        <?php else: ?>
          <div class="panel panel-body">
            <div class="small-caps mb-2">How team rooms work</div>
            <p class="small text-muted mb-0">Messages post without a page reload and refresh every few seconds. Only team members (and admins) can open a team room. Reports go to the admin area.</p>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>

<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_role(['mentor', 'admin']);
if (is_admin()) {
    redirect('admin/index.php');
}

$uid = user_id();
$user = current_user();
$mentorProfile = db_one('SELECT * FROM mentor_profiles WHERE user_id = ?', [$uid]);
$activeMentees = db_count("SELECT COUNT(*) FROM mentor_requests WHERE mentor_id = ? AND status = 'accepted'", [$uid]);
$pendingRequests = db_count("SELECT COUNT(*) FROM mentor_requests WHERE mentor_id = ? AND status = 'pending'", [$uid]);
$pendingReviews = db_count("SELECT COUNT(*) FROM submissions WHERE status = 'submitted'");
$challengesCreated = db_count('SELECT COUNT(*) FROM challenges WHERE created_by = ?', [$uid]);
$feedbackGiven = db_count('SELECT COUNT(*) FROM project_feedback WHERE user_id = ?', [$uid]);

$requests = db_all(
    "SELECT mr.*, u.name, u.username, u.is_demo, p.headline FROM mentor_requests mr
     JOIN users u ON u.id = mr.member_id LEFT JOIN profiles p ON p.user_id = u.id
     WHERE mr.mentor_id = ? ORDER BY mr.status = 'pending' DESC, mr.created_at DESC LIMIT 6",
    [$uid]
);
$reviewQueue = db_all(
    "SELECT s.id, s.challenge_id, s.created_at, s.content, u.name, u.username, c.title AS challenge_title
     FROM submissions s JOIN users u ON u.id = s.user_id JOIN challenges c ON c.id = s.challenge_id
     WHERE s.status = 'submitted' ORDER BY s.created_at ASC LIMIT 6"
);
$myChallenges = db_all(
    'SELECT c.*, (SELECT COUNT(*) FROM challenge_participants cp WHERE cp.challenge_id = c.id) AS participants,
            (SELECT COUNT(*) FROM submissions s WHERE s.challenge_id = c.id) AS submissions
     FROM challenges c WHERE c.created_by = ? ORDER BY c.created_at DESC LIMIT 5',
    [$uid]
);
$recentFeedback = db_all(
    'SELECT f.*, p.title, p.id AS project_id FROM project_feedback f JOIN projects p ON p.id = f.project_id
     WHERE f.user_id = ? ORDER BY f.created_at DESC LIMIT 5',
    [$uid]
);
$capacity = (int) ($mentorProfile['capacity'] ?? 0);
$places = max(0, $capacity - $activeMentees);
$unread = unread_notifications_count($uid);

$page_title = 'Mentor dashboard';
$page_description = 'Requests, reviews and the mentoring work you are supporting.';
require __DIR__ . '/../includes/header.php';
?>
<section class="section-pad-sm section-cream">
  <div class="container">
    <div class="row align-items-end g-3">
      <div class="col-lg-8">
        <span class="eyebrow">Mentor workspace</span>
        <h1 class="display-5 mt-2 mb-1">Hello, <?= e(explode(' ', $user['name'])[0]) ?>.</h1>
        <p class="text-muted mb-0"><?= $pendingRequests ? 'You have ' . $pendingRequests . ' pending mentor request' . ($pendingRequests === 1 ? '' : 's') . ' to answer.' : 'Your mentoring queue is clear. Thanks for showing up consistently.' ?></p>
      </div>
      <div class="col-lg-4 text-lg-end d-flex flex-wrap gap-2 justify-content-lg-end">
        <a class="btn btn-gold" href="<?= e(url('pages/mentor-form.php')) ?>"><i class="bi bi-pencil me-1"></i>Edit mentor profile</a>
        <a class="btn btn-outline-brown" href="<?= e(url('pages/messages.php')) ?>"><i class="bi bi-chat-dots me-1"></i>Conversations</a>
      </div>
    </div>
  </div>
</section>

<section class="section-pad-sm">
  <div class="container">
    <div class="row g-3 mb-4">
      <div class="col-6 col-lg-3"><div class="dash-stat"><div class="d-flex justify-content-between"><div><div class="number"><?= $activeMentees ?></div><div class="label">Active mentees</div></div><span class="icon"><i class="bi bi-people"></i></span></div></div></div>
      <div class="col-6 col-lg-3"><div class="dash-stat"><div class="d-flex justify-content-between"><div><div class="number"><?= $pendingRequests ?></div><div class="label">Pending requests</div></div><span class="icon"><i class="bi bi-inbox"></i></span></div></div></div>
      <div class="col-6 col-lg-3"><div class="dash-stat"><div class="d-flex justify-content-between"><div><div class="number"><?= $pendingReviews ?></div><div class="label">Submissions to review</div></div><span class="icon"><i class="bi bi-clipboard-check"></i></span></div></div></div>
      <div class="col-6 col-lg-3"><div class="dash-stat"><div class="d-flex justify-content-between"><div><div class="number"><?= $places ?></div><div class="label">Mentee places left</div></div><span class="icon"><i class="bi bi-person-plus"></i></span></div></div></div>
    </div>

    <?php if (!$mentorProfile): ?>
      <div class="alert alert-warning">
        <strong>Your mentor profile is not set up yet.</strong> Add what you can help with and your availability so members can send a focused request.
        <a class="alert-link" href="<?= e(url('pages/mentor-form.php')) ?>">Set up my mentor profile</a>.
      </div>
    <?php endif; ?>

    <div class="row g-4">
      <div class="col-lg-7">
        <div class="panel mb-4">
          <div class="panel-head"><h2><i class="bi bi-inbox me-2 text-gold"></i>Mentor requests</h2><span class="badge badge-soft"><?= count($requests) ?></span></div>
          <div class="panel-body">
            <?php if (!$requests): ?><p class="small text-muted mb-0">No requests yet. When a member asks for help, the request appears here and in your notifications.</p><?php endif; ?>
            <?php foreach ($requests as $r): ?>
              <div class="border-bottom py-3">
                <div class="d-flex justify-content-between align-items-start gap-2">
                  <div>
                    <a class="fw-semibold text-decoration-none" href="<?= e(url('pages/profile.php?u=' . urlencode($r['username']))) ?>"><?= e($r['name']) ?></a> <?= demo_badge($r['is_demo']) ?>
                    <div class="small text-muted"><?= e($r['headline'] ?: 'Member') ?> · <?= e(time_ago($r['created_at'])) ?></div>
                  </div>
                  <?= status_badge($r['status']) ?>
                </div>
                <p class="small text-muted mt-2 mb-2"><?= e(excerpt($r['message'], 220)) ?></p>
                <a class="btn btn-sm btn-outline-brown" href="<?= e(url('pages/messages.php?request=' . (int) $r['id'])) ?>">Open conversation</a>
              </div>
            <?php endforeach; ?>
          </div>
        </div>

        <div class="panel">
          <div class="panel-head"><h2><i class="bi bi-clipboard-check me-2 text-gold"></i>Review queue</h2><a class="small" href="<?= e(url('pages/challenges.php')) ?>">All challenges</a></div>
          <div class="panel-body">
            <?php if (!$reviewQueue): ?><p class="small text-muted mb-0">No submissions waiting for review.</p><?php endif; ?>
            <?php foreach ($reviewQueue as $s): ?>
              <div class="border-bottom py-3">
                <div class="d-flex justify-content-between gap-2">
                  <div><span class="fw-semibold small"><?= e($s['name']) ?></span> <span class="small text-muted">· <?= e($s['challenge_title']) ?></span></div>
                  <span class="small text-muted"><?= e(time_ago($s['created_at'])) ?></span>
                </div>
                <p class="small text-muted mb-2 mt-1"><?= e(excerpt($s['content'], 160)) ?></p>
                <a class="btn btn-sm btn-brown" href="<?= e(url('pages/challenge-detail.php?id=' . (int) $s['challenge_id'] . '#reviews')) ?>">Review submission</a>
              </div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>

      <aside class="col-lg-5">
        <div class="panel panel-body mb-4">
          <div class="small-caps mb-2">Mentor snapshot</div>
          <ul class="list-clean small">
            <li class="d-flex justify-content-between"><span>Challenges created</span><strong><?= $challengesCreated ?></strong></li>
            <li class="d-flex justify-content-between"><span>Project feedback given</span><strong><?= $feedbackGiven ?></strong></li>
            <li class="d-flex justify-content-between"><span>Unread notifications</span><strong><?= $unread ?></strong></li>
            <li class="d-flex justify-content-between"><span>Capacity</span><strong><?= $activeMentees ?>/<?= $capacity ?></strong></li>
          </ul>
          <?php if ($mentorProfile && $mentorProfile['availability']): ?><p class="small text-muted mt-2 mb-0"><i class="bi bi-calendar-week me-1 text-gold"></i><?= e($mentorProfile['availability']) ?></p><?php endif; ?>
        </div>

        <div class="panel panel-body mb-4">
          <div class="d-flex justify-content-between align-items-center mb-2">
            <h2 class="h5 mb-0">My challenges</h2>
            <a class="small" href="<?= e(url('pages/challenge-form.php')) ?>">Create</a>
          </div>
          <?php if (!$myChallenges): ?><p class="small text-muted mb-0">You have not created a challenge yet.</p><?php endif; ?>
          <?php foreach ($myChallenges as $c): ?>
            <a class="d-block border-bottom py-2 text-decoration-none" href="<?= e(url('pages/challenge-detail.php?id=' . (int) $c['id'])) ?>">
              <span class="small fw-semibold text-dark-brown"><?= e($c['title']) ?></span>
              <span class="d-block small text-muted"><?= (int) $c['participants'] ?> participants · <?= (int) $c['submissions'] ?> submissions · <?= e(status_badge($c['status'])) ?></span>
            </a>
          <?php endforeach; ?>
        </div>

        <div class="panel panel-body">
          <div class="small-caps mb-2">Recent project feedback you gave</div>
          <?php if (!$recentFeedback): ?><p class="small text-muted mb-0">No project feedback yet. <a href="<?= e(url('pages/showcase.php')) ?>">Browse the showcase</a>.</p><?php endif; ?>
          <?php foreach ($recentFeedback as $f): ?>
            <a class="d-block border-bottom py-2 text-decoration-none" href="<?= e(url('pages/project-detail.php?id=' . (int) $f['project_id'] . '#feedback')) ?>">
              <span class="small fw-semibold text-dark-brown"><?= e($f['title']) ?></span>
              <span class="d-block small text-muted"><?= e(excerpt($f['feedback'], 90)) ?></span>
            </a>
          <?php endforeach; ?>
        </div>
      </aside>
    </div>
  </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>

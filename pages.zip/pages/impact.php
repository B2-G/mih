<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_login();
$page_title = 'Impact Dashboard';
$page_description = 'Hub impact metrics with filters';
require __DIR__ . '/../includes/header.php';
?>
<main id="main-content">
<section class="section-pad-lg">
  <div class="container">
    <div class="row mb-4">
      <div class="col-md-6">
        <h1>Impact Dashboard</h1>
        <p class="text-muted">Filter by date range and role</p>
      </div>
      <div class="col-md-6 text-md-end">
        <form method="get" action="" class="form-inline">
          <div class="form-group mb-2">
            <label class="small text-muted me-2">From</label>
            <input type="date" name="from" class="form-control form-control-sm" style="width: 140px;">
          </div>
          <div class="form-group mb-2">
            <label class="small text-muted me-2">To</label>
            <input type="date" name="to" class="form-control form-control-sm" style="width: 140px;">
          </div>
          <button class="btn btn-sm btn-gold ms-2" type="submit">Apply</button>
        </form>
      </div>
    </div>
    <div class="row">
      <div class="col-md-4">
        <div class="card bg-brown text-white">
          <div class="card-body">
            <h5 class="card-title">Total Users</h5>
            <h2 class="card-number">9</h2>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card bg-chocolate text-white">
          <div class="card-body">
            <h5 class="card-title">Active Challenges</h5>
            <h2 class="card-number">4</h2>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card bg-gold text-brown">
          <div class="card-body">
            <h5 class="card-title">Total Ideas</h5>
            <h2 class="card-number">4</h2>
          </div>
        </div>
      </div>
    </div>
    <div class="row mt-4">
      <div class="col-12">
        <div class="card">
          <div class="card-header bg-brown text-white">
            <h4 class="mb-0">Impact Summary</h4>
          </div>
          <div class="card-body p-0">
            <canvas id="impactChart" height="150"></canvas>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<script src="<?= e(asset('vendor Chart/chart.min.js')) ?>"></script>
<script>
  // Simple impact chart
  const ctx = document.getElementById('impactChart').getContext('2d');
  const impactChart = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: ['Users', 'Challenges', 'Ideas'],
      datasets: [{
        data: [9, 4, 4],
        backgroundColor: ['#2E1A0F', '#4A2C17', '#D4AF37'],
        hoverBackgroundColor: ['#3E2A1A', '#5A3C22', '#E6C068']
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: { position: 'bottom' },
        tooltip: { enabled: false }
      }
    }
  });
</script>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
$page_title = 'Access Denied';
require __DIR__ . '/../includes/header.php';
?>
<main id="main-content">
<section class="section-pad-lg text-center">
  <div class="container">
    <div class="row">
      <div class="col-12">
        <h1 class="display-6 fw-bold mb-3">403</h1>
        <h2 class="mb-4">Access denied</h2>
        <p class="lead text-muted">You don't have permission to access this page.</p>
        <a class="btn btn-gold mt-3" href="<?= e(url('index.php')) ?>">Go to home</a>
      </div>
    </div>
  </div>
</section>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
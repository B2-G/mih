<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_login();

$page_title = 'Collaboration Teams';
$page_description = 'Create or join a team in the Mindset Innovators Hub pilot and collaborate in a shared room.';
$breadcrumbs = [['Teams', null]];
$errors = [];
$form = ['name' => '', 'description' => '', 'challenge_id' => ''];

if (is_post()) {
    require_csrf();
    $action = post('action');
    if ($action === 'join') {
        $teamId = (int) post('team_id');
        $team = db_one('SELECT * FROM teams WHERE id = ?', [$teamId]);
        if (!$team) {
            flash('danger', 'That team could not be found.');
        } elseif (is_team_member($teamId)) {
            flash('info', 'You are already a member of this team.');
        } else {
            db_run("INSERT INTO team_members (team_id, user_id, role) VALUES (?, ?, 'member')", [$teamId, user_id()]);
            advance_stage(user_id(), 'Build');
            refresh_badges(user_id());
            log_activity('team.joined', 'team', $teamId, $team['name']);
            if ($team['created_by'] && (int) $team['created_by'] !== user_id()) {
                notify((int) $team['created_by'], 'team', 'A new member joined your team: ' . $team['name'] . '.', 'pages/team.php?id=' . $teamId);
            }
            flash('success', 'You joined ' . $team['name'] . '. The team room is now available.');
            redirect('pages/team.php?id=' . $teamId);
        }
        redirect('pages/teams.php');
    }

    if ($action === 'create') {
        $form['name'] = post('name');
        $form['description'] = post('description');
        $form['challenge_id'] = post('challenge_id');
        if (mb_strlen($form['name']) < 3 || mb_strlen($form['name']) > 120) {
            $errors['name'] = 'Use a team name between 3 and 120 characters.';
        }
        if (mb_strlen($form['description']) < 20 || mb_strlen($form['description']) > 2000) {
            $errors['description'] = 'Describe the team in 20–2,000 characters.';
        }
        $challengeId = null;
        if ($form['challenge_id'] !== '') {
            $ch = db_one("SELECT id FROM challenges WHERE id = ? AND status = 'published'", [(int) $form['challenge_id']]);
            if (!$ch) {
                $errors['challenge_id'] = 'Choose a valid open challenge.';
            } else {
                $challengeId = (int) $ch['id'];
            }
        }
        if (!$errors) {
            db()->beginTransaction();
            db_run('INSERT INTO teams (name, description, challenge_id, created_by) VALUES (?, ?, ?, ?)', [$form['name'], $form['description'], $challengeId, user_id()]);
            $teamId = (int) db()->lastInsertId();
            db_run("INSERT INTO team_members (team_id, user_id, role) VALUES (?, ?, 'lead')", [$teamId, user_id()]);
            db_run("INSERT INTO rooms (name, description, type, team_id, created_by) VALUES (?, ?, 'team', ?, ?)", [
                mb_substr($form['name'], 0, 140) . ' room',
                'Team room for ' . $form['name'] . '.',
                $teamId,
                user_id(),
            ]);
            db()->commit();
            advance_stage(user_id(), 'Build');
            refresh_badges(user_id());
            log_activity('team.created', 'team', $teamId, $form['name']);
            flash('success', 'Your team and its room have been created.');
            redirect('pages/team.php?id=' . $teamId);
        }
    }
}

$q = get('q');
$page = current_page_number();
$perPage = 9;
$where = '1=1';
$params = [];
if ($q !== '') {
    $where .= ' AND (t.name LIKE ? OR t.description LIKE ?)';
    $params[] = '%' . $q . '%';
    $params[] = '%' . $q . '%';
}
$total = db_count("SELECT COUNT(*) FROM teams t WHERE $where", $params);
$pages = max(1, (int) ceil($total / $perPage));
$page = min($page, $pages);
$offset = ($page - 1) * $perPage;
$teams = db_all(
    "SELECT t.*, c.title AS challenge_title,
            (SELECT COUNT(*) FROM team_members tm WHERE tm.team_id = t.id) AS member_count,
            EXISTS(SELECT 1 FROM team_members mine WHERE mine.team_id = t.id AND mine.user_id = ?) AS joined
     FROM teams t LEFT JOIN challenges c ON c.id = t.challenge_id
     WHERE $where ORDER BY t.created_at DESC LIMIT $perPage OFFSET $offset",
    array_merge([user_id()], $params)
);
$challenges = db_all("SELECT id, title FROM challenges WHERE status = 'published' ORDER BY deadline IS NULL, deadline ASC");

require __DIR__ . '/../includes/header.php';
?>
<section class="section-pad-sm section-cream">
  <div class="container">
    <div class="row align-items-end g-3">
      <div class="col-lg-8">
        <span class="eyebrow">Practise · Build</span>
        <h1 class="display-5 mt-2 mb-1">Collaboration teams</h1>
        <p class="text-muted mb-0">Build with other people. Every team gets a shared room, an optional challenge and a record of who took part.</p>
      </div>
      <div class="col-lg-4 text-lg-end">
        <button class="btn btn-gold" type="button" data-bs-toggle="collapse" data-bs-target="#createTeam" aria-expanded="false" aria-controls="createTeam"><i class="bi bi-plus-lg me-1"></i>Create a team</button>
      </div>
    </div>
  </div>
</section>

<section class="section-pad-sm">
  <div class="container">
    <div class="collapse mb-4" id="createTeam">
      <div class="panel panel-body">
        <h2 class="h5">Create a team</h2>
        <?= error_summary($errors) ?>
        <form method="post" action="<?= e(url('pages/teams.php')) ?>" class="needs-validation" novalidate data-single-submit>
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="create">
          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label" for="name">Team name <span class="text-danger">*</span></label>
              <input class="form-control <?= isset($errors['name']) ? 'is-invalid' : '' ?>" id="name" name="name" required maxlength="120" value="<?= e($form['name']) ?>">
              <?= field_error($errors, 'name') ?>
            </div>
            <div class="col-md-6">
              <label class="form-label" for="challenge_id">Working on a challenge? <span class="text-muted">(optional)</span></label>
              <select class="form-select <?= isset($errors['challenge_id']) ? 'is-invalid' : '' ?>" id="challenge_id" name="challenge_id">
                <option value="">No specific challenge</option>
                <?php foreach ($challenges as $c): ?><option value="<?= (int) $c['id'] ?>" <?= $form['challenge_id'] === (string) $c['id'] ? 'selected' : '' ?>><?= e($c['title']) ?></option><?php endforeach; ?>
              </select>
              <?= field_error($errors, 'challenge_id') ?>
            </div>
            <div class="col-12">
              <label class="form-label" for="description">What is the team for? <span class="text-danger">*</span></label>
              <textarea class="form-control <?= isset($errors['description']) ? 'is-invalid' : '' ?>" id="description" name="description" rows="3" required minlength="20" maxlength="2000"><?= e($form['description']) ?></textarea>
              <?= field_error($errors, 'description') ?>
            </div>
          </div>
          <button class="btn btn-gold mt-3" type="submit">Create team and room</button>
        </form>
      </div>
    </div>

    <form class="filter-bar mb-4" method="get" action="<?= e(url('pages/teams.php')) ?>">
      <div class="row g-2 align-items-end">
        <div class="col-md-10"><label class="form-label" for="q">Search teams</label><input class="form-control" id="q" name="q" value="<?= e($q) ?>" placeholder="Team name or description"></div>
        <div class="col-md-2 d-grid"><button class="btn btn-gold" type="submit">Search</button></div>
      </div>
    </form>

    <?php if (!$teams): ?>
      <div class="panel empty-state mx-auto"><i class="bi bi-people display-4"></i><h2>No teams yet</h2><p>Create the first team and invite others to build with you.</p></div>
    <?php else: ?>
      <div class="row g-3">
        <?php foreach ($teams as $t): ?>
          <div class="col-md-6 col-lg-4">
            <div class="feature-card h-100 d-flex flex-column">
              <div class="d-flex justify-content-between gap-2 mb-2">
                <div class="feature-icon mb-0"><i class="bi bi-people"></i></div>
                <span class="badge badge-soft"><?= (int) $t['member_count'] ?> member<?= (int) $t['member_count'] === 1 ? '' : 's' ?></span>
              </div>
              <h2 class="h5"><a class="text-decoration-none" href="<?= e(url('pages/team.php?id=' . (int) $t['id'])) ?>"><?= e($t['name']) ?></a> <?= demo_badge($t['is_demo']) ?></h2>
              <p class="small text-muted"><?= e(excerpt($t['description'], 100)) ?></p>
              <?php if ($t['challenge_title']): ?><p class="small mb-2"><i class="bi bi-lightning-charge me-1 text-gold"></i><?= e($t['challenge_title']) ?></p><?php endif; ?>
              <div class="mt-auto d-flex gap-2">
                <a class="btn btn-sm btn-outline-brown" href="<?= e(url('pages/team.php?id=' . (int) $t['id'])) ?>">View team</a>
                <?php if ((int) $t['joined']): ?><span class="btn btn-sm btn-gold disabled">Joined</span>
                <?php else: ?>
                  <form method="post" action="<?= e(url('pages/teams.php')) ?>">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="join">
                    <input type="hidden" name="team_id" value="<?= (int) $t['id'] ?>">
                    <button class="btn btn-sm btn-gold" type="submit">Join</button>
                  </form>
                <?php endif; ?>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
      <?= pagination($total, $page, $perPage, array_filter(['q' => $q])) ?>
    <?php endif; ?>
  </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>

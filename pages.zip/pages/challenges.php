<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';

$page_title = 'Build-to-Learn Challenges';
$page_description = 'Join practical challenges, submit real work and receive feedback from mentors in the Mindset Innovators Hub pilot.';
$active = 'explore';
$breadcrumbs = [['Challenges', null]];

$q = get('q');
$category = get('category');
$difficulty = get('difficulty');
$page = current_page_number();
$perPage = PER_PAGE;

$where = ["c.status = 'published'"];
$params = [];
if ($q !== '') {
    $where[] = '(c.title LIKE ? OR c.description LIKE ? OR c.sponsor_name LIKE ?)';
    $like = '%' . $q . '%';
    array_push($params, $like, $like, $like);
}
if ($category !== '') {
    $where[] = 'c.category = ?';
    $params[] = $category;
}
if ($difficulty !== '' && in_array($difficulty, ['Beginner', 'Intermediate', 'Advanced'], true)) {
    $where[] = 'c.difficulty = ?';
    $params[] = $difficulty;
}
$whereSql = implode(' AND ', $where);
$total = db_count("SELECT COUNT(*) FROM challenges c WHERE $whereSql", $params);
$pages = max(1, (int) ceil($total / $perPage));
$page = min($page, $pages);
$offset = ($page - 1) * $perPage;
$uid = user_id();

$stmt = db()->prepare(
    "SELECT c.*, u.name AS creator_name,
            (SELECT COUNT(*) FROM challenge_participants cp WHERE cp.challenge_id = c.id) AS participants,
            (SELECT ROUND(AVG(cr.rating),1) FROM challenge_ratings cr WHERE cr.challenge_id = c.id) AS avg_rating,
            me.status AS my_status
     FROM challenges c
     LEFT JOIN users u ON u.id = c.created_by
     LEFT JOIN challenge_participants me ON me.challenge_id = c.id AND me.user_id = ?
     WHERE $whereSql
     ORDER BY c.deadline IS NULL, c.deadline ASC, c.created_at DESC
     LIMIT $perPage OFFSET $offset"
);
$paramsWithUser = array_merge([$uid], $params);
$stmt->execute($paramsWithUser);
$challenges = $stmt->fetchAll();
$categories = db_all("SELECT DISTINCT category FROM challenges WHERE status = 'published' ORDER BY category");

require __DIR__ . '/../includes/header.php';
?>
<section class="section-pad-sm section-cream">
  <div class="container">
    <div class="row align-items-end g-3">
      <div class="col-lg-8">
        <span class="eyebrow">Learn · Practise · Build</span>
        <h1 class="display-5 mt-2 mb-1">Build-to-Learn Challenges</h1>
        <p class="text-muted mb-0">Short, practical briefs with real reviewers. Submit work, get written feedback, improve and add evidence to your portfolio.</p>
      </div>
      <div class="col-lg-4 text-lg-end d-flex flex-wrap gap-2 justify-content-lg-end">
        <?php if (can_create_challenges()): ?><a class="btn btn-gold" href="<?= e(url('pages/challenge-form.php')) ?>"><i class="bi bi-plus-lg me-1"></i>Create challenge</a><?php endif; ?>
        <span class="badge badge-soft align-self-center"><?= number_format($total) ?> open</span>
      </div>
    </div>
  </div>
</section>

<section class="section-pad-sm">
  <div class="container">
    <form class="filter-bar mb-4" method="get" action="<?= e(url('pages/challenges.php')) ?>">
      <div class="row g-2 align-items-end">
        <div class="col-lg-5 col-md-6">
          <label class="form-label" for="q">Search challenges</label>
          <input class="form-control" id="q" name="q" value="<?= e($q) ?>" placeholder="Title, topic or sponsor">
        </div>
        <div class="col-lg-3 col-md-6">
          <label class="form-label" for="category">Category</label>
          <select class="form-select" id="category" name="category">
            <option value="">All categories</option>
            <?php foreach ($categories as $cat): ?><option value="<?= e($cat['category']) ?>" <?= $category === $cat['category'] ? 'selected' : '' ?>><?= e($cat['category']) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="col-lg-2 col-md-8">
          <label class="form-label" for="difficulty">Difficulty</label>
          <select class="form-select" id="difficulty" name="difficulty">
            <option value="">All levels</option>
            <?php foreach (['Beginner', 'Intermediate', 'Advanced'] as $d): ?><option value="<?= e($d) ?>" <?= $difficulty === $d ? 'selected' : '' ?>><?= e($d) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="col-lg-2 col-md-4 d-grid">
          <button class="btn btn-gold" type="submit"><i class="bi bi-search me-1"></i>Filter</button>
        </div>
      </div>
      <?php if ($q || $category || $difficulty): ?><div class="mt-2"><a class="small" href="<?= e(url('pages/challenges.php')) ?>">Clear filters</a></div><?php endif; ?>
    </form>

    <?php if (!$challenges): ?>
      <div class="panel empty-state mx-auto">
        <i class="bi bi-lightning display-4"></i>
        <h2>No challenges here yet</h2>
        <p>Try clearing the filters. If you are a mentor or partner, you can publish the first challenge.</p>
        <?php if (can_create_challenges()): ?><a class="btn btn-gold" href="<?= e(url('pages/challenge-form.php')) ?>">Create a challenge</a><?php else: ?><a class="btn btn-outline-brown" href="<?= e(url('pages/challenges.php')) ?>">Clear filters</a><?php endif; ?>
      </div>
    <?php else: ?>
      <div class="row g-3">
        <?php foreach ($challenges as $ch): $isOpen = !$ch['deadline'] || strtotime($ch['deadline']) >= strtotime('today'); ?>
          <div class="col-md-6 col-lg-4">
            <div class="card challenge-card h-100 card-hover">
              <div class="card-body d-flex flex-column">
                <div class="d-flex justify-content-between align-items-start gap-2 mb-2">
                  <span class="difficulty"><i class="bi bi-bar-chart me-1"></i><?= e($ch['difficulty']) ?></span>
                  <span class="badge badge-tag"><?= e($ch['category']) ?></span>
                </div>
                <h2 class="h5"><a class="stretched-link text-decoration-none" href="<?= e(url('pages/challenge-detail.php?id=' . (int) $ch['id'])) ?>"><?= e($ch['title']) ?></a></h2>
                <p class="small text-muted mb-3"><?= e(excerpt($ch['description'], 130)) ?></p>
                <div class="meta-row mb-2">
                  <span><i class="bi bi-people me-1"></i><?= (int) $ch['participants'] ?> joined</span>
                  <?php if ($ch['deadline']): ?><span class="<?= $isOpen ? '' : 'text-danger' ?>"><i class="bi bi-calendar3 me-1"></i><?= $isOpen ? 'Ends ' . e(format_date($ch['deadline'])) : 'Closed ' . e(format_date($ch['deadline'])) ?></span><?php endif; ?>
                  <?php if ($ch['avg_rating']): ?><span><i class="bi bi-star-fill me-1"></i><?= e($ch['avg_rating']) ?>/5</span><?php endif; ?>
                </div>
                <div class="mt-auto d-flex justify-content-between align-items-center gap-2">
                  <div>
                    <?= demo_badge($ch['is_demo']) ?>
                    <?php if ($ch['my_status']): ?><?= status_badge($ch['my_status']) ?><?php endif; ?>
                  </div>
                  <span class="small text-gold fw-semibold">View <i class="bi bi-arrow-right"></i></span>
                </div>
                <?php if ($ch['sponsor_name']): ?><div class="sponsor">Sponsored by <?= e($ch['sponsor_name']) ?></div><?php endif; ?>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
      <?= pagination($total, $page, $perPage, array_filter(['q' => $q, 'category' => $category, 'difficulty' => $difficulty])) ?>
    <?php endif; ?>
  </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>

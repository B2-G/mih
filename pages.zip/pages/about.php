<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';

$page_title = 'About Us';
$page_description = 'About Mindset Innovators Hub: our mission, vision, founder motivation and the team behind the pilot.';
$active = 'about';
$breadcrumbs = [['About us', null]];

$team = db_all('SELECT * FROM team_members_public ORDER BY sort_order, id');
$memberCount = db_count("SELECT COUNT(*) FROM users WHERE role = 'member' AND status = 'active'");
$projectCount = db_count("SELECT COUNT(*) FROM projects WHERE status = 'published'");
$teamCount = db_count('SELECT COUNT(*) FROM teams');
require __DIR__ . '/../includes/header.php';
?>
<section class="section-pad-sm section-cream">
  <div class="container">
    <div class="row g-5 align-items-center">
      <div class="col-lg-7">
        <span class="eyebrow">About the hub</span>
        <h1 class="display-4 mt-2 mb-3">A place to turn potential into practice.</h1>
        <p class="lead-lg">Mindset Innovators Hub is a youth innovation platform being built in Nigeria for young people across Africa. It brings learning, collaboration, evidence and opportunity into one connected journey.</p>
        <p class="mb-0 text-muted">The project is at an early pilot stage. This website is a working prototype of the planned platform, built to test the experience and learn what the community actually needs.</p>
      </div>
      <div class="col-lg-5">
        <div class="panel p-4">
          <div class="row g-3 text-center">
            <div class="col-4"><div class="dash-stat"><div class="number"><?= number_format($memberCount) ?></div><div class="label">Members</div></div></div>
            <div class="col-4"><div class="dash-stat"><div class="number"><?= number_format($projectCount) ?></div><div class="label">Projects</div></div></div>
            <div class="col-4"><div class="dash-stat"><div class="number"><?= number_format($teamCount) ?></div><div class="label">Teams</div></div></div>
          </div>
          <p class="small text-muted mt-3 mb-0">Live counts from this prototype database, including labelled demo records.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="section-pad">
  <div class="container">
    <div class="row g-4">
      <div class="col-md-4">
        <div class="feature-card h-100">
          <div class="feature-icon"><i class="bi bi-bullseye"></i></div>
          <h2 class="h4">Mission</h2>
          <p class="text-muted mb-0">To help young people transform their ideas and potential into practical skills, projects, meaningful connections, and opportunities.</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="feature-card h-100">
          <div class="feature-icon"><i class="bi bi-eye"></i></div>
          <h2 class="h4">Vision</h2>
          <p class="text-muted mb-0">An accessible innovation ecosystem where young people learn, practise, collaborate, develop solutions, showcase their abilities, and connect with opportunities.</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="feature-card h-100">
          <div class="feature-icon"><i class="bi bi-compass"></i></div>
          <h2 class="h4">Our approach</h2>
          <p class="text-muted mb-0">Start with something real. Learn enough to try, try with guidance, show the evidence, and connect the work to a next step.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="section-pad section-dark">
  <div class="container">
    <div class="row g-5 align-items-center">
      <div class="col-lg-5">
        <div class="p-4 rounded-4" style="border:1px solid rgba(230,192,104,.3); background:rgba(255,253,247,.05)">
          <i class="bi bi-quote display-4 text-gold-bright"></i>
          <p class="lead mb-3">“The gap is rarely potential. It is the space between learning something and having a safe place to try it.”</p>
          <div class="d-flex align-items-center gap-3">
            <span class="avatar avatar-md avatar-initials rounded-circle">BT</span>
            <div>
              <strong class="text-cream d-block">Bintu Tijjani Goni</strong>
              <span class="small text-cream-soft">Founder · Software engineer</span>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-7">
        <span class="eyebrow">Why we started</span>
        <h2 class="display-5 mt-2 mb-3">Potential needs a route, not just encouragement.</h2>
        <p>As a software engineer, the founder kept meeting young people who had learned a lot, cared deeply about their communities, and still had no practical route from an idea to a first project. They needed somewhere to try, someone to ask, and a way to show what they could do.</p>
        <p>Mindset Innovators Hub is an attempt to build that route in public: a small, honest prototype that can be tested with real young people, mentors and partner organisations before it claims to be anything bigger.</p>
        <p class="mb-0">The pilot is designed to learn from actual use — which challenges people join, what feedback helps, where teams struggle, and which opportunities connect. We would rather show small, real numbers than impressive invented ones.</p>
      </div>
    </div>
  </div>
</section>

<section class="section-pad">
  <div class="container">
    <div class="text-center mb-5">
      <span class="eyebrow">Our values</span>
      <h2 class="display-6 mt-2">Practical, honest, connected.</h2>
    </div>
    <div class="row g-3">
      <?php
      $values = [
          ['bi-hammer', 'Practical', 'We favour a first real attempt over a perfect plan.'],
          ['bi-chat-heart', 'Honest', 'We label demo data, name limitations and do not invent impact.'],
          ['bi-people', 'Connected', 'Progress is stronger with feedback, teammates and a door to opportunity.'],
          ['bi-shield-check', 'Respectful', 'We protect privacy, ask for consent and keep moderation visible.'],
      ];
      foreach ($values as $v): ?>
        <div class="col-md-6 col-lg-3">
          <div class="feature-card h-100 text-center">
            <div class="feature-icon mx-auto"><i class="bi <?= $v[0] ?>"></i></div>
            <h3 class="h5"><?= e($v[1]) ?></h3>
            <p class="text-muted small mb-0"><?= e($v[2]) ?></p>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="section-pad section-cream" id="team">
  <div class="container">
    <div class="row align-items-end mb-4">
      <div class="col-lg-8">
        <span class="eyebrow">The team</span>
        <h2 class="display-6 mt-2 mb-0">People supporting the pilot</h2>
      </div>
      <div class="col-lg-4 text-lg-end">
        <span class="small text-muted">Listed from the public team table in this installation.</span>
      </div>
    </div>
    <div class="row g-3">
      <?php foreach ($team as $person): ?>
        <div class="col-sm-6 col-lg-4">
          <div class="feature-card h-100 d-flex gap-3 align-items-start">
            <span class="avatar avatar-md avatar-initials rounded-circle"><?= e(initials($person['name'])) ?></span>
            <div>
              <h3 class="h5 mb-1"><?= e($person['name']) ?></h3>
              <div class="small text-gold fw-semibold mb-2"><?= e($person['role']) ?></div>
              <p class="small text-muted mb-0"><?= e($person['bio']) ?></p>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
      <?php if (!$team): ?><div class="col-12"><div class="empty-state"><p>The team list has not been added yet.</p></div></div><?php endif; ?>
    </div>
    <div class="alert alert-warning mt-4 mb-0 small" role="note">
      <i class="bi bi-info-circle me-1"></i>Team names and roles come from the <code>team_members_public</code> table so they can be corrected without editing code. This is a prototype; being listed here is not a claim of a formal appointment or endorsement.
    </div>
  </div>
</section>

<section class="section-pad">
  <div class="container">
    <div class="panel p-4 p-lg-5">
      <div class="row g-4 align-items-center">
        <div class="col-lg-8">
          <h2 class="h3">Come and test it with us.</h2>
          <p class="text-muted mb-0">If you are a young person, mentor, school, NGO or organisation that wants to learn in public with us, we would like to hear from you.</p>
        </div>
        <div class="col-lg-4 d-flex flex-wrap gap-2 justify-content-lg-end">
          <a class="btn btn-gold" href="<?= e(url('pages/pilot.php')) ?>">Join the pilot</a>
          <a class="btn btn-outline-brown" href="<?= e(url('pages/contact.php')) ?>">Contact us</a>
        </div>
      </div>
    </div>
  </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>

<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';

$page_title = 'Opportunity Bridge';
$page_description = 'Find competitions, internships, grants, training and events for young builders in the pilot.';
$active = 'explore';
$breadcrumbs = [['Opportunities', null]];

$q = get('q');
$type = get('type');
$page = current_page_number();
$perPage = PER_PAGE;
$uid = user_id();

$where = ["o.status = 'approved'"];
$params = [];
if ($q !== '') {
    $where[] = '(o.title LIKE ? OR o.organization LIKE ? OR o.description LIKE ? OR o.tags LIKE ?)';
    $like = '%' . $q . '%';
    array_push($params, $like, $like, $like, $like);
}
if ($type !== '' && in_array($type, ['competition', 'internship', 'training', 'grant', 'job', 'event'], true)) {
    $where[] = 'o.type = ?';
    $params[] = $type;
}
$whereSql = implode(' AND ', $where);
$total = db_count("SELECT COUNT(*) FROM opportunities o WHERE $whereSql", $params);
$pages = max(1, (int) ceil($total / $perPage));
$page = min($page, $pages);
$offset = ($page - 1) * $perPage;

$stmt = db()->prepare(
    "SELECT o.*, u.name AS poster_name, u.role AS poster_role,
            (SELECT COUNT(*) FROM opportunity_actions oa WHERE oa.opportunity_id = o.id AND oa.action = 'saved') AS saves,
            (SELECT COUNT(*) FROM opportunity_actions oa WHERE oa.opportunity_id = o.id AND oa.action = 'interested') AS interests,
            (SELECT COUNT(*) FROM opportunity_actions oa WHERE oa.opportunity_id = o.id AND oa.action = 'applied') AS applications
     FROM opportunities o LEFT JOIN users u ON u.id = o.posted_by
     WHERE $whereSql
     ORDER BY o.deadline IS NULL, o.deadline ASC, o.created_at DESC
     LIMIT $perPage OFFSET $offset"
);
$stmt->execute($params);
$opportunities = $stmt->fetchAll();
$types = ['competition' => 'Competition', 'internship' => 'Internship', 'training' => 'Training', 'grant' => 'Grant', 'job' => 'Job', 'event' => 'Event'];
$myActions = [];
if ($uid) {
    $rows = db_all('SELECT opportunity_id, action FROM opportunity_actions WHERE user_id = ?', [$uid]);
    foreach ($rows as $row) {
        $myActions[(int) $row['opportunity_id']][$row['action']] = true;
    }
}

require __DIR__ . '/../includes/header.php';
?>
<section class="section-pad-sm section-cream">
  <div class="container">
    <div class="row align-items-end g-3">
      <div class="col-lg-8">
        <span class="eyebrow">From learning to next step</span>
        <h1 class="display-5 mt-2 mb-1">Opportunity Bridge</h1>
        <p class="text-muted mb-0">A clear, curated list of competitions, internships, grants, training and events. Always check the official source before applying.</p>
      </div>
      <div class="col-lg-4 text-lg-end">
        <?php if (is_partner() || is_admin()): ?><a class="btn btn-gold" href="<?= e(url('pages/opportunity-form.php')) ?>"><i class="bi bi-plus-lg me-1"></i>Post an opportunity</a><?php endif; ?>
      </div>
    </div>
  </div>
</section>

<section class="section-pad-sm">
  <div class="container">
    <form class="filter-bar mb-4" method="get" action="<?= e(url('pages/opportunities.php')) ?>">
      <div class="row g-2 align-items-end">
        <div class="col-lg-7 col-md-6">
          <label class="form-label" for="q">Search opportunities</label>
          <input class="form-control" id="q" name="q" value="<?= e($q) ?>" placeholder="Title, organisation or tag">
        </div>
        <div class="col-lg-3 col-md-6">
          <label class="form-label" for="type">Type</label>
          <select class="form-select" id="type" name="type">
            <option value="">All types</option>
            <?php foreach ($types as $value => $label): ?><option value="<?= e($value) ?>" <?= $type === $value ? 'selected' : '' ?>><?= e($label) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="col-lg-2 d-grid">
          <button class="btn btn-gold" type="submit"><i class="bi bi-search me-1"></i>Filter</button>
        </div>
      </div>
      <?php if ($q || $type): ?><div class="mt-2"><a class="small" href="<?= e(url('pages/opportunities.php')) ?>">Clear filters</a></div><?php endif; ?>
    </form>

    <div class="alert alert-warning small" role="note">
      <i class="bi bi-exclamation-triangle me-1"></i><strong>Check before you apply.</strong> These listings are demo records in a prototype. The prototype does not verify eligibility, prizes, funding or employers. Never pay a fee to apply for an opportunity.
    </div>

    <?php if (!$opportunities): ?>
      <div class="panel empty-state mx-auto">
        <i class="bi bi-compass display-4"></i>
        <h2>No opportunities match</h2>
        <p>Try clearing the filters. Partners can submit a listing for admin review.</p>
        <a class="btn btn-outline-brown" href="<?= e(url('pages/opportunities.php')) ?>">Show all</a>
      </div>
    <?php else: ?>
      <div class="row g-3">
        <?php foreach ($opportunities as $o): $expired = $o['deadline'] && strtotime($o['deadline']) < strtotime('today'); $mine = $myActions[(int) $o['id']] ?? []; ?>
          <div class="col-md-6">
            <article class="card h-100 card-hover">
              <div class="card-body d-flex flex-column">
                <div class="d-flex flex-wrap justify-content-between gap-2 mb-2">
                  <span class="badge badge-stage text-uppercase"><?= e($types[$o['type']] ?? $o['type']) ?></span>
                  <span class="small text-muted"><?= e($o['organization']) ?></span>
                </div>
                <h2 class="h5"><a class="stretched-link text-decoration-none" href="<?= e(url('pages/opportunity-detail.php?id=' . (int) $o['id'])) ?>"><?= e($o['title']) ?></a></h2>
                <p class="small text-muted mb-3"><?= e(excerpt($o['description'], 150)) ?></p>
                <div class="meta-row mb-2">
                  <span class="<?= $expired ? 'text-danger' : '' ?>"><i class="bi bi-calendar3 me-1"></i><?= $o['deadline'] ? ($expired ? 'Closed ' : 'Deadline ') . e(format_date($o['deadline'])) : 'No deadline' ?></span>
                  <?php if ($mine): ?>
                    <?php foreach (['saved' => 'Saved', 'interested' => 'Interested', 'applied' => 'Applied'] as $key => $label): ?><?php if (!empty($mine[$key])): ?><span class="badge text-bg-success"><?= e($label) ?></span><?php endif; ?><?php endforeach; ?>
                  <?php endif; ?>
                </div>
                <div class="mt-auto d-flex justify-content-between align-items-center gap-2 pt-2 border-top">
                  <div class="d-flex gap-2 small text-muted">
                    <span title="Saved"><i class="bi bi-bookmark me-1"></i><?= (int) $o['saves'] ?></span>
                    <span title="Interested"><i class="bi bi-star me-1"></i><?= (int) $o['interests'] ?></span>
                    <span title="Applied"><i class="bi bi-send me-1"></i><?= (int) $o['applications'] ?></span>
                  </div>
                  <span class="small text-gold fw-semibold">Details <i class="bi bi-arrow-right"></i></span>
                </div>
              </div>
            </article>
          </div>
        <?php endforeach; ?>
      </div>
      <?= pagination($total, $page, $perPage, array_filter(['q' => $q, 'type' => $type])) ?>
    <?php endif; ?>
  </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>

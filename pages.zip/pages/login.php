<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';

if (is_logged_in()) {
    redirect(redirect_after_login());
}

$page_title = 'Sign in';
$page_description = 'Sign in to your Mindset Innovators Hub account.';
$next = safe_next(get('next', ''));
$errors = [];
$identifier = '';

if (is_post()) {
    require_csrf();
    $identifier = strtolower(post('identifier'));
    $password = (string) ($_POST['password'] ?? '');
    $next = safe_next(post('next', ''));

    if ($identifier === '' || $password === '') {
        $errors['form'] = 'Please enter your email or username and your password.';
    } elseif (login_rate_limited($identifier)) {
        $errors['form'] = 'Too many failed attempts. Please wait about 15 minutes and try again.';
    } else {
        $user = db_one('SELECT * FROM users WHERE email = ? OR username = ? LIMIT 1', [$identifier, $identifier]);
        $ok = $user && password_verify($password, $user['password_hash']);
        record_login_attempt($identifier, (bool) $ok);
        if (!$ok) {
            $errors['form'] = 'Invalid login credentials. Please try again.';
        } elseif ($user['status'] === 'suspended') {
            $errors['form'] = 'This account is not available. Please contact the team.';
        } else {
            login_user((int) $user['id']);
            log_activity('auth.login_success', 'user', (int) $user['id']);
            if ($next !== '' && $next !== 'index.php') {
                redirect($next);
            }
            if ($user['role'] === 'member') {
                $quiz = db_one('SELECT quiz_completed FROM profiles WHERE user_id = ?', [(int) $user['id']]);
                if (!$quiz || !(int) $quiz['quiz_completed']) {
                    redirect('pages/onboarding.php');
                }
            }
            redirect(redirect_after_login());
        }
    }
}

$demoAccounts = APP_DEBUG
    ? db_all("SELECT name, email, role, status FROM users WHERE is_demo = 1 AND role <> 'admin' ORDER BY FIELD(role,'member','mentor','partner'), id LIMIT 4")
    : [];

require __DIR__ . '/../includes/header.php';
?>
<section class="section-pad">
  <div class="container">
    <div class="auth-wrap">
      <div class="auth-card">
        <div class="text-center mb-4">
          <img src="<?= e(logo_url()) ?>" alt="" width="56" height="56" class="mb-2">
          <h1 class="h3 mb-1">Welcome back</h1>
          <p class="text-muted small mb-0">Sign in to continue your journey.</p>
        </div>
        <?= error_summary($errors) ?>
        <form method="post" action="<?= e(url('pages/login.php')) ?>" class="needs-validation" novalidate data-single-submit>
          <?= csrf_field() ?>
          <input type="hidden" name="next" value="<?= e($next) ?>">
          <div class="mb-3">
            <label class="form-label" for="identifier">Email or username</label>
            <input class="form-control" id="identifier" name="identifier" required maxlength="190" autocomplete="username" value="<?= e($identifier) ?>" autofocus>
          </div>
          <div class="mb-2">
            <div class="d-flex justify-content-between">
              <label class="form-label" for="password">Password</label>
              <a class="small" href="<?= e(url('pages/forgot-password.php')) ?>">Forgot password?</a>
            </div>
            <input type="password" class="form-control" id="password" name="password" required autocomplete="current-password">
          </div>
          <button class="btn btn-gold w-100 mt-3" type="submit">Sign in</button>
        </form>
        <p class="text-center small text-muted mt-4 mb-0">New here? <a href="<?= e(url('pages/register.php')) ?>">Create an account</a></p>
      </div>

      <?php if ($demoAccounts): ?>
        <div class="panel panel-body mt-3">
          <div class="d-flex justify-content-between align-items-center mb-2">
            <span class="small-caps">Demo logins</span>
            <span class="badge badge-demo">Demo data</span>
          </div>
          <p class="small text-muted mb-2">All demo accounts use the password <code>Password123!</code>. Admin: <code>admin@mindsetinnovators.test</code>.</p>
          <div class="table-responsive">
            <table class="table table-sm mb-0">
              <thead><tr><th>Role</th><th>Email</th></tr></thead>
              <tbody>
                <?php foreach ($demoAccounts as $d): ?>
                  <tr><td><?= e(role_label($d['role'])) ?><?= $d['status'] === 'pending' ? ' (pending)' : '' ?></td><td><code><?= e($d['email']) ?></code></td></tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
          <p class="small text-muted mt-2 mb-0">This panel is only visible while <code>APP_DEBUG</code> is on.</p>
        </div>
      <?php endif; ?>

      <p class="text-center small text-muted mt-3 mb-0"><i class="bi bi-shield-lock me-1"></i>Passwords are hashed, sessions expire after 30 minutes, and forms are CSRF protected.</p>
    </div>
  </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>

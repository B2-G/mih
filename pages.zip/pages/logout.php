<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';

$page_title = 'Sign out';
$page_description = 'Sign out of Mindset Innovators Hub.';

if (is_post()) {
    require_csrf();
    logout_user();
    start_session();
    flash('success', 'You have been signed out.');
    redirect('index.php');
}

$breadcrumbs = [['Sign out', null]];
require __DIR__ . '/../includes/header.php';
?>
<section class="section-pad">
  <div class="container">
    <div class="auth-wrap">
      <div class="auth-card text-center">
        <i class="bi bi-box-arrow-right display-4 text-gold"></i>
        <h1 class="h3 mt-3">Sign out?</h1>
        <p class="text-muted">You will need to sign in again to continue working on your profile, projects and rooms.</p>
        <form method="post" action="<?= e(url('pages/logout.php')) ?>">
          <?= csrf_field() ?>
          <div class="d-flex gap-2 justify-content-center">
            <button class="btn btn-outline-brown" type="submit">Yes, sign out</button>
            <a class="btn btn-gold" href="<?= e(url(redirect_after_login())) ?>">Stay signed in</a>
          </div>
        </form>
      </div>
    </div>
  </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>

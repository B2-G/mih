<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';

$page_title = 'Choose a new password';
$page_description = 'Use your one-time link to choose a new password.';
$errors = [];
$token = post('token', get('token'));

$findReset = static function (string $token): ?array {
    if ($token === '') {
        return null;
    }
    return db_one(
        "SELECT pr.*, u.name, u.email FROM password_resets pr JOIN users u ON u.id = pr.user_id
         WHERE pr.token_hash = ? AND pr.used_at IS NULL AND pr.expires_at > NOW() LIMIT 1",
        [hash('sha256', $token)]
    );
};
$reset = $findReset($token);

if (is_post()) {
    require_csrf();
    $password = (string) ($_POST['password'] ?? '');
    $confirm = (string) ($_POST['password_confirm'] ?? '');
    if (!$reset) {
        $errors['form'] = 'This reset link is invalid or has expired. Please request a new one.';
    }
    if (mb_strlen($password) < 8 || !preg_match('/[A-Za-z]/', $password) || !preg_match('/[0-9]/', $password)) {
        $errors['password'] = 'Use at least 8 characters, including a letter and a number.';
    }
    if ($password !== $confirm) {
        $errors['password_confirm'] = 'The passwords do not match.';
    }
    if (!$errors && $reset) {
        db()->beginTransaction();
        db_run('UPDATE users SET password_hash = ? WHERE id = ?', [password_hash($password, PASSWORD_DEFAULT), (int) $reset['user_id']]);
        db_run('UPDATE password_resets SET used_at = NOW() WHERE id = ?', [(int) $reset['id']]);
        db_run('UPDATE password_resets SET used_at = NOW() WHERE user_id = ? AND used_at IS NULL', [(int) $reset['user_id']]);
        db()->commit();
        log_activity('auth.password_reset', 'user', (int) $reset['user_id'], null, (int) $reset['user_id']);
        notify((int) $reset['user_id'], 'security', 'Your password was reset using a one-time link.', 'pages/login.php');
        flash('success', 'Your password has been changed. You can now sign in with the new password.');
        redirect('pages/login.php');
    }
}

$breadcrumbs = [['Sign in', 'pages/login.php'], ['New password', null]];
require __DIR__ . '/../includes/header.php';
?>
<section class="section-pad">
  <div class="container">
    <div class="auth-wrap">
      <div class="auth-card">
        <h1 class="h3 mb-2">Choose a new password</h1>
        <?php if (!$reset): ?>
          <div class="alert alert-danger">
            <i class="bi bi-link-45deg me-1"></i>This reset link is invalid, already used or expired. Request a fresh one below.
          </div>
          <a class="btn btn-gold w-100" href="<?= e(url('pages/forgot-password.php')) ?>">Request a new link</a>
        <?php else: ?>
          <p class="text-muted small mb-4">Resetting the password for <strong><?= e($reset['email']) ?></strong>.</p>
          <?= error_summary($errors) ?>
          <?php if (!empty($errors['form'])): ?><div class="alert alert-danger"><?= e($errors['form']) ?></div><?php endif; ?>
          <form method="post" action="<?= e(url('pages/reset-password.php')) ?>" class="needs-validation" novalidate data-single-submit>
            <?= csrf_field() ?>
            <input type="hidden" name="token" value="<?= e($token) ?>">
            <div class="mb-3">
              <label class="form-label" for="password">New password</label>
              <input type="password" class="form-control <?= isset($errors['password']) ? 'is-invalid' : '' ?>" id="password" name="password" required minlength="8" autocomplete="new-password">
              <div class="form-text">At least 8 characters, with a letter and a number.</div>
              <?= field_error($errors, 'password') ?>
            </div>
            <div class="mb-3">
              <label class="form-label" for="password_confirm">Confirm new password</label>
              <input type="password" class="form-control <?= isset($errors['password_confirm']) ? 'is-invalid' : '' ?>" id="password_confirm" name="password_confirm" required autocomplete="new-password">
              <?= field_error($errors, 'password_confirm') ?>
            </div>
            <button class="btn btn-gold w-100" type="submit">Save new password</button>
          </form>
        <?php endif; ?>
      </div>
    </div>
  </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>

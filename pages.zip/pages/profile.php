<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';

$username = get('u');
if ($username === '' && is_logged_in()) {
    $username = current_user()['username'];
}
if ($username === '') {
    require_login();
    redirect('pages/profile.php');
}

$person = db_one(
    "SELECT u.id, u.name, u.username, u.role, u.status, u.is_demo, u.created_at AS member_since,
            p.photo, p.headline, p.bio, p.location, p.interests, p.goals, p.website, p.linkedin,
            p.github, p.journey_stage, p.privacy, p.quiz_completed
     FROM users u JOIN profiles p ON p.user_id = u.id
     WHERE u.username = ? AND u.status <> 'suspended' LIMIT 1",
    [$username]
);
if (!$person) {
    not_found('That member profile could not be found.');
}

$isOwner = is_logged_in() && user_id() === (int) $person['id'];
$isAdminViewer = is_admin();
if ($person['privacy'] === 'private' && !$isOwner && !$isAdminViewer) {
    forbidden('This profile is private. Only the owner and admins can view it.');
}
if ($person['privacy'] === 'members' && !is_logged_in()) {
    require_login();
}

$page_title = $person['name'] . ' — Profile';
$page_description = $person['headline'] ?: 'A member profile on Mindset Innovators Hub.';
$breadcrumbs = [['Member directory', 'pages/directory.php'], [$person['name'], null]];

$skills = db_all(
    'SELECT s.name, us.level FROM user_skills us JOIN skills s ON s.id = us.skill_id
     WHERE us.user_id = ? ORDER BY s.name',
    [(int) $person['id']]
);
$badges = db_all(
    'SELECT b.*, ub.awarded_at FROM user_badges ub JOIN badges b ON b.id = ub.badge_id
     WHERE ub.user_id = ? ORDER BY ub.awarded_at DESC',
    [(int) $person['id']]
);
$projects = db_all(
    "SELECT * FROM projects WHERE user_id = ? AND status = 'published' ORDER BY created_at DESC",
    [(int) $person['id']]
);
$ideas = db_all(
    "SELECT * FROM ideas WHERE user_id = ? AND visibility <> 'private' ORDER BY created_at DESC LIMIT 5",
    [(int) $person['id']]
);
$teams = db_all(
    'SELECT t.*, tm.role FROM team_members tm JOIN teams t ON t.id = tm.team_id WHERE tm.user_id = ? ORDER BY t.created_at DESC',
    [(int) $person['id']]
);
$stats = [
    'completed' => db_count("SELECT COUNT(*) FROM submissions WHERE user_id = ? AND status = 'completed'", [(int) $person['id']]),
    'projects' => count($projects),
    'teams' => count($teams),
];
[$completeness, $missing] = profile_completeness((int) $person['id']);

require __DIR__ . '/../includes/header.php';
?>
<section class="section-pad-sm">
  <div class="container">
    <?php if ($person['privacy'] !== 'public'): ?>
      <div class="alert alert-info small mb-3"><i class="bi bi-eye-slash me-1"></i>Visibility: <strong><?= e(ucfirst($person['privacy'])) ?></strong><?= $person['privacy'] === 'members' ? ' — only signed-in members can see this profile.' : ' — only the owner and admins can see this profile.' ?></div>
    <?php endif; ?>
    <div class="profile-hero">
      <div class="row g-4 align-items-center position-relative" style="z-index:1">
        <div class="col-auto"><?= avatar_html($person, $person, 'xl') ?></div>
        <div class="col">
          <div class="d-flex flex-wrap align-items-center gap-2 mb-1">
            <h1 class="h2 mb-0"><?= e($person['name']) ?></h1>
            <?= demo_badge($person['is_demo']) ?>
          </div>
          <p class="lead mb-2" style="color:rgba(248,244,232,.88)"><?= e($person['headline'] ?: 'Member of the Mindset Innovators Hub pilot') ?></p>
          <div class="meta-row" style="color:rgba(248,244,232,.7)">
            <span><i class="bi bi-person me-1"></i>@<?= e($person['username']) ?></span>
            <?php if ($person['location']): ?><span><i class="bi bi-geo-alt me-1"></i><?= e($person['location']) ?></span><?php endif; ?>
            <span><i class="bi bi-calendar3 me-1"></i>Joined <?= e(format_date($person['member_since'], 'M Y')) ?></span>
            <span class="badge badge-stage"><?= e($person['journey_stage']) ?></span>
            <span class="badge badge-soft"><?= e(role_label($person['role'])) ?></span>
          </div>
        </div>
        <div class="col-lg-auto d-flex flex-column gap-2">
          <?php if ($isOwner): ?>
            <a class="btn btn-gold btn-sm" href="<?= e(url('pages/profile-edit.php')) ?>"><i class="bi bi-pencil me-1"></i>Edit profile</a>
          <?php endif; ?>
          <a class="btn btn-outline-gold btn-sm" href="<?= e(url('pages/portfolio.php?u=' . urlencode($person['username']))) ?>"><i class="bi bi-collection me-1"></i>Portfolio</a>
          <button class="btn btn-outline-gold btn-sm" type="button" data-copy="<?= e(url('pages/profile.php?u=' . urlencode($person['username']))) ?>"><i class="bi bi-link-45deg me-1"></i>Copy link</button>
        </div>
      </div>
      <div class="mt-4 position-relative" style="z-index:1">
        <?= journey_tracker($person['journey_stage']) ?>
      </div>
    </div>
  </div>
</section>

<section class="section-pad-sm">
  <div class="container">
    <div class="row g-4">
      <div class="col-lg-8">
        <div class="panel panel-body mb-4">
          <h2 class="h5">About</h2>
          <?php if ($person['bio']): ?>
            <p class="text-muted" style="white-space:pre-line"><?= e($person['bio']) ?></p>
          <?php else: ?>
            <p class="text-muted fst-italic">This member has not written a bio yet.</p>
          <?php endif; ?>
          <?php if ($person['goals']): ?>
            <div class="mt-3"><div class="small-caps mb-1">Goals</div><p class="small text-muted mb-0" style="white-space:pre-line"><?= e($person['goals']) ?></p></div>
          <?php endif; ?>
          <?php if ($person['website'] || $person['linkedin'] || $person['github']): ?>
            <div class="d-flex flex-wrap gap-2 mt-3">
              <?php if ($person['website']): ?><a class="btn btn-sm btn-outline-brown" rel="noopener noreferrer nofollow" target="_blank" href="<?= e($person['website']) ?>"><i class="bi bi-globe me-1"></i>Website</a><?php endif; ?>
              <?php if ($person['linkedin']): ?><a class="btn btn-sm btn-outline-brown" rel="noopener noreferrer nofollow" target="_blank" href="<?= e($person['linkedin']) ?>"><i class="bi bi-linkedin me-1"></i>LinkedIn</a><?php endif; ?>
              <?php if ($person['github']): ?><a class="btn btn-sm btn-outline-brown" rel="noopener noreferrer nofollow" target="_blank" href="<?= e($person['github']) ?>"><i class="bi bi-github me-1"></i>GitHub</a><?php endif; ?>
            </div>
          <?php endif; ?>
        </div>

        <div class="panel panel-body mb-4">
          <div class="d-flex justify-content-between align-items-center mb-2">
            <h2 class="h5 mb-0">Skills</h2>
            <span class="small text-muted">Self-reported</span>
          </div>
          <?php if ($skills): ?>
            <div>
              <?php foreach ($skills as $s): ?>
                <span class="skill-chip"><i class="bi bi-check2"></i><?= e($s['name']) ?><span class="level">· <?= e($s['level']) ?></span></span>
              <?php endforeach; ?>
            </div>
          <?php else: ?>
            <p class="text-muted small mb-0">No skills added yet.</p>
          <?php endif; ?>
          <?php if ($person['interests']): ?>
            <div class="small-caps mt-3 mb-2">Interests</div>
            <div><?php foreach (tags_to_array($person['interests']) as $tag): ?><span class="badge badge-tag me-1 mb-1"><?= e($tag) ?></span><?php endforeach; ?></div>
          <?php endif; ?>
        </div>

        <div class="d-flex justify-content-between align-items-center mb-3">
          <h2 class="h5 mb-0">Published projects</h2>
          <span class="small text-muted"><?= count($projects) ?> published</span>
        </div>
        <div class="row g-3 mb-4">
          <?php foreach ($projects as $p): ?>
            <div class="col-md-6">
              <div class="card project-card card-hover">
                <div class="project-cover">
                  <?php if ($p['image']): ?><img src="<?= e(url($p['image'])) ?>" alt="Cover image for <?= e($p['title']) ?>"><?php else: ?><span class="cover-initials"><?= e(initials($p['title'])) ?></span><?php endif; ?>
                </div>
                <div class="card-body">
                  <h3><a class="stretched-link text-decoration-none" href="<?= e(url('pages/project-detail.php?id=' . (int) $p['id'])) ?>"><?= e($p['title']) ?></a></h3>
                  <p class="summary"><?= e(excerpt($p['summary'], 95)) ?></p>
                  <?= demo_badge($p['is_demo']) ?>
                </div>
              </div>
            </div>
          <?php endforeach; ?>
          <?php if (!$projects): ?>
            <div class="col-12"><div class="panel p-4 text-center text-muted small">No published projects yet.<?= $isOwner ? ' <a href="' . e(url('pages/project-form.php')) . '">Add your first project</a>.' : '' ?></div></div>
          <?php endif; ?>
        </div>

        <div class="row g-4">
          <div class="col-md-6">
            <div class="panel panel-body h-100">
              <h2 class="h6">Ideas shared</h2>
              <?php if ($ideas): ?>
                <ul class="list-clean small">
                  <?php foreach ($ideas as $idea): ?>
                    <li><a href="<?= e(url('pages/idea-detail.php?id=' . (int) $idea['id'])) ?>"><?= e($idea['title']) ?></a><br><span class="text-muted"><?= e($idea['category']) ?> · <?= e($idea['status']) ?></span></li>
                  <?php endforeach; ?>
                </ul>
              <?php else: ?><p class="small text-muted mb-0">No public ideas yet.</p><?php endif; ?>
            </div>
          </div>
          <div class="col-md-6">
            <div class="panel panel-body h-100">
              <h2 class="h6">Teams</h2>
              <?php if ($teams): ?>
                <ul class="list-clean small">
                  <?php foreach ($teams as $t): ?>
                    <li><a href="<?= e(url('pages/team.php?id=' . (int) $t['id'])) ?>"><?= e($t['name']) ?></a><br><span class="text-muted"><?= e(ucfirst($t['role'])) ?></span></li>
                  <?php endforeach; ?>
                </ul>
              <?php else: ?><p class="small text-muted mb-0">Not in a team yet.</p><?php endif; ?>
            </div>
          </div>
        </div>
      </div>

      <aside class="col-lg-4">
        <div class="panel panel-body mb-3">
          <div class="small-caps mb-2">Growth</div>
          <div class="row g-2 text-center">
            <div class="col-4"><div class="dash-stat"><div class="number"><?= $stats['completed'] ?></div><div class="label">Challenges</div></div></div>
            <div class="col-4"><div class="dash-stat"><div class="number"><?= $stats['projects'] ?></div><div class="label">Projects</div></div></div>
            <div class="col-4"><div class="dash-stat"><div class="number"><?= $stats['teams'] ?></div><div class="label">Teams</div></div></div>
          </div>
          <p class="small text-muted mt-3 mb-0">Counted live from the prototype database.</p>
        </div>

        <?php if ($isOwner): ?>
          <div class="panel panel-body mb-3">
            <div class="d-flex justify-content-between small mb-1"><span>Profile completeness</span><strong><?= $completeness ?>%</strong></div>
            <div class="completeness"><span style="width:<?= $completeness ?>%"></span></div>
            <?php if ($missing): ?><p class="small text-muted mt-2 mb-0">Add: <?= e(implode(', ', $missing)) ?>.</p><?php endif; ?>
            <a class="btn btn-sm btn-outline-brown w-100 mt-3" href="<?= e(url('pages/profile-edit.php')) ?>">Improve profile</a>
          </div>
        <?php endif; ?>

        <div class="panel panel-body">
          <div class="small-caps mb-2">Badges</div>
          <?php if ($badges): ?>
            <?php foreach ($badges as $b): ?>
              <div class="badge-earned">
                <i class="bi <?= e($b['icon']) ?>"></i>
                <div><strong class="small d-block"><?= e($b['name']) ?></strong><span class="small text-muted"><?= e($b['description']) ?></span></div>
              </div>
            <?php endforeach; ?>
          <?php else: ?>
            <p class="small text-muted mb-0">No badges yet. Complete a challenge, join a team or publish a project to begin.</p>
          <?php endif; ?>
        </div>
      </aside>
    </div>
  </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>

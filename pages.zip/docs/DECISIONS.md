# Mindset Innovators Hub - Decisions

## Build Location
- Project built in `C:\xampp\htdocs\mih` (workspace) rather than spec's `mindset-innovators-hub`
- `BASE_URL` is auto-detected so the app works under any subfolder

## Demo Credentials
- Demo password for all seeded accounts: `Password123!`
- bcrypt hash: `$2y$10$NDOfJ8KZldnPsL9Pa7.L3un.ZQC0o6p8oW2xoyxxAJZ.V6A2zNq9y`
- All demo accounts use this single password for testing simplicity

## Database Choices
- Database name: `mindset_innovators_hub`
- Character set: `utf8mb4` for full Unicode support
- PDO singleton pattern in `config/database.php` with `db_one`/`db_all`/`db_run`/`db_count` helpers

## Architecture Decisions
- No framework (no Laravel, Symfony, etc.) - vanilla PHP 8
- PDO prepared statements throughout - no raw SQL interpolation
- CSRF on every state-changing POST request
- Role/ownership checks via `require_role()` and `require_login()`
- Hashed passwords via bcrypt
- Safe file uploads with extension and size validation
- `.htaccess` denies PHP execution in uploads directories

## Vendor Assets (Bundled, not CDN)
- Bootstrap 5.3.3 - `assets/vendor/bootstrap/`
- Bootstrap Icons 1.11.3 - `assets/vendor/bootstrap-icons/`
- Chart.js 4.4.3 - `assets/vendor/chart/`
- Sora fonts - `assets/vendor/fonts/`
- All downloaded successfully; no internet required at runtime

## Role System
- 4 roles: member, mentor, partner, admin
- Role-based page access via `is_admin()`, `is_mentor()`, `is_partner()`, `is_member()`
- Admin area under `admin/` with dedicated pages
- Partner/enquiries moderation separate from admin

## Room Implementation
- AJAX POST + ~4s polling for message updates
- No websockets chosen for simplicity and compatibility
- Public rooms for all signed-in roles
- Team rooms for team members and admins only

## Dashboard Strategy
- Role-specific separate pages: `dashboard.php`, `mentor-dashboard.php`, `partner-dashboard.php`
- Admin dashboard under `admin/index.php` with moderation queue
- Leaderboard and impact dashboard as public pages
- Privacy enforcement on all dashboards (users only see their own data)

## Documentation
- `docs/README.md` - user/setup guide
- `docs/DECISIONS.md` - architectural decisions log
- `docs/TESTING.md` - test procedures and checklist
# Mindset Innovators Hub - Testing

## Prerequisites
- XAMPP installed with Apache and MySQL running
- PHP 8.0+ with PDO and mysqli extensions
- Base URL pointing to the project root (e.g., `http://localhost/mih/`)

## Syntax Check
Run a syntax validation over all PHP files:

```bash
C:\xampp\php\php.exe -l "C:\xampp\htdocs\mih\includes\*.php"
C:\xampp\php\php.exe -l "C:\xampp\htdocs\mih\config\*.php"
C:\xampp\php\php.exe -l "C:\xampp\htdocs\mih\api\*.php"
C:\xampp\php\php.exe -l "C:\xampp\htdocs\mih\pages\*.php"
C:\xampp\php\php.exe -l "C:\xampp\htdocs\mih\admin\*.php"
```

All files must pass with "No syntax errors detected".

## Database Setup
1. Start XAMPP Control Panel
2. Start Apache and MySQL
3. Visit `http://localhost/phpmyadmin/` or use the MySQL CLI
4. Create database: `CREATE DATABASE mindset_innovators_hub CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;`
5. Import schema: `mysql -u root mindset_innovators_hub < database/schema.sql`
6. Import seed data: `mysql -u root mindset_innovators_hub < database/seed.sql`

## Demo Logins
| Role | Email | Password |
|------|-------|----------|
| Admin | admin@mindsetinnovators.test | Password123! |
| Mentor Aisha | mentor.aisha@mindsetinnovators.test | Password123! |
| Mentor Ibrahim | mentor.ibrahim@mindsetinnovators.test | Password123! |
| Partner Nexus | partner.nexus@mindsetinnovators.test | Password123! |
| Member Amina | member.amina@mindsetinnovators.test | Password123! |
| Member Yusuf | member.yusuf@mindsetinnovators.test | Password123! |
| Member Zainab | member.zainab@mindsetinnovators.test | Password123! |
| Member Musa | member.musa@mindsetinnovators.test | Password123! |
| Member Halima | member.halima@mindsetinnovators.test | Password123! |

## Functional Test Checklist

### Core Features
- [ ] Home page loads and shows brand overview
- [ ] Navigation works across all pages (header.php included)
- [ ] Sign up flow: register.php creates new user
- [ ] Login: login.php with rate limiting (40/10s)
- [ ] Logout: logout.php (POST + CSRF)
- [ ] Password reset: forgot-password.php → reset-password.php
- [ ] Email verification: verify.php (simulated)

### Auth & Roles
- [ ] Role-based access: admin sees admin area, mentors see mentor dashboard, etc.
- [ ] Generic error messages on failed login (no leaked details)
- [ ] Rate limiting visible when exceeded
- [ ] `elif` syntax fixed - no `<?php elif ?>` in any file

### Profile & Preferences
- [ ] onboarding.php (3-step quiz) works
- [ ] profile-edit.php: photo upload, skills/levels, links, stage, privacy
- [ ] profile.php: privacy enforcement, badges, projects, teams
- [ ] directory.php: search/filter/pagination works

### Challenges
- [ ] challenges.php: filters/pagination work
- [ ] challenge-form.php: create/edit for admin/mentor/partner
- [ ] challenge-detail.php: join, submit with file, review by mentor/admin, ratings, feedback

### Teams & Rooms
- [ ] teams.php: create/join/search teams
- [ ] team.php: members, auto team room, leave, recent messages
- [ ] rooms.php: public + team room lists
- [ ] room.php: chat UI, initial messages, AJAX send/delete/report, polling
- [ ] api/room_messages.php: GET after ID; POST send/delete/report with CSRF

### Idea Board
- [ ] ideas.php: visibility-aware list/filter/pagination
- [ ] idea-form.php: create/edit
- [ ] idea-detail.php: supports, comments, owner readiness/status, mentor/partner interest, accept/decline, admin manual match

### Portfolio
- [ ] showcase.php: filters/pagination
- [ ] project-form.php: create/edit, cover image, collaborators, draft/publish
- [ ] project-detail.php: feedback, moderation, publish toggle
- [ ] portfolio.php: public/printable portfolio with privacy enforcement

### Mentors
- [ ] mentors.php: search/filter/capacity
- [ ] mentor-form.php: mentor profile setup/edit
- [ ] mentor-detail.php: request/cancel mentor request
- [ ] messages.php: request threads, accept/decline, private messages

### Opportunities
- [ ] opportunities.php: public approved listings/filters
- [ ] opportunity-form.php: partner/admin create/edit, admin status
- [ ] opportunity-detail.php: save/interested/applied tracking

### Admin Area
- [ ] admin/index.php: site-wide stats + moderation queue
- [ ] admin/users.php: user list management
- [ ] admin/opportunities.php: opportunity listings management
- [ ] admin/reports.php: activity reports
- [ ] admin/enquiries.php: partner enquiries

### Public Pages
- [ ] index.php: homepage
- [ ] how-it-works.php: onboarding explanation
- [ ] explore.php: explore hub content
- [ ] partners.php: partner info + enquiry form
- [ ] about.php: about page
- [ ] pilot.php: pilot information
- [ ] contact.php: contact form

### Edge Cases & Security
- [ ] php -l sweep: all PHP files pass (no `elif`, no parse errors)
- [ ] CSRF token present on all state-changing forms
- [ ] Upload validation: only jpg/jpeg/png/webp (images), pdf/zip/txt (files)
- [ ] Max sizes: 3MB images, 5MB files
- [ ] .htaccess denies PHP execution in uploads/
- [ ] Rate limiting on mentor_message (40/10s)
- [ ] Role checks prevent unauthorized access
- [ ] Hashed passwords verified (bcrypt `Password123!`)

## Known Issues & Limitations
- Rooms use AJAX polling ~4s; no websockets
- Email simulated to `storage/mail.log`; links shown only when `APP_DEBUG=true`
- All demo accounts share `Password123!` bcrypt hash
- No CDN reliance - all vendors bundled locally
- Upload directory `.htaccess` denies PHP execution
- Admin moderation tools are basic (listing + manual actions)
- Leaderboard uses notification points summary (not full gamification)
- Privacy: users can only see their own data unless explicitly public

## Running the Full Walkthrough
1. Start XAMPP (Apache + MySQL)
2. Import schema + seed data as above
3. Visit `http://localhost/mih/` (adjust path)
4. Log in as admin: test admin functions
5. Log in as mentor: test mentor dashboard, requests, messages
6. Log in as partner: test opportunities, enquiries
7. Log in as member: test profile, challenges, ideas, portfolio
8. Verify responsive design on mobile/tablet
9. Check all `php -l` results are clean
10. Review `docs/` for full documentation
# Mindset Innovators Hub - Prototype

## Overview
A complete PHP 8/PDO/MySQL Bootstrap 5 prototype for the Mindset Innovators Hub platform. No frameworks - vanilla PHP with prepared statements.

## Brand Palette
- Dark brown: `#2E1A0F` (primary accents)
- Chocolate: `#4A2C17` (secondary accents)
- Gold: `#D4AF37` (highlights)
- Soft gold: `#E6C068` (backgrounds)
- Cream: `#F8F4E8` (surfaces)
- Black: `#1A1A1A` (text on gold)

## Logo
- Primary: `assets/img/logo.png`
- Fallback: `assets/img/logo.svg`

## Database
- Database name: `mindset_innovators_hub`
- Character set: `utf8mb4`
- PDO singleton connection via `config/database.php`

## Demo Accounts
All passwords are `Password123!` (bcrypt hash: `$2y$10$NDOfJ8KZldnPsL9Pa7.L3un.ZQC0o6p8oW2xoyxxAJZ.V6A2zNq9y`)

| Role | Email | Name |
|------|-------|------|
| Admin | admin@mindsetinnovators.test | Admin |
| Mentor | mentor.aisha@mindsetinnovators.test | Aisha |
| Mentor | mentor.ibrahim@mindsetinnovators.test | Ibrahim |
| Partner | partner.nexus@mindsetinnovators.test | Nexus |
| Member | member.amina@mindsetinnovators.test | Amina |
| Member | member.yusuf@mindsetinnovators.test | Yusuf |
| Member | member.zainab@mindsetinnovators.test | Zainab |
| Member | member.musa@mindsetinnovators.test | Musa |
| Member | member.halima@mindsetinnovators.test | Halima |

## Local Development
1. Start XAMPP (Apache + MySQL)
2. Import `database/schema.sql` then `database/seed.sql` into MySQL
3. Ensure `APP_DEBUG=true` in `config/config.php` for debug mail links
4. Visit `http://localhost/mih/` (adjust based on your web root)

## Security
- CSRF token required on every state-changing POST request
- bcrypt hashed passwords (`Password123!` for all demo accounts)
- Rate limiting on auth actions (40 attempts per 10 seconds)
- File upload validation: jpg/jpeg/png/webp (max 3MB), pdf/zip/txt (max 5MB)
- `.htaccess` denies PHP execution in uploads directories
- Role-based access checks on all pages
- Generic error messages for security (no leaked details)

## Known Limitations
- No websockets; rooms use AJAX POST + ~4s polling
- No image CDN; all vendor assets bundled locally
- Email simulated to `storage/mail.log`
- No rate-limit bypass prevention beyond 40/10s
- Admin area functional but basic moderation tools